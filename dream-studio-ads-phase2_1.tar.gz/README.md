# Dream Studio Ads — by Digital Sign (Bangladesh)

Finished 30-second Bangla AI video ads for Facebook sellers.
The site does three jobs:

1. **Sales** — a free 5-second watermarked preview of the customer's own product.
2. **Orders** — brief form → phone login → bKash payment (your QR + TrxID) → order tracking → delivery.
3. **Production** — staff dashboard: AI writes the script and shot prompts, Wan generates the clips,
   operators approve, the editor uploads the final ad.

| Part | Service |
|---|---|
| Web + API | Next.js 16 (TypeScript, Tailwind) on Railway |
| Background jobs | `mini-services/worker` (second Railway service, same code) |
| Database | Railway PostgreSQL (Prisma) |
| Phone login | Firebase Phone Auth |
| Script + safety AI | DeepSeek (switchable to Claude) — photo checks fall back to Alibaba Qwen-VL |
| Video | Alibaba Wan 3.0 (Model Studio) or Atlas Cloud |
| Files | Your Google Drive (`DreamStudioAds/…`, one folder per order) |
| Payments | Manual bKash QR (your number) — bKash API ready for later |
| Admin alerts | Telegram bot |
| Customer updates | Order page timeline + one-tap WhatsApp messages from staff |

---

## Run locally (test mode, no keys needed)

```bash
npm install
cp .env.example .env
# in .env set: MOCK_MODE=true, STORAGE_PROVIDER=local, DATABASE_URL="file:./db/dev.db"
npm run db:generate:local && npm run db:push:local && npm run db:seed
npm run dev          # terminal 1 → http://localhost:3000
npm run worker       # terminal 2
```

Test mode: the phone code is always **123456**, AI answers are canned, Wan returns a sample clip.
Demo logins (local only): `admin@dreamstudio.bd / admin12345`, `operator@dreamstudio.bd / operator12345`,
`editor@dreamstudio.bd / editor12345`. Staff dashboard: `/#/staff`.

---

## Deploy to Railway (step by step)

### 1. Put the code on GitHub
GitHub Desktop → *Add existing repository* (this folder) → *Publish repository* (keep it **private**).

### 2. Create the Railway project
1. Railway → **New Project → Deploy from GitHub repo** → pick the repo. This becomes the **web** service.
2. **+ New → Database → PostgreSQL**.
3. Railway builds with the included **Dockerfile** (it installs ffmpeg + fonts for the watermark).

### 3. Web service settings
- **Pre-deploy command:** `npx prisma migrate deploy && npm run db:seed`
- **Start command:** `npm run start` (default)
- **Healthcheck path:** `/api/health`
- **Networking → Generate Domain**, then put that URL in `APP_URL`.

### 4. Worker service
**+ New → GitHub repo** → the same repo again. In its settings:
- **Start command:** `npm run worker:once`
- No domain, no healthcheck (it has no web page).

### 5. Variables
Open **Project → Variables (shared)** and add everything from `.env.example`.
`DATABASE_URL` → use Railway's reference variable from the Postgres service. Both services must get the variables.

### 6. First login and settings
Open `https://YOUR-DOMAIN/#/staff`, log in with `ADMIN_EMAIL` / `ADMIN_PASSWORD`, then **Admin → Settings**:
- bKash number (the one that receives payments) + upload your bKash QR image
- WhatsApp number
- add operators/editors under **Staff accounts**
- real terms / privacy / refund text

### 7. Check everything is green
**Admin → System** shows every service in green or red. Then press **Test AI** (lists the model IDs your
DeepSeek key can use and proves the photo check works) and **Test Wan** (one 5-second clip, costs one clip).

---

## Connect services

### Firebase phone login
1. console.firebase.google.com → create a project → **Build → Authentication → Sign-in method → Phone → Enable**.
2. Upgrade to the **Blaze** plan (phone SMS is billed per message).
3. **Authentication → Settings → SMS region policy → Allow only Bangladesh**.
4. **Authentication → Settings → Authorized domains → Add** your Railway domain.
5. **Project settings → General → Your apps → Web app** → copy `apiKey`, `authDomain`, `projectId`, `appId`
   into `FIREBASE_API_KEY`, `FIREBASE_AUTH_DOMAIN`, `FIREBASE_PROJECT_ID`, `FIREBASE_APP_ID`.
   (These are public identifiers, not secrets.) The server checks every login token with Google's public keys.

### Connect Google Drive (your 5 TB)
The app stores files in **your own** Drive (a service account can't use a personal Drive's space).
1. console.cloud.google.com (same project as Firebase is fine) → **APIs & Services → Library → Google Drive API → Enable**.
2. **OAuth consent screen** → External → app name "Dream Studio" → add your email → **Publish app**
   (scope used: `drive.file` — the app only sees files it creates; no Google review needed).
   Publishing matters: in "Testing" the token expires after 7 days.
3. **Credentials → Create credentials → OAuth client ID → Web application**.
   Add redirect URI `https://developers.google.com/oauthplayground`. Copy the Client ID + Secret.
4. Get the refresh token (no install): open developers.google.com/oauthplayground → ⚙ gear →
   *Use your own OAuth credentials* → paste Client ID + Secret → in "Input your own scopes" type
   `https://www.googleapis.com/auth/drive.file` → **Authorize APIs** (sign in with the 5 TB account) →
   **Exchange authorization code for tokens** → copy the **Refresh token**.
   (Alternative on a computer with Node: `GOOGLE_CLIENT_ID=… GOOGLE_CLIENT_SECRET=… npm run drive:auth`
   with redirect URI `http://localhost:53682` added to the client.)
5. Set `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_REFRESH_TOKEN`, `STORAGE_PROVIDER=drive`.
6. After the first order, a `DreamStudioAds` folder appears in your Drive. Share it with your operators'
   and editor's Google accounts so the **Drive folder** button works for them.

### Wan (video)
- **Alibaba Model Studio:** `WAN_PROVIDER=alibaba`, `WAN_API_KEY`, `WAN_BASE_URL=https://<WorkspaceId>.ap-southeast-1.maas.aliyuncs.com`,
  `WAN_MODEL=wan3.0-video`, `WAN_RESOLUTION=480P`.
- **Atlas Cloud:** `WAN_PROVIDER=atlas`, `WAN_API_KEY`, `WAN_MODEL=<Atlas's Wan 3.0 model id>`; if Atlas needs extra
  fields (resolution etc.) put them in `WAN_ATLAS_EXTRA_JSON`.
- Failed tasks save the raw request/response in the job's error (visible in Test Wan / logs).

### DeepSeek (script + safety)
`DEEPSEEK_API_KEY`, `LLM_MODEL_HEAVY`, `LLM_MODEL_LIGHT`. Run **Test AI** to see the model IDs your key has.
If Test AI says the photo check failed because images aren't supported, set `VISION_PROVIDER=qwen`
(uses your Alibaba key). Update prices in **Admin → Settings → AI model prices** so the cost report is right.
To switch to Claude: `LLM_PROVIDER=anthropic`, `ANTHROPIC_API_KEY`, and Claude model IDs.

### Telegram alerts
Message **@BotFather** → `/newbot` → copy the token → `TELEGRAM_BOT_TOKEN`. Send your bot any message,
then get your chat id from **@userinfobot** → `TELEGRAM_CHAT_ID`.
You get: new payment to check, overdue orders, manual reviews, failed scripts/shots, and a daily summary at 22:00.

---

## How payment works (manual bKash QR)
1. Customer places the order → the order page shows your QR, number, exact amount and the order code.
2. Customer sends money, then submits sender number + **TrxID** (+ optional screenshot).
3. You get a Telegram alert → **Admin → Payments** → check your bKash statement → **Confirm** (production starts,
   the delivery deadline starts now) or **Reject** with a reason (the customer sees it and can resubmit).
4. A TrxID can never be used twice. Max 3 submissions per order per day.

Personal bKash accounts have monthly limits and aren't meant for business sales — move to a bKash merchant
account (`PAYMENT_MODE=bkash_api`) when volume grows. Review the bKash callback checks before enabling it.

---

## Safety rules built in
- Free preview: 1 per phone (one retry after a failure), 3 per IP per day, site-wide daily cap. Phone comes only
  from the verified login token.
- Every product photo is checked by the vision model before any paid video generation. Unreadable AI output on a
  paid order goes to **Manual review**, never auto-reject.
- Preview videos are only ever stored with the watermark burned in.
- Files are served only through signed links that expire.
- Staff removed in Admin lose access immediately.

## Known limitations
- Pages are hash-routed (`/#/order/…`) — fine for ads/links, not ideal for Google search.
- bKash API mode is kept but not enabled or tested; manual QR is the live path.
- Customer SMS is off (`SMS_PROVIDER=none`); updates go through the order page and staff WhatsApp.
