import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Use `next start` (standard) for production. Set output: "standalone"
  // only if you need a self-contained Docker-style deploy.
  typescript: {
    ignoreBuildErrors: false,
  },
  reactStrictMode: false,
};

export default nextConfig;
