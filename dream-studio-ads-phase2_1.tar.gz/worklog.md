# Dream Studio Ads — Build Worklog

This file tracks work across all agents building the Dream Studio Ads MVP.
Each agent MUST append a new section (separated by `---`) after finishing its Task ID.

---
Task ID: 0
Agent: orchestrator
Task: Bootstrap worklog and project analysis

Work Log:
- Inspected existing Next.js 16 project (App Router, Tailwind 4, 48 shadcn/ui components, Prisma 6/SQLite, NextAuth, Zustand, TanStack Query, z-ai-web-dev-sdk)
- Reviewed Caddyfile gateway (port 81, XTransformPort routing)
- Noted sandbox constraint: only `/` route in src/app/page.tsx is visible to user. All "pages" must be hash-routed inside the SPA.
- Decided architecture: single-page app with hash routing in src/app/page.tsx; full API layer in src/app/api/; worker mini-service in mini-services/worker; mockable service layer in src/lib/services/

Stage Summary:
- Project base is Next.js 16 (not 14 as user requested — sandbox requires 16). TypeScript 5, Tailwind 4, shadcn/ui New York.
- All external integrations (Claude, Wan/DashScope, bKash, SMS, R2) will be behind adapters with MOCK default.
- Build proceeds foundation → services → API → worker → UI → README.

---
Task ID: 1
Agent: orchestrator
Task: Foundation — env, Prisma schema, lib helpers, seed

Work Log:
- Wrote .env with all 23 vars (MOCK_MODE=true default)
- Wrote prisma/schema.prisma: StaffUser, Customer, Otp, Product, Order, Shot, Revision, Payment, CostLog, Preview, Job, Testimonial, Faq, Sample, Setting, StudioWaitlist
- bun run db:push succeeded (SQLite)
- Wrote src/lib/{env,types,auth,crypto,rateLimit,storage,aiService,sms,payment,queue,orders}.ts
- aiService: Claude + Wan adapters with MOCK deterministic JSON, retry+backoff, cost logging
- payment.ts: mock + bKash Tokenized (sandbox/live) adapters
- sms.ts: mock + bulksmsbd + sslwireless adapters
- storage.ts: local-disk + R2 adapters
- queue.ts: DB-backed claim/finish/fail job helpers
- prompts/{moderation,preview,script}.txt created
- Removed "server-only" markers (broke bun scripts); extracted crypto to lib/crypto.ts
- bun run db:seed succeeded: admin, operator, editor, 6 products, 6 samples, 5 FAQs, 3 testimonials

Stage Summary:
- DB seeded. Admin: admin@dreamstudio.bd / admin12345
- Operator: operator@dreamstudio.bd / operator12345
- Editor: editor@dreamstudio.bd / editor12345
- All services default to MOCK; flipping MOCK_MODE=false + filling keys enables real Claude/Wan/bKash/SMS/R2.
- Order code format: DSA-YYYY-NNNN. SLA helper converts "48 h" -> ms.
- Next: API routes (Task 3) and worker mini-service (Task 4) — can run in parallel.

---
Task ID: 7
Agent: staff-dashboard-builder
Task: Build the Staff Dashboard SPA view (src/components/views/staff.tsx) for operator / editor / admin roles

Work Log:
- Read worklog.md (Task 0 + 1: foundation, Prisma schema, services, seed) and explored existing API routes (/api/staff/*, /api/admin/*, /api/orders/[id], /api/payment/manual) and helpers (api/uploadFile from use-api, statusColor/statusLabelBn/isOverdue from lib/orders, cn from lib/utils).
- Confirmed `.bangla` and `.scroll-fancy` CSS classes exist in globals.css; confirmed all required shadcn/ui components (Card, Table, Tabs, Select, Checkbox, Dialog, Switch, Progress, Separator, ScrollArea, Badge, Input, Textarea, Label, Button) are present in src/components/ui/.
- Created /home/z/my-project/src/components/views/staff.tsx (single client component, ~1300 lines) with:
  * `StaffView` root: loads `/api/staff/me` on mount; shows LoginScreen if null, else TopBar + role-specific views.
  * `LoginScreen`: email+password form → POST `/api/staff/login`; demo credential hint box; "Back to site" → navigate("#/").
  * `TopBar`: logo, staff name/email, role badge, "View site" link, Logout button (POST `/api/staff/logout`).
  * `ProductionPanel` (shared by operator + admin): fetches `/api/orders/{id}` every 5s; renders brief (parsed from briefJson — productName/category/tone/language/cta/phoneOrPage/targetCustomer/priceOffer/notes + product photos), script (script_bn/music_mood/edit_notes/cta_endcard_text), shot cards grid (editable prompt textarea in local state keyed by shotId, video player, status badge, regen count, Approve + Regenerate buttons disabled when APPROVED), "Generate all shots" button (POST `/api/staff/order/{id}/generate`), Claim button, "claimed by other operator" notice, QC checklist (5 checkboxes) shown when ALL shots APPROVED → POST `/api/staff/order/{id}/qc`.
  * `OperatorView` (role operator|admin): Tabs "Queue" + "Production". Queue polls `/api/staff/queue` every 5s; table (Code/Product/Status badge/SLA countdown red-if-overdue/Operator/Open) sorted by slaDeadline asc, overdue rows bg-destructive/5, max-h-96 scroll-fancy.
  * `EditorView` (role editor|admin): Tabs "Editing Queue" + "Upload". Editing Queue filters queue for EDITING status (empty due to endpoint gap — added manual order-ID input + note), detail panel shows parsed script + approved shot video list + "Download script" (Blob → .txt). Upload form: Select EDITING order (or manual ID), file input for video + optional video15, uses `uploadFile` helper with FormData → POST `/api/staff/order/{id}/upload`; toast "ডেলিভার হয়েছে!" + qaFlag notice on success.
  * `AdminView` (role admin only): 7 tabs — Orders (merge `/api/staff/queue` + `/api/admin/costs` by id, status dropdown + code search filters, Mark paid via POST `/api/payment/manual`, Open → inline ProductionPanel), Products (inline-editable price/name/nameBn/deliverySla/revisions + active Switch + Save per row → PUT `/api/admin/products`), Content (sub-tabs testimonials/faqs/samples with inline edit + add-new + delete → GET/POST/PUT/DELETE `/api/admin/content`), Settings (whatsapp_number/bkash_personal/preview_daily_cap/launch_remaining/usd_to_bdt inputs + 3 legal Textareas → GET/PUT `/api/admin/settings`), Costs (4 summary cards + table sorted by marginPct desc from `/api/admin/costs`), QA Review (flagged DELIVERED+qaFlag orders list with note textarea + "Mark quality issue"/"Approve & Close" → POST `/api/admin/qa`), Operator Stats (table from `/api/admin/staff-stats`).
- All labels in Bangla, mobile-first responsive, no indigo/blue (used zinc/amber/emerald/rose/purple/orange/violet from existing statusColor map), `cn()` for conditional classes, `toast.success/error/info` from sonner, sticky TopBar, long lists use `max-h-* overflow-y-auto scroll-fancy`.
- Ran `bun run lint`: 1 error in src/components/views/order-detail.tsx (pre-existing — "load accessed before declaration" TDZ issue, NOT my file, instructed not to touch). 0 errors in staff.tsx (confirmed via `npx eslint src/components/views/staff.tsx` → exit 0).
- Fixed initial lint error in AdminCosts: `useEffect(() => { load(); }, [load])` with `load` = useCallback that calls setState triggered `react-hooks/set-state-in-effect`. Refactored to `.then()`-chain pattern (matching AdminStaffStats) with `active` flag for cleanup; removed now-unused `load` reference.

Stage Summary:
- File created at /home/z/my-project/src/components/views/staff.tsx — a single client component (~1300 lines) implementing the full staff dashboard for all 3 roles.
- Roles + tabs implemented: operator (Queue, Production), editor (Editing Queue, Upload), admin (Orders, Products, Content, Settings, Costs, QA Review, Operator Stats). Admin also sees operator + editor sections.
- API endpoints found missing / worked around:
  1. `/api/staff/queue` returns only PAID/SCRIPT_READY/GENERATING/QC/REVISION_REQUESTED orders (excludes EDITING) AND is operator/admin-only (editor role gets 403). Editor's Editing Queue tab therefore shows nothing from the queue — added a manual order-ID input + amber notice explaining the gap as the workaround. A dedicated `/api/staff/editing-queue` endpoint (editor-accessible, returns EDITING orders) would fix this properly.
  2. No admin "all orders" endpoint. Admin Orders tab merges `/api/staff/queue` (limited statuses, has customerPhone + product) with `/api/admin/costs` (all non-PENDING/non-REJECTED, has financials but no phone/product). PENDING_PAYMENT orders are absent from both — the "Mark paid" button column is present but never renders for the visible rows. A dedicated `/api/admin/orders` endpoint returning ALL orders with phone+product+financials would close this gap.
  3. `/api/staff/order/[id]/upload` does not return whether a 15s cut was saved (only returns `{ ok, qaFlag }`). UI handles this silently.
- Lint: 0 errors in staff.tsx (verified with `npx eslint src/components/views/staff.tsx`). The 1 remaining project-wide lint error is pre-existing in order-detail.tsx (another agent's file) and was not touched per instructions.
- Dev server: port 3000 returns HTTP 500 due to the pre-existing order-detail.tsx TDZ error (page-level import breaks compilation). This is NOT caused by staff.tsx. Once order-detail.tsx is fixed by its owning agent, the staff dashboard at `#/staff` will render.

---
Task ID: 8
Agent: orchestrator
Task: Final verification, README, deployment files

Work Log:
- Fixed use-hash-route window-not-defined (replaced useState+effect with useSyncExternalStore)
- Fixed order-detail TDZ (hoisted load into useCallback)
- Fixed FK constraint in /api/preview/start (upsert customer before OTP)
- Split lib/status.ts (pure, client-safe) from lib/orders.ts (server, imports storage)
  so client components don't pull in 'fs' via the storage adapter
- Added resolveVideoUrl helper so mock/sample videos (/samples/*) are served from
  /public while real uploads go through storage.signedUrl
- Installed @aws-sdk/client-s3 + @aws-sdk/s3-request-presigner so the R2 dynamic
  import resolves even in mock mode
- Added purpose="login" path for account OTP (separate from preview OTP limits)
- Restarted worker stably (bun, no --hot) — processed generate_script + 6 generate_shot jobs
- README.md written with full setup, env vars, Railway deploy, golden-path verification, limitations
- Procfile (release/web/worker) + .env.example added

Stage Summary — VERIFIED END-TO-END:
- Home renders 200, hero+gallery+pricing+FAQ+WhatsApp, no console errors, footer sticky
- Free preview: OTP (mock 123456) → moderation → Claude prompt → Wan job → READY video ✓
- Order create → mock payment callback → PAID → worker generates script (6 shots) → SCRIPT_READY ✓
- Operator: Generate all shots → 6 mock videos READY → Approve all 6 → QC checklist (5 boxes) → EDITING ✓
- Staff login (admin/operator/editor) all work, role-based tabs ✓
- Lint clean, both services (Next 3000, worker) running
- Final DB: 1 order, 6 shots, 1 preview, 9 jobs (all DONE), 3 staff, 6 products

Known limitations:
- Next.js 16 (sandbox requirement) not 14 — code is 14-compatible
- Single / route (sandbox) — all "pages" hash-routed in src/app/page.tsx
- bKash live adapter untested against real sandbox (idempotent callback handler ready)
- ffmpeg burned-in watermark is CSS-overlay in MVP; worker run_preview is structured to drop fluent-ffmpeg in
- Monthly plan 3-day reminder is stubbed (daily sweep present)
- Lighthouse not formally run but home is light (lazy videos, compressed posters)

---
Task ID: P1
Agent: orchestrator
Task: Phase 1 fundamental fixes (22 items)

Work Log:
- Group A (security): mock-callback locked to MOCK_MODE && !prod; random base32 order codes (DSA-XXXXXXXX); preview/generate requires signed customer token + phone-from-token + DB-transaction limit rechecks + rightmost X-Forwarded-For + DB-backed rate limits; namespaced customer/staff session secrets with timingSafeEqual + startup SESSION_SECRET validation; MOCK_MODE defaults false in prod + startup warning + no debug_otp in prod; orders/[id] requires customer token or staff session; storage/* HMAC-signed 7-day-expiring URLs + cuid-based keys
- Group B (missing endpoints): created POST /api/staff/order/[id]/upload (video+video15 for PREMIUM, EDITING/REVISION_REQUESTED, 1-in-5 QA, signed delivery link, {ok,qaFlag,has15}); GET /api/staff/editing-queue (editor/admin, EDITING+REVISION_REQUESTED); GET /api/admin/orders (all statuses with phone/product/payments/costs); revision routes back to same operator + editor queue; ADMIN_PHONE env var for alerts; Customer.planCredits + planExpiresAt, MONTHLY paid adds 4 credits + 30-day expiry, STANDARD order paid with 1 credit, daily sweep enqueues monthly_reminder + monthly_expire jobs, credits shown on account page
- Group C (pipeline correctness): SCRIPT_FAILED status + retry-script endpoint; shared lib/aiJson.ts (strip fences + zod validate) — unparseable moderation = REJECTED, script = retry once then SCRIPT_FAILED; operator rules — claimer-only on generate/regenerate/approve/qc, regen cap 3 per shot + admin unlock-regen, release-order endpoint; real ffmpeg watermark (fluent-ffmpeg + ffmpeg-static) burned into preview, unwatermarked deleted, CSS overlay kept as extra layer
- Group D (costs): lib/costs.ts reads configurable rates from admin settings (wan_cost_per_sec_usd, claude_*_per_m incl. opus-5-5, usd_to_bdt); aiService + regenerate use these; mock generations logged with configured rates
- Group E (deployment): schema.prisma switched to postgresql + migrations/0000_init; schema.local.prisma (sqlite) for sandbox testing; seed only when empty + no default admin password in prod; LOCAL_UPLOAD_DIR env var (no hardcoded paths); deleted Caddyfile/.zscripts/examples/tests/tool-results/agent-ctx/download/skills + root jpgs; removed z-ai-web-dev-sdk dependency; package.json scripts use npm + tsx (Node 20 compatible, no Bun required); Procfile uses npx/npm

Stage Summary:
- 22 items FIXED
- Golden path verified end-to-end in MOCK mode (20 passed, 0 failed): preview→order→mock pay→script→6 shots→QC→editor upload→DELIVERED→revision→REVISION_REQUESTED→re-deliver→DELIVERED, plus cost report + admin orders
- npm run lint clean; npm run build succeeds; npm start + npm run worker:once work with plain Node
- New env vars: SESSION_SECRET, ADMIN_PHONE, LOCAL_UPLOAD_DIR
- bKash adapter, Wan/DashScope request format, and real Claude API request code were NOT touched (per phase-1 rules)

---
Task ID: P1B
Agent: orchestrator
Task: Phase 1B fixes (5 items)

Work Log:
- Item 1: recreated src/app/api/staff/order/[id]/upload/route.ts (was missing from export) — accepts video+video15 (PREMIUM), EDITING/REVISION_REQUESTED, saves→DELIVERED, 1-in-5 QA, signed delivery SMS, returns {ok,qaFlag,has15}
- Item 2: added MANUAL_REVIEW status; worker moderation parse-fail → MANUAL_REVIEW (only clear allowed:false → REJECTED); admin gets Approve/Reject buttons via POST /api/admin/order/[id]/review; failJob now sets order SCRIPT_FAILED when a generate_script job goes DEAD (no order stays PAID/SCRIPTING after DEAD); generate_shot DEAD → shot FAILED
- Item 3: bundled Noto Sans Bold (OFL) at assets/fonts/NotoSans-Bold.ttf + LICENSE.txt; watermark.ts passes fontfile=, plain hyphen; prefers system ffmpeg (has drawtext) over ffmpeg-static (lacks it); on burn failure → preview FAILED, never delivers unwatermarked; proved burn works standalone (ffprobe: h264, valid MP4)
- Item 4: added Customer.previewUsed + previewRetryUsed to both schemas + migration 20250101000001_add_preview_limit_fields; /api/preview/generate claims previewUsed atomically via updateMany({where:{phone,previewUsed:false},data:{previewUsed:true}}), continues only if count===1; moderation rejection / generation failure resets it once via grantPreviewRetry (previewRetryUsed tracks the one-time reset)
- Item 5: start script → next start -p ${PORT:-3000}; tsx + prisma moved to dependencies; bun-types removed; deleted tool-results/ + db/custom.db; .gitignore updated (.env* ignored, !.env.example exception); .env untracked, .env.example tracked

Stage Summary:
- 5/5 items FIXED
- Golden path: 27 passed, 0 failed (preview watermark with fontfile burn, previewUsed limit, upload endpoint, revision re-deliver, admin orders, Railway config all verified)
- Lint clean; npm install works (deps reshuffled)
- Could NOT run the watermark inside a node:20-slim Docker container (no Docker available in sandbox); proved the burn works with the system ffmpeg + the bundled font via a standalone node script

---
Task ID: P1C
Agent: orchestrator
Task: Phase 1C fixes (5 items)

Work Log:
- Item 1: /api/orders/create now requires a valid customer token (readCustomerToken); phone comes ONLY from the token, never from the body. The order view logs the customer in by phone+OTP before submitting (reuses preview/start+verify with purpose=login); the brief stays filled in component state during the OTP step; returning customers with a matching session skip the OTP.
- Item 2: credit payment deducts atomically inside the order-create transaction with tx.customer.updateMany({where:{phone, planCredits:{gte:1}, planExpiresAt:{gt:new Date()}}, data:{planCredits:{decrement:1}}}); continues only if count===1. Concurrent orders can't double-spend.
- Item 3: added nixpacks.toml (aptPkgs: ffmpeg, fonts-dejavu-core, fontconfig); worker runs checkFfmpegDrawtext() at startup, sets FFMPEG_DRAWTEXT_OK; run_preview hard-fails new previews (status=FAILED + admin SMS) when the flag is false — never delivers unwatermarked. README section 6 explains how to confirm on Railway (worker log line + `ffmpeg -filters | grep drawtext`).
- Item 4: added Order.moderationOverride Boolean @default(false) to both schemas + migration 20250101000002_add_moderation_override. Admin "Approve and continue" sets it true. generate_script skips the entire moderation block when order.moderationOverride is true (logs "skipping moderation (admin override)").
- Item 5: added smsTemplates.orderRejected(code) in Bangla ("আপনার অর্ডার {code} গ্রহণ করা যায়নি। টাকা ফেরত দেওয়া হবে, আমরা শীঘ্রই যোগাযোগ করব।"). Admin reject now sends this proper template (the .replace() hack is gone). Worker also sends it on a clear moderation rejection.

Stage Summary:
- 5/5 items FIXED
- Golden path: 18 passed, 0 failed (token-required 401, login flow, token-only order body, atomic credit deduct 4→3, ffmpeg startup check, moderationOverride approve→persist, refund SMS proper Bangla template, nixpacks.toml)
- Lint clean; worker startup confirms ffmpegDrawtext=true
- bKash, Wan, and real Claude request code were NOT touched

---
Task ID: P2
Agent: Claude (Cowork) — built directly on the verified Phase 1C code
Task: Phase 2 — real integrations

Work Log:
- Payments: manual bKash QR (PAYMENT_MODE=manual_qr). Customer submits sender/TrxID/amount/screenshot → PAYMENT_SUBMITTED; TrxID unique in DB; max 3 real submissions/order/day; admin Payments tab confirm/reject-with-reason; shared atomic markOrderPaid (SLA starts at PAID, MONTHLY credits); bKash API route gated behind PAYMENT_MODE=bkash_api.
- Login: Firebase Phone Auth in production (client SDK + server verification of the ID token against Google's public keys with jose — no service account). Local/mock keeps OTP 123456. Limits pre-check runs before any SMS.
- AI: lib/llm.ts (DeepSeek OpenAI-compatible default, Anthropic optional, Qwen-VL vision fallback). Photo moderation (vision) for previews and paid orders. Unreachable AI → retry (orders) / free retry (previews); unreadable → MANUAL_REVIEW. No silent mock outside MOCK_MODE.
- Video: lib/wan.ts — Alibaba Wan 3.0 (video-synthesis + tasks) and Atlas Cloud adapters, content-policy refusals never retried, raw request/response saved on failure, output copied to storage immediately.
- Storage: Google Drive adapter (owner OAuth refresh token, drive.file scope), DreamStudioAds/orders/<CODE>/photos|shots|delivered, previews, settings; signed /api/storage URLs with HTTP Range; Wan gets absolute signed URLs.
- Notifications: Telegram admin alerts (payments, overdue, manual review, failed script/shot, daily 22:00 summary); staff one-tap WhatsApp messages; customer status timeline; SMS default none.
- Worker: concurrency (WORKER_CONCURRENCY, previews first), heartbeat, stuck-job recovery, overdue alerts, daily sweep by Dhaka date, test_wan job.
- Admin: Payments tab (badge), System tab (health + Test AI + Test Wan), bKash number/QR upload, AI price JSON, staff accounts (add/reset/remove; removal is immediate).
- Security fixes: staff password hashes no longer returned by any API; customer order view hides costs/operator/raw payment data; public content returns only public settings; demo staff + example testimonials seeded only outside production; placeholder phone numbers removed.
- Deploy: Dockerfile (ffmpeg + fonts) for both Railway services; env check skipped during `next build`; /api/health; new .env.example; README rewritten.
- Migration: 20260927000003_phase2_payments_drive.

Verification:
- tsc + eslint clean; production `next build` passes without runtime secrets.
- Migrations applied to real PostgreSQL 16; schema diff empty.
- End-to-end on PostgreSQL in mock mode: 49/49 checks (preview + watermark + range, QR submit/reject/resubmit/confirm, TrxID reuse blocked, double-confirm refused, script/shots/QC/upload/delivered, monthly credits, health, Test AI/Wan, staff add/remove, role checks).
- Real-mode against fake DeepSeek/Qwen/Wan servers: vision fallback to Qwen, JSON mode, Wan 3.0 body shape, Wan fetched the signed image URL, parallel shots, content-policy → FAILED without retry, Atlas adapter, Test AI model listing.
- Firebase: forged/garbage tokens rejected. Drive adapter logic tested with a stubbed Drive API (folders, single root under concurrency, read, range 206, delete).
- Not tested against live services: real Firebase SMS, real Google Drive, real DeepSeek/Wan accounts, Telegram (all verified from Admin → System after deploy).
