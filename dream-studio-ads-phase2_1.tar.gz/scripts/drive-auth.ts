// scripts/drive-auth.ts — one-time helper to get GOOGLE_REFRESH_TOKEN.
// Usage (on your own computer):
//   GOOGLE_CLIENT_ID=... GOOGLE_CLIENT_SECRET=... npm run drive:auth
// 1. Open the printed link, sign in with the Google account that owns the
//    5 TB Drive, and allow access.
// 2. The browser goes to http://localhost:53682/?code=... — this script is
//    listening there, catches the code and prints the refresh token.
// 3. Paste the token into Railway as GOOGLE_REFRESH_TOKEN.
import http from "http";
import { auth } from "@googleapis/drive";

const clientId = process.env.GOOGLE_CLIENT_ID;
const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
if (!clientId || !clientSecret) {
  console.error("Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET first (from Google Cloud → Credentials → your OAuth client).");
  process.exit(1);
}
const PORT = 53682;
const redirect = `http://localhost:${PORT}`;
const oauth = new auth.OAuth2(clientId, clientSecret, redirect);
const url = oauth.generateAuthUrl({
  access_type: "offline",
  prompt: "consent", // always return a refresh token
  scope: ["https://www.googleapis.com/auth/drive.file"],
});
console.log("\n1) Open this link and allow access:\n\n" + url + "\n\nWaiting for Google to send you back…");

const server = http.createServer(async (req, res) => {
  const code = new URL(req.url || "/", redirect).searchParams.get("code");
  if (!code) { res.end("No code in the URL."); return; }
  try {
    const { tokens } = await oauth.getToken(code);
    res.end("Done! Go back to the terminal and copy the refresh token.");
    console.log("\n2) Your GOOGLE_REFRESH_TOKEN (paste into Railway Variables):\n\n" + tokens.refresh_token + "\n");
    if (!tokens.refresh_token) console.log("No refresh token returned — remove the app at https://myaccount.google.com/permissions and run again.");
  } catch (e) {
    res.end("Failed: " + (e as Error).message);
    console.error(e);
  } finally {
    server.close();
  }
});
server.listen(PORT);
