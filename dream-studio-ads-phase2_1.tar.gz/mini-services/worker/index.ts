// mini-services/worker — DB-backed background job processor (Phase 2).
// Runs up to WORKER_CONCURRENCY jobs in parallel (free previews first, so a
// customer never waits behind a batch of order shots). Handlers:
//   generate_script, generate_shot, run_preview, send_sms, cleanup_previews,
//   monthly_reminder, monthly_expire, test_wan
// Also: heartbeat every 30 s (shown on /api/health), overdue alerts, a daily
// Telegram summary at 22:00 Dhaka, and the daily cleanup/monthly sweep.
import { PrismaClient } from "@prisma/client";
import { env } from "../../src/lib/env";
import { aiService, logCost } from "../../src/lib/aiService";
import { runWanToCompletion, WanError } from "../../src/lib/wan";
import { storage, generateStorageKey, absoluteSignedUrl, readStored, contentTypeFor } from "../../src/lib/storage";
import { sendSms, smsTemplates } from "../../src/lib/sms";
import { notifyAdmin } from "../../src/lib/notify";
import { burnWatermark, readFileBuffer, cleanupTemp } from "../../src/lib/watermark";
import type { LlmImage } from "../../src/lib/llm";
import { promises as fs } from "fs";
import path from "path";
import os from "os";
import { execSync } from "child_process";
import ffmpegStatic from "ffmpeg-static";

const prisma = new PrismaClient();
const WORKER_ID = `worker-${process.pid}-${Math.random().toString(36).slice(2, 6)}`;
const POLL_MS = 1500;
const CONCURRENCY = Math.max(1, env.workerConcurrency);
const ACTIVE_STATUSES = ["PAID", "SCRIPTING", "SCRIPT_READY", "GENERATING", "QC", "EDITING", "REVISION_REQUESTED", "SCRIPT_FAILED", "MANUAL_REVIEW"];

// ─── ffmpeg check (watermark needs drawtext) ────────────────
let FFMPEG_DRAWTEXT_OK = false;
function checkFfmpegDrawtext(): boolean {
  const candidates = ["ffmpeg"];
  if (ffmpegStatic) candidates.push(ffmpegStatic as unknown as string);
  for (const bin of candidates) {
    try {
      const filters = execSync(`"${bin}" -hide_banner -filters`, { stdio: ["ignore", "pipe", "ignore"] }).toString();
      if (filters.includes("drawtext")) {
        console.log(`[ffmpeg] drawtext available via ${bin}`);
        return true;
      }
    } catch { /* try next */ }
  }
  return false;
}

// ─── queue helpers ──────────────────────────────────────────
async function claimNext(preferType?: string) {
  const where = { status: "QUEUED", runAfter: { lte: new Date() }, ...(preferType ? { type: preferType } : {}) };
  const candidates = await prisma.job.findMany({ where, orderBy: { runAfter: "asc" }, take: 5 });
  for (const j of candidates) {
    const updated = await prisma.job.updateMany({
      where: { id: j.id, status: "QUEUED" },
      data: { status: "RUNNING", lockedBy: WORKER_ID, updatedAt: new Date() },
    });
    if (updated.count === 1) return prisma.job.findUnique({ where: { id: j.id } });
  }
  return null;
}

async function finishJob(id: string) {
  await prisma.job.update({ where: { id }, data: { status: "DONE", finishedAt: new Date() } });
}

class NoRetry extends Error {}

async function failJob(id: string, error: string, noRetry = false) {
  const j = await prisma.job.findUnique({ where: { id } });
  if (!j) return;
  const attempts = j.attempts + 1;
  if (noRetry || attempts >= j.maxAttempts) {
    await prisma.job.update({ where: { id }, data: { status: "DEAD", attempts, lastError: error.slice(0, 1000) } });
    await onJobDead(j.type, j.payloadJson, error);
  } else {
    const runAfter = new Date(Date.now() + 5000 * 2 ** attempts);
    await prisma.job.update({
      where: { id },
      data: { status: "QUEUED", attempts, lastError: error.slice(0, 1000), runAfter, lockedBy: null },
    });
  }
}

// No order or shot may stay "in progress" after its job is DEAD.
async function onJobDead(type: string, payloadJson: string, error: string) {
  let payload: any = {};
  try { payload = JSON.parse(payloadJson || "{}"); } catch { /* ignore */ }
  if (type === "generate_script" && payload.orderId) {
    const order = await prisma.order.findUnique({ where: { id: payload.orderId }, select: { status: true, code: true } });
    if (order && (order.status === "PAID" || order.status === "SCRIPTING")) {
      await prisma.order.update({ where: { id: payload.orderId }, data: { status: "SCRIPT_FAILED" } });
      await notifyAdmin(`⚠️ ${order.code}: script generation failed after retries. Open the staff dashboard and press "Retry script".\nError: ${error.slice(0, 300)}`);
    }
  } else if (type === "generate_shot" && payload.shotId) {
    const shot = await prisma.shot.update({ where: { id: payload.shotId }, data: { status: "FAILED" } }).catch(() => null);
    if (shot) {
      const order = await prisma.order.findUnique({ where: { id: shot.orderId }, select: { code: true } });
      await notifyAdmin(`⚠️ ${order?.code || shot.orderId}: shot #${shot.shotNo} failed to generate. The operator can edit the prompt and regenerate.\nError: ${error.slice(0, 300)}`);
    }
  } else if (type === "run_preview" && payload.previewId) {
    const p = await prisma.preview.update({ where: { id: payload.previewId }, data: { status: "FAILED" } }).catch(() => null);
    if (p) await grantPreviewRetry(p.customerPhone);
  }
}

// A failed free preview gives the phone exactly one more try.
async function grantPreviewRetry(phone: string) {
  await prisma.customer.updateMany({
    where: { phone, previewRetryUsed: 0, previewUsed: true },
    data: { previewUsed: false, previewRetryUsed: 1 },
  });
}

async function setSetting(key: string, value: string) {
  await prisma.setting.upsert({ where: { key }, update: { value }, create: { key, value } });
}
async function getSetting(key: string): Promise<string | null> {
  return (await prisma.setting.findUnique({ where: { key } }))?.value ?? null;
}

// ─── file helpers ───────────────────────────────────────────
async function downloadToTemp(url: string): Promise<string> {
  const tmp = path.join(os.tmpdir(), `dsa-${Date.now()}-${Math.random().toString(36).slice(2, 6)}.mp4`);
  if (url.startsWith("/samples/")) {
    await fs.copyFile(path.join(process.cwd(), "public", url), tmp);
    return tmp;
  }
  const r = await fetch(url, { signal: AbortSignal.timeout(120_000) });
  if (!r.ok) throw new Error(`download failed HTTP ${r.status}`);
  await fs.writeFile(tmp, Buffer.from(await r.arrayBuffer()));
  return tmp;
}

// Image URL Wan can fetch. Mock mode never calls Wan, so any string works.
async function imageUrlFor(key: string): Promise<string> {
  if (env.mockMode) return key;
  return absoluteSignedUrl(key, 3600);
}

async function photosAsImages(keys: string[], max = 3): Promise<LlmImage[]> {
  const out: LlmImage[] = [];
  for (const k of keys.slice(0, max)) {
    try {
      const buf = await readStored(k);
      if (buf.length > 4.5 * 1024 * 1024) continue; // keep requests small
      const mime = contentTypeFor(k).startsWith("image/") ? contentTypeFor(k) : "image/jpeg";
      out.push({ mime, base64: buf.toString("base64") });
    } catch (e) {
      console.error(`[photos] could not read ${k}`, (e as Error).message);
    }
  }
  return out;
}

// ─── handlers ───────────────────────────────────────────────
const handlers: Record<string, (payload: any) => Promise<void>> = {
  async send_sms({ phone, message }: { phone: string; message: string }) {
    await sendSms(phone, message);
  },

  async generate_script({ orderId, attempt = 0 }: { orderId: string; attempt?: number }) {
    const order = await prisma.order.findUnique({ where: { id: orderId }, include: { product: true } });
    if (!order) throw new NoRetry("order not found");
    if (order.status !== "PAID" && order.status !== "SCRIPTING") {
      throw new NoRetry(`order status ${order.status}, not PAID/SCRIPTING`);
    }
    const brief = JSON.parse(order.briefJson) as any;

    if (!order.moderationOverride) {
      const modInput = `productName=${brief.productName}; category=${brief.category}; cta=${brief.cta}; tone=${brief.tone}; language=${brief.language}; targetCustomer=${brief.targetCustomer}; priceOffer=${brief.priceOffer || ""}; notes=${brief.notes || ""}`;
      const images = await photosAsImages([...(brief.photos || []), ...(brief.logo ? [brief.logo] : [])]);
      const mod = await aiService.moderation(modInput, images);
      await logCost({ orderId, type: "llm_tokens", cost: mod.cost });
      if (mod.error && !mod.result) {
        // The AI call itself failed (network, key, outage) → retry the job.
        throw new Error(`moderation call failed: ${mod.error}`);
      }
      if (mod.parseFailed || !mod.result) {
        // The customer has paid: never auto-reject on unreadable output.
        await prisma.order.update({ where: { id: orderId }, data: { status: "MANUAL_REVIEW" } });
        await notifyAdmin(`🔎 ${order.code}: the safety check could not decide. Please review it in the staff dashboard (Approve and continue / Reject and refund).`);
        return;
      }
      if (!mod.result.allowed) {
        await prisma.order.update({ where: { id: orderId }, data: { status: "REJECTED" } });
        await notifyAdmin(`⛔ ${order.code} was rejected by the safety check: ${mod.result.reason_bn} (${mod.result.category}). The customer paid — arrange a refund.`);
        await prisma.job.create({
          data: { type: "send_sms", payloadJson: JSON.stringify({ phone: order.customerPhone, message: smsTemplates.orderRejected(order.code) }), status: "QUEUED" },
        });
        return;
      }
    }

    await prisma.order.update({ where: { id: orderId }, data: { status: "SCRIPTING" } });
    const briefText = JSON.stringify({
      productName: brief.productName, category: brief.category, tone: brief.tone, language: brief.language,
      cta: brief.cta, targetCustomer: brief.targetCustomer, priceOffer: brief.priceOffer, notes: brief.notes,
      phoneOrPage: brief.phoneOrPage, photos: (brief.photos || []).length, isPremium: order.product.code === "PREMIUM",
    });
    const { script, cost, parseFailed } = await aiService.generateScript(briefText);
    await logCost({ orderId, type: "llm_tokens", cost });
    if (parseFailed || !script) {
      if (attempt < 1) return handlers.generate_script({ orderId, attempt: attempt + 1 });
      await prisma.order.update({ where: { id: orderId }, data: { status: "SCRIPT_FAILED" } });
      await notifyAdmin(`⚠️ ${order.code}: the AI returned an unreadable script twice. Press "Retry script" in the staff dashboard.`);
      return;
    }
    await prisma.shot.deleteMany({ where: { orderId } });
    for (const shot of script.shots) {
      await prisma.shot.create({
        data: {
          orderId, shotNo: shot.shot_no, purpose: shot.purpose, prompt: shot.image_to_video_prompt,
          negativePrompt: shot.negative_prompt, camera: shot.camera, onScreenText: shot.on_screen_text,
          photoIndex: shot.which_product_photo, status: "PENDING",
        },
      });
    }
    await prisma.order.update({ where: { id: orderId }, data: { scriptJson: JSON.stringify(script), status: "SCRIPT_READY" } });
  },

  async generate_shot({ orderId, shotId }: { orderId: string; shotId: string }) {
    const order = await prisma.order.findUnique({ where: { id: orderId }, include: { shots: true } });
    if (!order) throw new NoRetry("order not found");
    const shot = order.shots.find((s) => s.id === shotId);
    if (!shot) throw new NoRetry("shot not found");
    const brief = JSON.parse(order.briefJson) as any;
    const photos: string[] = brief.photos || [];
    const photoKey = photos[Math.min(Math.max(0, shot.photoIndex), photos.length - 1)] || photos[0];
    if (!photoKey) throw new NoRetry("order has no photos");

    let result;
    try {
      result = await runWanToCompletion({
        imageUrl: await imageUrlFor(photoKey), prompt: shot.prompt,
        negativePrompt: shot.negativePrompt || undefined, durationSec: 5,
      });
    } catch (e) {
      if (e instanceof WanError && e.code === "content_policy") {
        await prisma.shot.update({ where: { id: shotId }, data: { status: "FAILED" } });
        await notifyAdmin(`⛔ ${order.code}: Wan refused shot #${shot.shotNo} (content policy). Edit the prompt and regenerate.\n${(e.raw || e.message).slice(0, 300)}`);
        throw new NoRetry(e.message);
      }
      throw e;
    }
    await logCost({ orderId, type: "wan_seconds", cost: result.cost });

    let storedKey: string;
    if (result.videoUrl.startsWith("/samples/")) {
      storedKey = result.videoUrl.replace(/^\//, "");
    } else {
      const tmp = await downloadToTemp(result.videoUrl); // Wan URLs expire — copy now
      try {
        const buf = await readFileBuffer(tmp);
        storedKey = (await storage.save(buf, generateStorageKey(`orders/${order.code}/shots`, `shot${shot.shotNo}.mp4`), "video/mp4")).key;
      } finally {
        await cleanupTemp(tmp);
      }
    }
    await prisma.shot.update({ where: { id: shotId }, data: { status: "READY", videoUrl: storedKey, taskExternalId: result.taskId } });
  },

  async run_preview({ previewId, prompt, negativePrompt }: { previewId: string; prompt: string; negativePrompt: string }) {
    const preview = await prisma.preview.findUnique({ where: { id: previewId } });
    if (!preview) throw new NoRetry("preview not found");
    if (!FFMPEG_DRAWTEXT_OK) {
      await notifyAdmin("🛑 FATAL: the worker cannot burn the preview watermark (ffmpeg drawtext missing). Free previews are failing. See README → Railway → ffmpeg.");
      throw new NoRetry("ffmpeg with drawtext filter is not available on this worker");
    }
    let result;
    try {
      result = await runWanToCompletion({ imageUrl: await imageUrlFor(preview.photoPath), prompt, negativePrompt, durationSec: 5 });
    } catch (e) {
      if (e instanceof WanError && e.code === "content_policy") throw new NoRetry(e.message);
      throw e;
    }
    await prisma.preview.update({ where: { id: previewId }, data: { costUsd: preview.costUsd + result.cost.usd } });
    await logCost({ type: "wan_seconds", cost: result.cost });

    // Download → burn watermark → store ONLY the watermarked file.
    const src = await downloadToTemp(result.videoUrl);
    let wmPath: string | null = null;
    try {
      const wm = await burnWatermark(src);
      wmPath = wm.path;
      const buf = await readFileBuffer(wmPath);
      const key = (await storage.save(buf, generateStorageKey("preview", "wm.mp4"), "video/mp4")).key;
      await prisma.preview.update({ where: { id: previewId }, data: { status: "READY", videoUrl: key } });
    } catch (e) {
      throw new Error(`watermark failed: ${(e as Error).message}`);
    } finally {
      await cleanupTemp(src);
      if (wmPath) await cleanupTemp(wmPath);
    }
  },

  // Admin "Test Wan": one 5 s generation from a sample product photo.
  async test_wan() {
    const t0 = Date.now();
    await setSetting("test_wan_result", JSON.stringify({ status: "RUNNING", at: new Date().toISOString() }));
    try {
      const img = await fs.readFile(path.join(process.cwd(), "public", "samples", "cosmetics.jpg"));
      const imgKey = (await storage.save(img, generateStorageKey("settings/tests", "jpg"), "image/jpeg")).key;
      const r = await runWanToCompletion({
        imageUrl: await imageUrlFor(imgKey),
        prompt: "Slow cinematic push-in on the cosmetic product on a dark plain background, soft studio key light, realistic, vertical 9:16, 16mm film grain",
        negativePrompt: "cartoon, blurry, text artifacts, watermark",
        durationSec: 5,
      });
      await logCost({ type: "wan_seconds", cost: { ...r.cost, detail: `test ${r.cost.detail}` } });
      let videoKey = r.videoUrl;
      if (!r.videoUrl.startsWith("/samples/")) {
        const tmp = await downloadToTemp(r.videoUrl);
        try {
          videoKey = (await storage.save(await readFileBuffer(tmp), generateStorageKey("settings/tests", "mp4"), "video/mp4")).key;
        } finally { await cleanupTemp(tmp); }
      }
      await setSetting("test_wan_result", JSON.stringify({ status: "OK", ms: Date.now() - t0, videoKey, costUsd: r.cost.usd, taskId: r.taskId, provider: env.wanProvider, model: env.wanModel, at: new Date().toISOString() }));
    } catch (e) {
      const raw = e instanceof WanError ? e.raw : undefined;
      await setSetting("test_wan_result", JSON.stringify({ status: "FAILED", ms: Date.now() - t0, error: (e as Error).message, raw, provider: env.wanProvider, model: env.wanModel, at: new Date().toISOString() }));
      throw new NoRetry((e as Error).message);
    }
  },

  async cleanup_previews() {
    const cutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const old = await prisma.preview.findMany({ where: { createdAt: { lt: cutoff } } });
    for (const p of old) {
      if (p.videoUrl && !p.videoUrl.startsWith("samples/")) await storage.delete(p.videoUrl).catch(() => {});
      if (p.photoPath) await storage.delete(p.photoPath).catch(() => {});
      await prisma.preview.delete({ where: { id: p.id } });
    }
    console.log(`[cleanup_previews] deleted ${old.length} old previews`);
  },

  async monthly_reminder({ customerPhone }: { customerPhone: string }) {
    await sendSms(customerPhone, smsTemplates.monthlyExpiring(customerPhone));
  },

  async monthly_expire({ customerId }: { customerId: string }) {
    await prisma.customer.update({ where: { id: customerId }, data: { planCredits: 0 } });
  },
};

// ─── job runner with concurrency ────────────────────────────
let running = 0;

async function runJob(job: NonNullable<Awaited<ReturnType<typeof claimNext>>>) {
  running++;
  const t0 = Date.now();
  try {
    const handler = handlers[job.type];
    if (!handler) throw new NoRetry(`no handler for ${job.type}`);
    await handler(JSON.parse(job.payloadJson));
    await finishJob(job.id);
    console.log(`[job] ${job.type} ${job.id} done in ${Date.now() - t0} ms`);
  } catch (e) {
    const msg = (e as Error)?.message || String(e);
    console.error(`[job] ${job.type} ${job.id} failed: ${msg}`);
    await failJob(job.id, msg, e instanceof NoRetry).catch((err) => console.error("failJob error", err));
  } finally {
    running--;
  }
}

async function fillSlots() {
  while (running < CONCURRENCY) {
    const job = (await claimNext("run_preview")) || (await claimNext());
    if (!job) return;
    void runJob(job);
  }
}

// Jobs left RUNNING by a crashed/redeployed worker go back to the queue.
async function recoverStuckJobs() {
  const cutoff = new Date(Date.now() - 15 * 60 * 1000);
  const r = await prisma.job.updateMany({
    where: { status: "RUNNING", updatedAt: { lt: cutoff } },
    data: { status: "QUEUED", lockedBy: null, runAfter: new Date() },
  });
  if (r.count) console.log(`[recover] re-queued ${r.count} stuck job(s)`);
}

// ─── periodic tasks ─────────────────────────────────────────
function dhakaNow() {
  const d = new Date(Date.now() + 6 * 60 * 60 * 1000);
  return { date: d.toISOString().slice(0, 10), hour: d.getUTCHours() };
}

async function heartbeat() {
  await setSetting("worker_heartbeat", JSON.stringify({ at: new Date().toISOString(), id: WORKER_ID, ffmpegDrawtext: FFMPEG_DRAWTEXT_OK, running, concurrency: CONCURRENCY, mock: env.mockMode }));
}

async function overdueAlerts() {
  const overdue = await prisma.order.findMany({
    where: { status: { in: ACTIVE_STATUSES }, slaDeadline: { lt: new Date() }, paidAt: { not: null } },
    select: { id: true, code: true, status: true },
    take: 50,
  });
  for (const o of overdue) {
    const flag = `alert:overdue:${o.id}`;
    if (await getSetting(flag)) continue;
    await setSetting(flag, new Date().toISOString());
    await notifyAdmin(`⏰ ${o.code} is past its delivery deadline (status: ${o.status}).`);
  }
}

async function dailySummaryIfDue() {
  const { date, hour } = dhakaNow();
  if (hour !== 22) return;
  if ((await getSetting("daily_summary_last")) === date) return;
  await setSetting("daily_summary_last", date);
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const paid = await prisma.order.findMany({ where: { paidAt: { gte: since } }, include: { product: true, payments: true } });
  const revenue = paid.reduce((s, o) => s + (o.payments.find((p) => p.status === "PAID")?.amount ?? 0), 0);
  const costAgg = await prisma.costLog.aggregate({ where: { createdAt: { gte: since } }, _sum: { bdtCost: true } });
  const cost = costAgg._sum.bdtCost || 0;
  const delivered = await prisma.order.count({ where: { deliveredAt: { gte: since } } });
  const previews = await prisma.preview.count({ where: { createdAt: { gte: since } } });
  const pendingPay = await prisma.order.count({ where: { status: "PAYMENT_SUBMITTED" } });
  const margin = revenue > 0 ? Math.round(((revenue - cost) / revenue) * 100) : 0;
  await notifyAdmin(
    `📊 Dream Studio — last 24 h (${date})\n` +
      `Paid orders: ${paid.length} · Delivered: ${delivered} · Free previews: ${previews}\n` +
      `Revenue: ৳${revenue.toLocaleString("en-US")} · AI cost: ৳${Math.round(cost).toLocaleString("en-US")} · Margin: ${margin}%\n` +
      `Payments waiting for your check: ${pendingPay}`
  );
}

async function dailySweepIfDue() {
  const { date } = dhakaNow();
  if ((await getSetting("daily_sweep_last")) === date) return;
  await setSetting("daily_sweep_last", date);
  await prisma.job.create({ data: { type: "cleanup_previews", payloadJson: "{}", status: "QUEUED" } });
  const now = new Date();
  const inThreeDays = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);
  const customers = await prisma.customer.findMany({ where: { planCredits: { gt: 0 }, planExpiresAt: { not: null } } });
  for (const c of customers) {
    if (!c.planExpiresAt) continue;
    if (c.planExpiresAt <= now) {
      await prisma.job.create({ data: { type: "monthly_expire", payloadJson: JSON.stringify({ customerId: c.id }), status: "QUEUED" } });
    } else if (c.planExpiresAt <= inThreeDays) {
      await prisma.job.create({ data: { type: "monthly_reminder", payloadJson: JSON.stringify({ customerPhone: c.phone }), status: "QUEUED" } });
    }
  }
}

async function periodic() {
  for (const fn of [heartbeat, overdueAlerts, dailySummaryIfDue, dailySweepIfDue, recoverStuckJobs]) {
    try { await fn(); } catch (e) { console.error(`[periodic] ${fn.name} failed`, e); }
  }
}

async function main() {
  FFMPEG_DRAWTEXT_OK = checkFfmpegDrawtext();
  if (!FFMPEG_DRAWTEXT_OK) {
    console.error("FATAL: ffmpeg with the drawtext filter is NOT available. Free previews will fail (an unwatermarked file is never delivered). See README → Railway → ffmpeg.");
  }
  console.log(`Worker ${WORKER_ID} started · mock=${env.mockMode} · concurrency=${CONCURRENCY} · storage=${storage.name} · wan=${env.wanProvider} · llm=${env.llmProvider} · ffmpegDrawtext=${FFMPEG_DRAWTEXT_OK}`);
  await periodic();
  setInterval(() => void periodic(), 30_000);
  while (true) {
    try { await fillSlots(); } catch (e) { console.error("[loop] error", e); }
    await new Promise((r) => setTimeout(r, POLL_MS));
  }
}

void main();
