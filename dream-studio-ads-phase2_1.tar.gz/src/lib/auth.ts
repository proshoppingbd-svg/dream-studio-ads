// lib/auth.ts — phone OTP + staff cookie sessions (lightweight, no NextAuth)
// Item 4: uses namespaced tokens (buildStaffSession / buildCustomerSession)
// so a staff token can never be replayed as a customer token.
import { db } from "@/lib/db";
import { env } from "@/lib/env";
import { cookies } from "next/headers";
import {
  generateOtp,
  hashPassword,
  verifyPassword,
  buildStaffSession,
  parseStaffSession,
  buildCustomerSession,
  parseCustomerSession,
} from "@/lib/crypto";

const SESSION_COOKIE = "dsa_staff";
const CUSTOMER_TOKEN_TYPE = "preview";

// ─── OTP ─────────────────────────────────────────────────────
export {
  generateOtp,
  hashPassword,
  verifyPassword,
  buildStaffSession,
  parseStaffSession,
  buildCustomerSession,
  parseCustomerSession,
};

export async function createOtp(phone: string, purpose = "login") {
  // Item 5: never use a fixed mock OTP in production. In dev/mock, the
  // code is returned to the caller for display; in prod a random 6-digit
  // code is generated and the caller MUST send it via the SMS adapter.
  const code = env.mockMode && !env.isProd ? "123456" : generateOtp();
  await db.otp.updateMany({
    where: { phone, purpose, consumed: false },
    data: { consumed: true },
  });
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000);
  return db.otp.create({
    data: { phone, code, purpose, expiresAt, attempts: 0, consumed: false },
  });
}

export async function verifyOtp(phone: string, code: string, purpose = "login") {
  const record = await db.otp.findFirst({
    where: { phone, purpose, consumed: false },
    orderBy: { createdAt: "desc" },
  });
  if (!record) return { ok: false, reason: "no_otp" };
  if (record.attempts >= 3) return { ok: false, reason: "max_attempts" };
  if (record.expiresAt < new Date()) return { ok: false, reason: "expired" };

  if (record.code !== code) {
    await db.otp.update({ where: { id: record.id }, data: { attempts: record.attempts + 1 } });
    return { ok: false, reason: "wrong_code" };
  }
  await db.otp.update({ where: { id: record.id }, data: { consumed: true } });
  return { ok: true };
}

// ─── Staff sessions (signed cookie) ──────────────────────────
export async function createStaffSession(staffId: string, email: string, role: string) {
  const value = buildStaffSession(staffId, email, role);
  const c = await cookies();
  c.set(SESSION_COOKIE, value, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 12,
  });
}

export async function getStaff(): Promise<{ id: string; email: string; role: string } | null> {
  const c = await cookies();
  const value = c.get(SESSION_COOKIE)?.value;
  if (!value) return null;
  const s = parseStaffSession(value);
  if (!s) return null;
  // The account must still exist; its CURRENT role is used (so removing or
  // demoting a staff member takes effect immediately).
  const user = await db.staffUser.findUnique({ where: { id: s.id }, select: { id: true, email: true, role: true } });
  return user;
}

export async function clearStaffSession() {
  const c = await cookies();
  c.delete(SESSION_COOKIE);
}

// ─── Customer (preview/account) tokens ────────────────────────
// Issued by /api/preview/verify; the phone is taken ONLY from the token
// on subsequent requests, never from the request body (Item 3).
export function issueCustomerToken(phone: string): string {
  return buildCustomerSession(phone);
}
export function readCustomerToken(token: string): { phone: string; role: string } | null {
  const s = parseCustomerSession(token);
  if (!s || s.role !== CUSTOMER_TOKEN_TYPE) return null;
  return { phone: s.email, role: s.role };
}
