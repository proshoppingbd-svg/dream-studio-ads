// lib/phoneAuth.ts — browser-side phone login (Phase 2).
// Production: Firebase Phone Auth sends the SMS code; our server verifies the
// Firebase ID token and issues its own customer token.
// Local/mock: the built-in OTP endpoints (code 123456 is shown on screen).
import { api } from "@/hooks/use-api";

export interface PublicConfig {
  authMode: "firebase" | "otp";
  firebase: { apiKey: string; authDomain: string; projectId: string; appId: string } | null;
  paymentMode: "manual_qr" | "bkash_api";
  bkashNumber: string;
  bkashQrUrl: string | null;
  whatsappNumber: string;
  mock: boolean;
}

let cfgPromise: Promise<PublicConfig> | null = null;
export function getPublicConfig(fresh = false): Promise<PublicConfig> {
  if (!cfgPromise || fresh) {
    cfgPromise = api<PublicConfig>("/api/public/config").catch((e) => {
      cfgPromise = null;
      throw e;
    });
  }
  return cfgPromise;
}

type Purpose = "preview" | "login";

// Firebase objects are loaded lazily so the home page stays light.
let confirmation: { confirm: (code: string) => Promise<{ user: { getIdToken: () => Promise<string> } }> } | null = null;
let verifier: { clear: () => void } | null = null;

const FIREBASE_ERRORS: Record<string, string> = {
  "auth/invalid-phone-number": "মোবাইল নম্বরটি সঠিক নয়।",
  "auth/too-many-requests": "অনেকবার চেষ্টা হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।",
  "auth/quota-exceeded": "আজ SMS পাঠানোর সীমা শেষ। পরে চেষ্টা করুন।",
  "auth/invalid-verification-code": "ভুল কোড। আবার চেষ্টা করুন।",
  "auth/code-expired": "কোডের মেয়াদ শেষ। নতুন কোড পাঠান।",
  "auth/captcha-check-failed": "যাচাই ব্যর্থ হয়েছে। পেজটি রিফ্রেশ করে আবার চেষ্টা করুন।",
  "auth/network-request-failed": "ইন্টারনেট সংযোগ দেখুন এবং আবার চেষ্টা করুন।",
};

function friendly(e: unknown): Error {
  const code = (e as { code?: string })?.code || "";
  return new Error(FIREBASE_ERRORS[code] || (e as Error)?.message || "কিছু একটা ভুল হয়েছে।");
}

async function firebaseAuth(cfg: PublicConfig) {
  const { initializeApp, getApps } = await import("firebase/app");
  const authMod = await import("firebase/auth");
  const app = getApps()[0] || initializeApp(cfg.firebase!);
  const auth = authMod.getAuth(app);
  auth.languageCode = "bn";
  return { auth, authMod };
}

// Sends the login code. Throws Error with a Bangla message, or an Error whose
// message is an API error code (e.g. "already_used_preview") from the pre-check.
export async function sendLoginCode(phone: string, opts: { purpose: Purpose; category?: string }): Promise<{ debugOtp?: string }> {
  const cfg = await getPublicConfig();
  if (cfg.authMode === "firebase") {
    // Limits first (so we never spend an SMS on a number that can't continue).
    await api("/api/preview/start", {
      method: "POST",
      body: JSON.stringify({ phone, category: opts.category, purpose: opts.purpose, precheck: true }),
    });
    const { auth, authMod } = await firebaseAuth(cfg);
    let holder = document.getElementById("dsa-recaptcha");
    if (!holder) {
      holder = document.createElement("div");
      holder.id = "dsa-recaptcha";
      document.body.appendChild(holder);
    }
    try {
      if (!verifier) verifier = new authMod.RecaptchaVerifier(auth, "dsa-recaptcha", { size: "invisible" });
      confirmation = await authMod.signInWithPhoneNumber(auth, "+88" + phone, verifier as never);
    } catch (e) {
      try { verifier?.clear(); } catch { /* ignore */ }
      verifier = null;
      throw friendly(e);
    }
    return {};
  }
  const r = await api<{ ok: boolean; debug_otp?: string }>("/api/preview/start", {
    method: "POST",
    body: JSON.stringify({ phone, category: opts.category, purpose: opts.purpose }),
  });
  return { debugOtp: r.debug_otp };
}

// Checks the code and returns our customer token.
export async function verifyLoginCode(phone: string, code: string, purpose: Purpose): Promise<string> {
  const cfg = await getPublicConfig();
  if (cfg.authMode === "firebase") {
    if (!confirmation) throw new Error("আগে কোড পাঠান।");
    let idToken: string;
    try {
      const cred = await confirmation.confirm(code);
      idToken = await cred.user.getIdToken();
    } catch (e) {
      throw friendly(e);
    }
    const r = await api<{ ok: boolean; token: string }>("/api/auth/firebase", {
      method: "POST",
      body: JSON.stringify({ idToken }),
    });
    confirmation = null;
    try {
      const { auth, authMod } = await firebaseAuth(cfg);
      await authMod.signOut(auth); // our own token is the session from here on
    } catch { /* ignore */ }
    return r.token;
  }
  const r = await api<{ ok: boolean; token: string }>("/api/preview/verify", {
    method: "POST",
    body: JSON.stringify({ phone, code, purpose }),
  });
  return r.token;
}
