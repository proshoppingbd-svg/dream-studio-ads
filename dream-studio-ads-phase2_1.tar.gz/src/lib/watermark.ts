// lib/watermark.ts — burn a diagonal "PREVIEW - DREAM STUDIO" watermark
// into a video with ffmpeg (Item 17 + Phase 1B Item 3).
// Item 3: uses a bundled Noto Sans Bold font (OFL) passed via fontfile=,
// and a plain hyphen (no em dash, which needs special escaping).
// Item 3: if the watermark burn fails, the caller marks the preview FAILED
// with the error logged — an unwatermarked file is NEVER delivered.
import ffmpeg from "fluent-ffmpeg";
import ffmpegStatic from "ffmpeg-static";
import { promises as fs } from "fs";
import path from "path";
import os from "os";

// Point fluent-ffmpeg at a binary that has the drawtext filter.
// The `ffmpeg-static` npm package ships a MINIMAL build without libfreetype,
// so drawtext (and therefore text watermarks) is unavailable. We prefer the
// system ffmpeg (which is compiled with freetype/fontconfig) and only fall
// back to ffmpeg-static when the system binary is missing.
import { execSync } from "child_process";
function pickFfmpegPath(): string {
  // 1. try the system ffmpeg on PATH — it has drawtext
  try {
    const ver = execSync("ffmpeg -version", { stdio: ["ignore", "pipe", "ignore"] }).toString();
    if (ver.toLowerCase().includes("ffmpeg")) {
      // confirm drawtext is available
      const filters = execSync("ffmpeg -filters", { stdio: ["ignore", "pipe", "ignore"] }).toString();
      if (filters.includes("drawtext")) return "ffmpeg";
    }
  } catch {
    // system ffmpeg not available — fall through
  }
  // 2. fall back to the static binary (drawtext may not work, but it's something)
  if (ffmpegStatic) return ffmpegStatic as unknown as string;
  return "ffmpeg";
}
ffmpeg.setFfmpegPath(pickFfmpegPath());

// Resolve the bundled Noto Sans Bold font. In dev this is at the repo root;
// in a Next.js standalone build it's copied alongside server.js.
function fontPath(): string {
  const candidates = [
    path.join(process.cwd(), "assets", "fonts", "NotoSans-Bold.ttf"),
    path.join(__dirname, "..", "..", "assets", "fonts", "NotoSans-Bold.ttf"),
    path.join(process.env.LOCAL_UPLOAD_DIR || "./upload", "..", "assets", "fonts", "NotoSans-Bold.ttf"),
  ];
  return candidates[0]!;
}

export interface WatermarkResult {
  path: string; // absolute path to the watermarked file
  size: number;
}

// Burn the watermark. Throws on any failure — the caller must catch and
// mark the preview FAILED (never deliver an unwatermarked file).
export async function burnWatermark(inputPath: string): Promise<WatermarkResult> {
  const outPath = path.join(os.tmpdir(), `dsa-wm-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.mp4`);
  const font = fontPath();
  // Item 3: fontfile= with the bundled Noto Sans Bold, plain hyphen.
  // The `angle` drawtext option requires a specific ffmpeg build; we omit
  // it for portability and keep the diagonal visual via the CSS overlay.
  // 30% opacity, large, centred.
  // Three stacked lines (hard to crop out), sized to fit a vertical video.
  const t = (text: string, size: string, y: string, alpha = "0.35") =>
    `drawtext=text='${text}':fontfile='${font}':fontcolor=white@${alpha}:borderw=2:bordercolor=black@0.25:fontsize=${size}:x=(w-tw)/2:y=${y}`;
  const drawtext = [
    t("PREVIEW", "(w/5)", "(h*0.22)"),
    t("DREAM STUDIO", "(w/10)", "(h-th)/2", "0.45"),
    t("PREVIEW", "(w/5)", "(h*0.70)"),
  ].join(",");

  await new Promise<void>((resolve, reject) => {
    ffmpeg(inputPath)
      .videoFilter(drawtext)
      .outputOptions(["-c:v", "libx264", "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-c:a", "aac"])
      .save(outPath)
      .on("end", () => resolve())
      .on("error", (err) => reject(new Error(`watermark burn failed: ${err.message}`)));
  });

  // verify the output exists and is non-empty
  const stat = await fs.stat(outPath);
  if (stat.size === 0) throw new Error("watermark burn produced an empty file");
  return { path: outPath, size: stat.size };
}

// Read a file's bytes into a Buffer
export async function readFileBuffer(p: string): Promise<Buffer> {
  return fs.readFile(p);
}

// Clean up a temp file
export async function cleanupTemp(p: string): Promise<void> {
  try { await fs.unlink(p); } catch {}
}
