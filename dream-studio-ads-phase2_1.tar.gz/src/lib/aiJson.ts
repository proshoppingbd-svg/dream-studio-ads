// lib/aiJson.ts — shared JSON parse helper (Item 15).
// Strips code fences, parses, and validates against a zod schema.
// On parse failure returns null (caller decides to retry / reject).
import { z, ZodSchema } from "zod";

export function stripCodeFences(text: string): string {
  return text
    .replace(/```json\s*/gi, "")
    .replace(/```\s*/g, "")
    .trim();
}

// Extract the first JSON object/array from a string that may contain prose.
export function extractJSON(text: string): string | null {
  const cleaned = stripCodeFences(text);
  // try direct parse first
  try {
    JSON.parse(cleaned);
    return cleaned;
  } catch {
    // fall through to extraction
  }
  // find the first { ... } or [ ... ] balanced block
  const start = cleaned.search(/[{[]/);
  if (start < 0) return null;
  const open = cleaned[start];
  const close = open === "{" ? "}" : "]";
  let depth = 0;
  let inStr = false;
  let esc = false;
  for (let i = start; i < cleaned.length; i++) {
    const ch = cleaned[i];
    if (esc) { esc = false; continue; }
    if (ch === "\\") { esc = true; continue; }
    if (ch === '"') { inStr = !inStr; continue; }
    if (inStr) continue;
    if (ch === open) depth++;
    else if (ch === close) {
      depth--;
      if (depth === 0) {
        const candidate = cleaned.slice(start, i + 1);
        try {
          JSON.parse(candidate);
          return candidate;
        } catch {
          return null;
        }
      }
    }
  }
  return null;
}

// Parse + validate. Returns null on any failure (never throws).
export function parseAIJson<T>(text: string, schema: ZodSchema<T>): T | null {
  const json = extractJSON(text);
  if (json === null) return null;
  let data: unknown;
  try {
    data = JSON.parse(json);
  } catch {
    return null;
  }
  const parsed = schema.safeParse(data);
  return parsed.success ? parsed.data : null;
}
