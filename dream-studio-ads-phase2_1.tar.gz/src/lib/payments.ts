// lib/payments.ts — shared "mark order PAID" logic (Phase 2).
// Used by the admin payment check (manual bKash QR), the admin "mark paid"
// button and the bKash API callback. The status change is atomic, so the
// same order can never be paid (or credited) twice.
import { db } from "@/lib/db";
import { enqueue } from "@/lib/queue";
import { slaDeadline } from "@/lib/status";
import { smsTemplates } from "@/lib/sms";

export async function markOrderPaid(opts: {
  orderId: string;
  fromStatuses: string[];
  paymentId?: string; // existing Payment row to mark PAID
  newPayment?: { provider: string; amount: number; trxId?: string; note?: string; raw?: string };
}): Promise<{ ok: true } | { ok: false; error: string }> {
  const order = await db.order.findUnique({ where: { id: opts.orderId }, include: { product: true } });
  if (!order) return { ok: false, error: "not_found" };

  const now = new Date();
  const result = await db.$transaction(async (tx) => {
    const moved = await tx.order.updateMany({
      where: { id: order.id, status: { in: opts.fromStatuses } },
      data: { status: "PAID", paidAt: now, slaDeadline: slaDeadline(order.product.deliverySla, now) },
    });
    if (moved.count !== 1) return false;
    if (opts.paymentId) {
      await tx.payment.update({ where: { id: opts.paymentId }, data: { status: "PAID" } });
    }
    if (opts.newPayment) {
      await tx.payment.create({
        data: {
          orderId: order.id,
          provider: opts.newPayment.provider,
          amount: opts.newPayment.amount,
          status: "PAID",
          trxId: opts.newPayment.trxId,
          manualNote: opts.newPayment.note,
          rawResponse: opts.newPayment.raw,
        },
      });
    }
    // Any other still-open payment rows for this order are closed.
    await tx.payment.updateMany({
      where: { orderId: order.id, status: { in: ["PENDING", "SUBMITTED"] }, ...(opts.paymentId ? { id: { not: opts.paymentId } } : {}) },
      data: { status: "FAILED" },
    });
    if (order.product.code === "MONTHLY") {
      await tx.customer.update({
        where: { phone: order.customerPhone },
        data: { planCredits: { increment: 4 }, planExpiresAt: new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000) },
      });
    }
    return true;
  });
  if (!result) return { ok: false, error: "wrong_status" };

  await enqueue("generate_script", { orderId: order.id });
  await enqueue("send_sms", { phone: order.customerPhone, message: smsTemplates.paymentReceived(order.code, order.product.priceBdt) });
  return { ok: true };
}
