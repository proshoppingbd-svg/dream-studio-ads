// lib/wan.ts — Wan image-to-video adapters (Phase 2).
//   WAN_PROVIDER=alibaba  → Alibaba Model Studio (Wan 3.0, async task API)
//   WAN_PROVIDER=atlas    → Atlas Cloud (generateVideo + prediction polling)
// Mock mode returns a sample clip so the whole pipeline runs without keys.
import { env } from "@/lib/env";
import { costFromWanSeconds } from "@/lib/costs";
import type { AiCost } from "@/lib/types";

export class WanError extends Error {
  code: "not_configured" | "content_policy" | "http_error";
  raw?: string;
  constructor(code: WanError["code"], message: string, raw?: string) {
    super(message);
    this.code = code;
    this.raw = raw;
  }
}

export type WanStatus = "PENDING" | "RUNNING" | "SUCCEEDED" | "FAILED";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const CONTENT_POLICY_RE = /DataInspection|content.?policy|sensitive|moderation|inappropriate|safety/i;

export function wanConfigured(): boolean {
  if (!env.wanKey) return false;
  return true;
}

function alibabaBase(): string {
  return env.wanBaseUrl || "https://dashscope-intl.aliyuncs.com";
}
function atlasBase(): string {
  return env.wanBaseUrl || "https://api.atlascloud.ai";
}

// Only 5 s or 10 s clips are used by the pipeline.
function clampDuration(d?: number): number {
  return d && d >= 10 ? 10 : 5;
}

async function request(url: string, init: RequestInit, attempts = 3): Promise<{ status: number; text: string }> {
  let last: { status: number; text: string } | null = null;
  for (let i = 0; i < attempts; i++) {
    try {
      const r = await fetch(url, { ...init, signal: AbortSignal.timeout(60_000) });
      const text = await r.text();
      if (r.status === 429 || r.status >= 500) {
        last = { status: r.status, text };
        await sleep(Math.min(2000 * 2 ** i, 15000));
        continue;
      }
      return { status: r.status, text };
    } catch (e) {
      last = { status: 0, text: String(e) };
      await sleep(Math.min(2000 * 2 ** i, 15000));
    }
  }
  return last!;
}

export async function submitWanJob(opts: {
  imageUrl: string; // must be publicly reachable (signed absolute URL)
  prompt: string;
  negativePrompt?: string;
  durationSec?: number;
}): Promise<{ taskId: string; cost: AiCost; raw?: string }> {
  const duration = clampDuration(opts.durationSec);
  const c = await costFromWanSeconds(duration);
  const cost: AiCost = { usd: c.usd, bdt: c.bdt, detail: `wan ${duration}s` };
  if (env.mockMode) {
    return { taskId: `mock-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, cost: { ...cost, detail: `mock-wan ${duration}s` } };
  }
  if (!wanConfigured()) throw new WanError("not_configured", "WAN_API_KEY is not set");

  // Wan 3.0 docs do not list a negative prompt field — fold it into the prompt.
  const prompt = opts.negativePrompt ? `${opts.prompt}\nAvoid: ${opts.negativePrompt}` : opts.prompt;

  if (env.wanProvider === "atlas") {
    let extra: Record<string, unknown> = {};
    try { extra = env.wanAtlasExtra ? JSON.parse(env.wanAtlasExtra) : {}; } catch { /* ignore */ }
    const body = { model: env.wanModel, prompt, image_url: opts.imageUrl, duration, ...extra };
    const r = await request(`${atlasBase()}/api/v1/model/generateVideo`, {
      method: "POST",
      headers: { authorization: `Bearer ${env.wanKey}`, "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    if (r.status < 200 || r.status >= 300) {
      if (CONTENT_POLICY_RE.test(r.text)) throw new WanError("content_policy", "Atlas rejected the content", r.text.slice(0, 1000));
      throw new WanError("http_error", `Atlas submit HTTP ${r.status}`, `REQUEST ${JSON.stringify({ ...body, image_url: "[signed url]" })}\nRESPONSE ${r.text.slice(0, 1000)}`);
    }
    const data = JSON.parse(r.text);
    const id = data?.data?.id;
    if (!id) throw new WanError("http_error", "Atlas returned no prediction id", r.text.slice(0, 1000));
    return { taskId: `atlas:${id}`, cost, raw: r.text.slice(0, 1000) };
  }

  // Alibaba Model Studio (Wan 3.0)
  const body = {
    model: env.wanModel,
    input: { prompt, media: [{ type: "first_frame", url: opts.imageUrl }] },
    parameters: { resolution: env.wanResolution, ratio: "adaptive", duration, prompt_extend: false },
  };
  const r = await request(`${alibabaBase()}/api/v1/services/aigc/video-generation/video-synthesis`, {
    method: "POST",
    headers: {
      authorization: `Bearer ${env.wanKey}`,
      "content-type": "application/json",
      "X-DashScope-Async": "enable",
    },
    body: JSON.stringify(body),
  });
  if (r.status < 200 || r.status >= 300) {
    if (CONTENT_POLICY_RE.test(r.text)) throw new WanError("content_policy", "Wan rejected the content", r.text.slice(0, 1000));
    const safeBody = { ...body, input: { ...body.input, media: [{ type: "first_frame", url: "[signed url]" }] } };
    throw new WanError("http_error", `Wan submit HTTP ${r.status}`, `REQUEST ${JSON.stringify(safeBody)}\nRESPONSE ${r.text.slice(0, 1000)}`);
  }
  const data = JSON.parse(r.text);
  const taskId = data?.output?.task_id;
  if (!taskId) throw new WanError("http_error", "Wan returned no task_id", r.text.slice(0, 1000));
  return { taskId: `ali:${taskId}`, cost, raw: r.text.slice(0, 1000) };
}

export async function pollWanTask(taskId: string): Promise<{ status: WanStatus; videoUrl?: string; error?: string; contentPolicy?: boolean; raw?: string }> {
  if (taskId.startsWith("mock-")) return { status: "SUCCEEDED", videoUrl: "/samples/mock-shot.mp4" };

  if (taskId.startsWith("atlas:")) {
    const id = taskId.slice(6);
    const r = await request(`${atlasBase()}/api/v1/model/prediction/${id}`, { headers: { authorization: `Bearer ${env.wanKey}` } });
    if (r.status < 200 || r.status >= 300) return { status: "RUNNING", raw: r.text.slice(0, 500) }; // transient; keep polling
    const d = JSON.parse(r.text)?.data || {};
    const st = String(d.status || "").toLowerCase();
    if (st === "completed" || st === "succeeded") {
      const out = Array.isArray(d.outputs) ? d.outputs[0] : undefined;
      return { status: "SUCCEEDED", videoUrl: typeof out === "string" ? out : out?.url, raw: r.text.slice(0, 500) };
    }
    if (st === "failed" || st === "canceled" || st === "cancelled") {
      const err = String(d.error || "failed");
      return { status: "FAILED", error: err, contentPolicy: CONTENT_POLICY_RE.test(err), raw: r.text.slice(0, 1000) };
    }
    return { status: "RUNNING" };
  }

  const id = taskId.replace(/^ali:/, "");
  const r = await request(`${alibabaBase()}/api/v1/tasks/${id}`, { headers: { authorization: `Bearer ${env.wanKey}` } });
  if (r.status < 200 || r.status >= 300) return { status: "RUNNING", raw: r.text.slice(0, 500) };
  const out = JSON.parse(r.text)?.output || {};
  const st = String(out.task_status || "");
  if (st === "SUCCEEDED" || st === "SUCCEED") return { status: "SUCCEEDED", videoUrl: out.video_url, raw: r.text.slice(0, 500) };
  if (st === "FAILED" || st === "CANCELED" || st === "UNKNOWN") {
    const err = `${out.code || ""} ${out.message || st}`.trim();
    return { status: "FAILED", error: err, contentPolicy: CONTENT_POLICY_RE.test(err), raw: r.text.slice(0, 1000) };
  }
  return { status: st === "PENDING" ? "PENDING" : "RUNNING" };
}

// Submit + poll until done (timeout 6 min). Used by the worker and "Test Wan".
export async function runWanToCompletion(opts: {
  imageUrl: string;
  prompt: string;
  negativePrompt?: string;
  durationSec?: number;
  timeoutMs?: number;
}): Promise<{ taskId: string; videoUrl: string; cost: AiCost; ms: number }> {
  const t0 = Date.now();
  const sub = await submitWanJob(opts);
  const timeout = opts.timeoutMs ?? 6 * 60 * 1000;
  while (Date.now() - t0 < timeout) {
    const p = await pollWanTask(sub.taskId);
    if (p.status === "SUCCEEDED") {
      if (!p.videoUrl) throw new WanError("http_error", "task succeeded but returned no video URL", p.raw);
      return { taskId: sub.taskId, videoUrl: p.videoUrl, cost: sub.cost, ms: Date.now() - t0 };
    }
    if (p.status === "FAILED") {
      throw new WanError(p.contentPolicy ? "content_policy" : "http_error", `Wan task failed: ${p.error || "unknown"}`, p.raw);
    }
    await sleep(sub.taskId.startsWith("mock-") ? 50 : 5000);
  }
  throw new WanError("http_error", "Wan task timed out after 6 minutes");
}
