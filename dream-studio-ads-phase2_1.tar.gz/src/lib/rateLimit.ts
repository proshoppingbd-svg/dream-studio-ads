// lib/rateLimit.ts — DB-backed sliding window limiter.
// Item 3: counters persist across restarts and work across multiple
// instances because they live in the RateLimit table, not memory.
// Item 3: client IP = rightmost X-Forwarded-For entry.
import { db } from "@/lib/db";

export async function rateLimit(
  key: string,
  max: number,
  windowMs: number
): Promise<{ ok: boolean; remaining: number; retryAfterMs: number }> {
  const now = Date.now();
  const windowStart = new Date(now - (now % windowMs));
  // upsert the bucket, increment atomically
  const row = await db.rateLimit.upsert({
    where: { bucket: key },
    update: {},
    create: { bucket: key, count: 0, windowStart },
  });
  // reset window if expired
  const rowStart = row.windowStart.getTime();
  const expired = now - rowStart >= windowMs;
  const newCount = expired ? 1 : row.count + 1;
  const updated = await db.rateLimit.update({
    where: { bucket: key },
    data: { count: newCount, windowStart: expired ? new Date(now) : row.windowStart },
  });
  const ok = updated.count <= max;
  return {
    ok,
    remaining: Math.max(0, max - updated.count),
    retryAfterMs: ok ? 0 : rowStart + windowMs - now,
  };
}

// In-memory fallback for hot paths (e.g. login brute force) used alongside
// the DB limiter; this is a thin second layer and is not authoritative.
const memStore = new Map<string, { count: number; windowStart: number }>();
if (typeof setInterval !== "undefined") {
  setInterval(() => {
    const now = Date.now();
    for (const [k, v] of memStore) {
      if (now - v.windowStart > 10 * 60 * 1000) memStore.delete(k);
    }
  }, 5 * 60 * 1000).unref?.();
}
export function rateLimitMem(key: string, max: number, windowMs: number): { ok: boolean; remaining: number; retryAfterMs: number } {
  const now = Date.now();
  let b = memStore.get(key);
  if (!b || now - b.windowStart > windowMs) {
    b = { count: 0, windowStart: now };
    memStore.set(key, b);
  }
  b.count += 1;
  const ok = b.count <= max;
  return { ok, remaining: Math.max(0, max - b.count), retryAfterMs: ok ? 0 : b.windowStart + windowMs - now };
}

// Item 3: client IP is the RIGHTMOST X-Forwarded-For entry (the one set by
// the trusted proxy closest to us). The leftmost is client-controlled and
// trivially spoofable. Falls back to X-Real-IP, then loopback.
export function getIp(req: Request): string {
  const xf = req.headers.get("x-forwarded-for");
  if (xf) {
    const parts = xf.split(",").map((s) => s.trim()).filter(Boolean);
    if (parts.length > 0) return parts[parts.length - 1]!;
  }
  const xr = req.headers.get("x-real-ip");
  if (xr) return xr.trim();
  return "127.0.0.1";
}
