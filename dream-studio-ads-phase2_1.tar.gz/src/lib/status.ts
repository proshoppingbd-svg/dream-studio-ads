// lib/status.ts — pure status helpers (client-safe, no server imports)
export const statusColor: Record<string, string> = {
  PENDING_PAYMENT: "bg-zinc-200 text-zinc-800",
  PAYMENT_SUBMITTED: "bg-sky-100 text-sky-800",
  PAID: "bg-blue-100 text-blue-800",
  SCRIPTING: "bg-amber-100 text-amber-800",
  SCRIPT_READY: "bg-amber-100 text-amber-800",
  SCRIPT_FAILED: "bg-red-200 text-red-900",
  MANUAL_REVIEW: "bg-yellow-200 text-yellow-900",
  GENERATING: "bg-purple-100 text-purple-800",
  QC: "bg-orange-100 text-orange-800",
  EDITING: "bg-violet-100 text-violet-800",
  DELIVERED: "bg-emerald-100 text-emerald-800",
  REVISION_REQUESTED: "bg-rose-100 text-rose-800",
  CLOSED: "bg-zinc-300 text-zinc-800",
  REJECTED: "bg-red-200 text-red-900",
  REFUNDED: "bg-red-100 text-red-800",
};

export const statusLabelBn: Record<string, string> = {
  PENDING_PAYMENT: "পেমেন্ট বাকি",
  PAYMENT_SUBMITTED: "পেমেন্ট যাচাই হচ্ছে",
  PAID: "পেমেন্ট হয়েছে",
  SCRIPTING: "স্ক্রিপ্ট লেখা হচ্ছে",
  SCRIPT_READY: "স্ক্রিপ্ট প্রস্তুত",
  SCRIPT_FAILED: "স্ক্রিপ্ট ব্যর্থ",
  MANUAL_REVIEW: "ম্যানুয়াল রিভিউ",
  GENERATING: "ভিডিও তৈরি হচ্ছে",
  QC: "যাচাই হচ্ছে",
  EDITING: "এডিট হচ্ছে",
  DELIVERED: "ডেলিভার হয়েছে",
  REVISION_REQUESTED: "রিভিশন চাওয়া হয়েছে",
  CLOSED: "বন্ধ",
  REJECTED: "প্রত্যাখ্যাত",
  REFUNDED: "রিফান্ড হয়েছে",
};

export function isOverdue(deadline: Date | null | undefined): boolean {
  if (!deadline) return false;
  return new Date(deadline).getTime() < Date.now();
}

// "1 min" → minutes, "48 h" → hours, "same day" → 24h
export function slaToMs(sla: string): number {
  if (sla.includes("min")) return parseInt(sla) * 60 * 1000;
  if (sla.includes("h")) return parseInt(sla) * 60 * 60 * 1000;
  if (sla.toLowerCase() === "same day") return 24 * 60 * 60 * 1000;
  return 48 * 60 * 60 * 1000;
}

export function slaDeadline(sla: string, from = new Date()): Date {
  return new Date(from.getTime() + slaToMs(sla));
}

// Customer-facing explanation for each status (order page timeline).
export const statusMessageBn: Record<string, string> = {
  PENDING_PAYMENT: "bKash-এ পেমেন্ট করে ট্রানজেকশন আইডি (TrxID) জমা দিন।",
  PAYMENT_SUBMITTED: "আপনার পেমেন্ট আমরা যাচাই করছি। সাধারণত ৩০ মিনিটের মধ্যে নিশ্চিত হয়।",
  PAID: "পেমেন্ট নিশ্চিত হয়েছে! আপনার বিজ্ঞাপনের কাজ শুরু হয়েছে।",
  SCRIPTING: "আপনার বিজ্ঞাপনের স্ক্রিপ্ট লেখা হচ্ছে।",
  SCRIPT_READY: "স্ক্রিপ্ট প্রস্তুত, এখন ভিডিও তৈরি শুরু হবে।",
  SCRIPT_FAILED: "স্ক্রিপ্টে একটু সমস্যা হয়েছে, আমাদের টিম ঠিক করছে।",
  MANUAL_REVIEW: "আমাদের টিম আপনার অর্ডারটি একবার দেখে নিচ্ছে।",
  GENERATING: "আপনার বিজ্ঞাপনের ভিডিও দৃশ্যগুলো তৈরি হচ্ছে।",
  QC: "মান যাচাই চলছে।",
  EDITING: "এডিটর আপনার বিজ্ঞাপন সাজাচ্ছেন।",
  DELIVERED: "আপনার বিজ্ঞাপন প্রস্তুত! নিচে দেখুন ও ডাউনলোড করুন।",
  REVISION_REQUESTED: "আপনার রিভিশন অনুরোধ পেয়েছি, কাজ চলছে।",
  CLOSED: "অর্ডার সম্পন্ন। ধন্যবাদ!",
  REJECTED: "দুঃখিত, অর্ডারটি গ্রহণ করা যায়নি। টাকা ফেরত দেওয়া হবে।",
  REFUNDED: "টাকা ফেরত দেওয়া হয়েছে।",
};

// Pre-written WhatsApp message staff send to the customer (one tap).
export function whatsappMessageBn(o: { code: string; status: string }, orderLink: string, reason?: string): string {
  switch (o.status) {
    case "PAID":
    case "SCRIPTING":
    case "SCRIPT_READY":
    case "GENERATING":
      return `আসসালামু আলাইকুম! আপনার অর্ডার ${o.code} এর পেমেন্ট নিশ্চিত হয়েছে। বিজ্ঞাপনের কাজ শুরু হয়েছে। অবস্থা দেখুন: ${orderLink}`;
    case "DELIVERED":
      return `আপনার বিজ্ঞাপন প্রস্তুত! অর্ডার ${o.code} — দেখুন ও ডাউনলোড করুন: ${orderLink} (কোনো পরিবর্তন লাগলে পেজ থেকে রিভিশন চাইতে পারবেন)`;
    case "REVISION_REQUESTED":
    case "EDITING":
      return `আপনার অর্ডার ${o.code} এর কাজ চলছে। প্রস্তুত হলেই জানাব। ${orderLink}`;
    case "PENDING_PAYMENT":
      return reason
        ? `আপনার অর্ডার ${o.code} এর পেমেন্ট নিশ্চিত করা যায়নি: ${reason}। অনুগ্রহ করে আবার জমা দিন: ${orderLink}`
        : `আপনার অর্ডার ${o.code} এর পেমেন্ট এখনো বাকি। পেমেন্ট করতে: ${orderLink}`;
    case "REJECTED":
      return `দুঃখিত, অর্ডার ${o.code} গ্রহণ করা যায়নি। আপনার টাকা ফেরত দেওয়া হবে, আমরা শীঘ্রই যোগাযোগ করব।`;
    default:
      return `আপনার অর্ডার ${o.code} এর আপডেট দেখুন: ${orderLink}`;
  }
}

export function whatsappLink(phone: string, text: string): string {
  const num = phone.replace(/\D/g, "").replace(/^0/, "880").replace(/^(?!880)/, "880");
  return `https://wa.me/${num}?text=${encodeURIComponent(text)}`;
}
