// lib/orders.ts — server-only order helpers (uses storage). Pure status
// helpers live in lib/status.ts (client-safe).
import crypto from "crypto";
import { db } from "@/lib/db";
import { storage } from "@/lib/storage";

// re-export pure helpers for server code that imports from here
export { statusColor, statusLabelBn, isOverdue, slaToMs, slaDeadline } from "@/lib/status";

// Item 2: random, non-guessable order codes.
// Format: DSA-XXXXXXXX where X = 8 random uppercase base32 chars.
// Retries until unique (collision is astronomically unlikely).
const BASE32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"; // RFC 4648 base32 alphabet, no lowercase
export function randomOrderCodeSuffix(len = 8): string {
  const bytes = crypto.randomBytes(len);
  let out = "";
  for (let i = 0; i < len; i++) out += BASE32[bytes[i]! % 32];
  return out;
}
export async function generateOrderCode(): Promise<string> {
  for (let attempt = 0; attempt < 5; attempt++) {
    const candidate = `DSA-${randomOrderCodeSuffix(8)}`;
    const exists = await db.order.findUnique({ where: { code: candidate }, select: { id: true } });
    if (!exists) return candidate;
  }
  // extremely unlikely fallback
  return `DSA-${randomOrderCodeSuffix(12)}`;
}

// Resolve a stored video URL to a playable URL. Mock/sample videos live in
// /public and are served directly; real uploads go through storage.signedUrl.
export async function resolveVideoUrl(url: string | null): Promise<string | null> {
  if (!url) return null;
  if (url.startsWith("/samples/") || url.startsWith("samples/")) {
    return url.startsWith("/") ? url : "/" + url;
  }
  return storage.signedUrl(url);
}
