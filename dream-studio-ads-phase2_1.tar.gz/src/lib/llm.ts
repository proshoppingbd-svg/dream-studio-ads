// lib/llm.ts — one entry point for text + vision LLM calls (Phase 2).
// Providers:
//   deepseek  — OpenAI-compatible /chat/completions (default)
//   anthropic — Claude Messages API (kept as an option)
//   qwen      — Alibaba Qwen-VL via the OpenAI-compatible endpoint (vision fallback)
// Retries transient errors (network, 429, 5xx) with backoff. Never retries
// other 4xx errors. Throws LlmError with a machine-readable code.
import { env } from "@/lib/env";

export type LlmProvider = "deepseek" | "anthropic" | "qwen";

export interface LlmImage {
  mime: string; // image/jpeg | image/png | image/webp
  base64: string; // raw base64, no data: prefix
}

export interface LlmResult {
  text: string;
  inputTokens: number;
  outputTokens: number;
  cacheHitTokens: number;
  model: string;
  provider: LlmProvider;
}

export class LlmError extends Error {
  code: "not_configured" | "vision_unsupported" | "http_error" | "network" | "bad_response";
  status?: number;
  body?: string;
  constructor(code: LlmError["code"], message: string, status?: number, body?: string) {
    super(message);
    this.code = code;
    this.status = status;
    this.body = body;
  }
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function looksLikeVisionUnsupported(status: number, body: string): boolean {
  if (status !== 400 && status !== 422) return false;
  return /image|vision|multimodal|image_url|unknown variant|not support/i.test(body);
}

async function postJson(url: string, headers: Record<string, string>, body: unknown, attempts = 3): Promise<any> {
  let lastErr: unknown;
  for (let i = 0; i < attempts; i++) {
    let res: Response;
    try {
      res = await fetch(url, {
        method: "POST",
        headers: { "content-type": "application/json", ...headers },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(120_000),
      });
    } catch (e) {
      lastErr = new LlmError("network", `network error: ${String(e)}`);
      await sleep(Math.min(1000 * 2 ** i, 8000));
      continue;
    }
    const text = await res.text();
    if (res.ok) {
      try {
        return JSON.parse(text);
      } catch {
        throw new LlmError("bad_response", "provider returned non-JSON", res.status, text.slice(0, 500));
      }
    }
    if (res.status === 429 || res.status >= 500) {
      lastErr = new LlmError("http_error", `HTTP ${res.status}`, res.status, text.slice(0, 500));
      await sleep(Math.min(1500 * 2 ** i, 10000));
      continue;
    }
    if (looksLikeVisionUnsupported(res.status, text)) {
      throw new LlmError("vision_unsupported", "model does not accept images", res.status, text.slice(0, 500));
    }
    throw new LlmError("http_error", `HTTP ${res.status}: ${text.slice(0, 200)}`, res.status, text.slice(0, 500));
  }
  throw lastErr;
}

// ─── OpenAI-compatible (DeepSeek, Qwen) ─────────────────────
async function callOpenAICompat(opts: {
  provider: "deepseek" | "qwen";
  system: string;
  user: string;
  model: string;
  json: boolean;
  images?: LlmImage[];
  maxTokens: number;
}): Promise<LlmResult> {
  const baseUrl = opts.provider === "deepseek" ? env.deepseekBaseUrl : env.qwenBaseUrl;
  const key = opts.provider === "deepseek" ? env.deepseekKey : env.qwenKey;
  if (!key) throw new LlmError("not_configured", `${opts.provider} API key missing`);
  const userContent =
    opts.images && opts.images.length
      ? [
          { type: "text", text: opts.user },
          ...opts.images.map((im) => ({
            type: "image_url",
            image_url: { url: `data:${im.mime};base64,${im.base64}` },
          })),
        ]
      : opts.user;
  const body: Record<string, unknown> = {
    model: opts.model,
    max_tokens: opts.maxTokens,
    messages: [
      { role: "system", content: opts.system },
      { role: "user", content: userContent },
    ],
  };
  // JSON mode (DeepSeek supports it; Qwen-VL gets plain text + our parser)
  if (opts.json && opts.provider === "deepseek") body.response_format = { type: "json_object" };
  const data = await postJson(`${baseUrl}/chat/completions`, { authorization: `Bearer ${key}` }, body);
  const text: string = data?.choices?.[0]?.message?.content ?? "";
  if (!text) throw new LlmError("bad_response", "empty completion", 200, JSON.stringify(data).slice(0, 500));
  const u = data?.usage || {};
  return {
    text,
    inputTokens: Number(u.prompt_tokens || 0),
    outputTokens: Number(u.completion_tokens || 0),
    cacheHitTokens: Number(u.prompt_cache_hit_tokens || 0),
    model: opts.model,
    provider: opts.provider,
  };
}

// ─── Anthropic Messages API ─────────────────────────────────
async function callAnthropic(opts: {
  system: string;
  user: string;
  model: string;
  images?: LlmImage[];
  maxTokens: number;
}): Promise<LlmResult> {
  if (!env.anthropicKey) throw new LlmError("not_configured", "ANTHROPIC_API_KEY missing");
  const content =
    opts.images && opts.images.length
      ? [
          ...opts.images.map((im) => ({
            type: "image",
            source: { type: "base64", media_type: im.mime, data: im.base64 },
          })),
          { type: "text", text: opts.user },
        ]
      : opts.user;
  const data = await postJson(
    "https://api.anthropic.com/v1/messages",
    { "x-api-key": env.anthropicKey, "anthropic-version": "2023-06-01" },
    { model: opts.model, max_tokens: opts.maxTokens, system: opts.system, messages: [{ role: "user", content }] }
  );
  const text = (data?.content || []).map((c: { text?: string }) => c.text || "").join("");
  if (!text) throw new LlmError("bad_response", "empty completion", 200, JSON.stringify(data).slice(0, 500));
  return {
    text,
    inputTokens: Number(data?.usage?.input_tokens || 0),
    outputTokens: Number(data?.usage?.output_tokens || 0),
    cacheHitTokens: Number(data?.usage?.cache_read_input_tokens || 0),
    model: opts.model,
    provider: "anthropic",
  };
}

// ─── Public API ──────────────────────────────────────────────
export type ModelRole = "heavy" | "light" | "vision";

export function modelFor(role: ModelRole): string {
  if (role === "heavy") return env.llmModelHeavy;
  if (role === "light") return env.llmModelLight;
  return env.llmModelVision || env.llmModelLight;
}

export function llmConfigured(): boolean {
  const keyOk = env.llmProvider === "anthropic" ? !!env.anthropicKey : !!env.deepseekKey;
  return keyOk && !!env.llmModelHeavy && !!env.llmModelLight;
}

export async function callLLM(opts: {
  role: ModelRole;
  system: string;
  user: string;
  json?: boolean;
  images?: LlmImage[];
  maxTokens?: number;
  provider?: LlmProvider; // override (used for the Qwen vision fallback)
}): Promise<LlmResult> {
  const provider: LlmProvider = opts.provider || env.llmProvider;
  const maxTokens = opts.maxTokens ?? 2048;
  if (provider === "qwen") {
    return callOpenAICompat({
      provider: "qwen", system: opts.system, user: opts.user, model: env.qwenVlModel,
      json: !!opts.json, images: opts.images, maxTokens,
    });
  }
  const model = modelFor(opts.role);
  if (!model) throw new LlmError("not_configured", `LLM model for role "${opts.role}" is not set`);
  if (provider === "anthropic") {
    return callAnthropic({ system: opts.system, user: opts.user, model, images: opts.images, maxTokens });
  }
  return callOpenAICompat({
    provider: "deepseek", system: opts.system, user: opts.user, model,
    json: !!opts.json, images: opts.images, maxTokens,
  });
}

// List the model IDs this key can use (OpenAI-compatible GET /models).
export async function listModels(): Promise<string[]> {
  if (env.llmProvider === "anthropic") {
    if (!env.anthropicKey) throw new LlmError("not_configured", "ANTHROPIC_API_KEY missing");
    const r = await fetch("https://api.anthropic.com/v1/models", {
      headers: { "x-api-key": env.anthropicKey, "anthropic-version": "2023-06-01" },
    });
    const d = await r.json();
    return (d?.data || []).map((m: { id: string }) => m.id);
  }
  if (!env.deepseekKey) throw new LlmError("not_configured", "DEEPSEEK_API_KEY missing");
  const r = await fetch(`${env.deepseekBaseUrl}/models`, { headers: { authorization: `Bearer ${env.deepseekKey}` } });
  const d = await r.json();
  return (d?.data || []).map((m: { id: string }) => m.id);
}

// Convert a data: URL to an LlmImage (returns null if not an image data URL).
export function dataUrlToImage(dataUrl: string): LlmImage | null {
  const m = dataUrl.match(/^data:(image\/[\w+.-]+);base64,(.+)$/);
  if (!m) return null;
  return { mime: m[1]!, base64: m[2]! };
}
