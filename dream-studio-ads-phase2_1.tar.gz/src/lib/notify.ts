// lib/notify.ts — admin alerts via a Telegram bot (Phase 2).
// Replaces every ADMIN_PHONE SMS. Never throws: an alert failure must not
// break an order. In mock mode (or without a bot token) alerts are logged.
import { env } from "@/lib/env";

export async function notifyAdmin(text: string): Promise<boolean> {
  const token = env.telegramBotToken;
  const chat = env.telegramChatId;
  if (!token || !chat) {
    console.log(`[admin-alert] ${text}`);
    return false;
  }
  try {
    const r = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ chat_id: chat, text: text.slice(0, 4000), disable_web_page_preview: true }),
    });
    if (!r.ok) console.error(`[admin-alert] telegram ${r.status}: ${(await r.text()).slice(0, 200)}`);
    return r.ok;
  } catch (e) {
    console.error("[admin-alert] telegram failed", e);
    return false;
  }
}

export function adminOrderLink(orderId: string): string {
  return `${env.appUrl}/#/staff`;
}
