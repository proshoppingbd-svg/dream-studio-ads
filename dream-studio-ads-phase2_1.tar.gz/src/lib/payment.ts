// lib/payment.ts — PaymentProvider with bkash + mock adapters
import { env } from "@/lib/env";

export interface PaymentProvider {
  name: string;
  createPayment(opts: { amount: number; merchantInvoice: string; callbackUrl: string; ref: string }): Promise<{
    paymentId: string;
    payUrl: string;
    raw?: string;
  }>;
  executePayment(paymentId: string): Promise<{ trxId: string; raw: string }>;
  verifyPayment(paymentId: string, trxId: string): Promise<{ paid: boolean; raw: string }>;
}

// ─── mock ───────────────────────────────────────────────────
class MockPayment implements PaymentProvider {
  name = "mock";
  async createPayment(opts: { amount: number; merchantInvoice: string }) {
    const paymentId = `mock-pay-${Date.now()}`;
    // payUrl is a same-origin page that auto-executes
    return {
      paymentId,
      payUrl: `/api/payment/mock-callback?pid=${paymentId}&invoice=${opts.merchantInvoice}&amount=${opts.amount}`,
    };
  }
  async executePayment(_paymentId: string) {
    return { trxId: `MOCK${Date.now()}`, raw: JSON.stringify({ status: "paid" }) };
  }
  async verifyPayment(_paymentId: string, _trxId: string) {
    return { paid: true, raw: JSON.stringify({ status: "paid" }) };
  }
}

// ─── bKash Tokenized Checkout ────────────────────────────────
class BkashPayment implements PaymentProvider {
  name = env.bkashMode === "live" ? "bkash-live" : "bkash-sandbox";
  private base =
    env.bkashMode === "live"
      ? "https://tokenized.pay.bka.sh/v1.2.0"
      : "https://tokenized.sandbox.bka.sh/v1.2.0";

  private async getToken(): Promise<string> {
    const r = await fetch(`${this.base}/token/grant`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        username: env.bkashUsername,
        password: env.bkashPassword,
      },
      body: JSON.stringify({
        app_key: env.bkashAppKey,
        app_secret: env.bkashAppSecret,
      }),
    });
    const data = (await r.json()) as { id_token: string };
    return data.id_token;
  }

  async createPayment(opts: { amount: number; merchantInvoice: string; callbackUrl: string }) {
    const token = await this.getToken();
    const r = await fetch(`${this.base}/create`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        authorization: token,
        "x-app-key": env.bkashAppKey,
      },
      body: JSON.stringify({
        mode: "0011",
        amount: String(opts.amount),
        currency: "BDT",
        callbackURL: opts.callbackUrl,
        merchantInvoiceNumber: opts.merchantInvoice,
      }),
    });
    const data = (await r.json()) as { paymentID: string; bkashURL: string };
    return {
      paymentId: data.paymentID,
      payUrl: data.bkashURL,
      raw: JSON.stringify(data),
    };
  }

  async executePayment(paymentId: string) {
    const token = await this.getToken();
    const r = await fetch(`${this.base}/execute`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        authorization: token,
        "x-app-key": env.bkashAppKey,
      },
      body: JSON.stringify({ paymentID: paymentId }),
    });
    const data = (await r.json()) as { trxID: string };
    return { trxId: data.trxID, raw: JSON.stringify(data) };
  }

  async verifyPayment(paymentId: string, _trxId: string) {
    const token = await this.getToken();
    const r = await fetch(`${this.base}/payment/status`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        authorization: token,
        "x-app-key": env.bkashAppKey,
      },
      body: JSON.stringify({ paymentID: paymentId }),
    });
    const data = (await r.json()) as { transactionStatus: string };
    return { paid: data.transactionStatus === "Completed", raw: JSON.stringify(data) };
  }
}

export function getPaymentProvider(): PaymentProvider {
  if (!env.mockMode && env.bkashAppKey && env.bkashAppSecret && env.bkashUsername && env.bkashPassword) {
    return new BkashPayment();
  }
  return new MockPayment();
}

export const paymentProvider = getPaymentProvider();
