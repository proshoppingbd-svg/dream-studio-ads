// lib/queue.ts — DB-backed job queue. The worker mini-service polls
// `Job` rows in QUEUED state, locks them (lockedBy), runs handlers.
import { db } from "@/lib/db";

export async function enqueue(type: string, payload: unknown, runAfter?: Date) {
  return db.job.create({
    data: {
      type,
      payloadJson: JSON.stringify(payload),
      status: "QUEUED",
      runAfter: runAfter ?? new Date(),
    },
  });
}

export async function claimNextJob(workerId: string) {
  // claim the oldest runnable job atomically-ish
  const jobs = await db.job.findMany({
    where: {
      status: "QUEUED",
      runAfter: { lte: new Date() },
    },
    orderBy: { runAfter: "asc" },
    take: 1,
  });
  if (jobs.length === 0) return null;
  const j = jobs[0]!;
  const updated = await db.job.updateMany({
    where: { id: j.id, status: "QUEUED" },
    data: { status: "RUNNING", lockedBy: workerId, updatedAt: new Date() },
  });
  if (updated.count === 0) return null;
  return db.job.findUnique({ where: { id: j.id } });
}

export async function finishJob(id: string) {
  await db.job.update({
    where: { id },
    data: { status: "DONE", finishedAt: new Date() },
  });
}

export async function failJob(id: string, error: string) {
  const j = await db.job.findUnique({ where: { id } });
  if (!j) return;
  const attempts = j.attempts + 1;
  if (attempts >= j.maxAttempts) {
    await db.job.update({
      where: { id },
      data: { status: "DEAD", attempts, lastError: error.slice(0, 500) },
    });
  } else {
    // requeue with backoff
    const runAfter = new Date(Date.now() + 1000 * 2 ** attempts);
    await db.job.update({
      where: { id },
      data: { status: "QUEUED", attempts, lastError: error.slice(0, 500), runAfter, lockedBy: null },
    });
  }
}
