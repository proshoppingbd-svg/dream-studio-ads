// lib/env.ts — centralised env access with MOCK detection
// Reads once at module load. Validates SESSION_SECRET in production.

const isProd = process.env.NODE_ENV === "production";

function bool(key: string, fallback = false): boolean {
  const v = process.env[key];
  if (v === undefined) return fallback;
  return v === "true" || v === "1" || v === "TRUE";
}

// Item 5: MOCK_MODE defaults to false in production, true in dev.
const MOCK_MODE = bool("MOCK_MODE", !isProd);

// Item 5: warn loudly at startup whenever mock mode is on.
if (MOCK_MODE && typeof console !== "undefined") {
  console.warn(
    [
      "",
      "╔════════════════════════════════════════════════════════════════",
      "║ ⚠️  MOCK MODE IS ON ⚠️",
      "║ All AI, SMS, payment and storage calls are faked.",
      "║ NEVER deploy MOCK_MODE=true to production.",
      "║ Set MOCK_MODE=false and provide real API keys before going live.",
      "╚════════════════════════════════════════════════════════════════",
      "",
    ].join("\n")
  );
}

// Item 4: SESSION_SECRET must be ≥32 chars in production.
const SESSION_SECRET = process.env.SESSION_SECRET || "";
// Not checked while `next build` runs (Railway builds the Docker image
// without runtime variables); the running server and worker still refuse
// to start without it.
const isBuildPhase = process.env.NEXT_PHASE === "phase-production-build";
if (isProd && !isBuildPhase && SESSION_SECRET.length < 32) {
  // crash at startup with a clear error
  throw new Error(
    "FATAL: SESSION_SECRET is missing or shorter than 32 characters. " +
      "Generate one with `openssl rand -hex 48` and set it as the SESSION_SECRET env var."
  );
}

function int(key: string, fallback: number): number {
  const v = Number(process.env[key]);
  return Number.isFinite(v) && v > 0 ? v : fallback;
}

function str(key: string, fallback = ""): string {
  return (process.env[key] || fallback).trim();
}

export const env = {
  isProd,
  mockMode: MOCK_MODE,
  appUrl: str("APP_URL", "http://localhost:3000").replace(/\/$/, ""),

  // ── Script + safety AI (Phase 2: DeepSeek default, Anthropic optional) ──
  llmProvider: str("LLM_PROVIDER", "deepseek") as "deepseek" | "anthropic",
  deepseekKey: str("DEEPSEEK_API_KEY"),
  deepseekBaseUrl: str("DEEPSEEK_BASE_URL", "https://api.deepseek.com").replace(/\/$/, ""),
  anthropicKey: str("ANTHROPIC_API_KEY"),
  llmModelHeavy: str("LLM_MODEL_HEAVY"),   // script writing
  llmModelLight: str("LLM_MODEL_LIGHT"),   // moderation + preview prompt
  llmModelVision: str("LLM_MODEL_VISION"), // photo moderation (defaults to light)
  visionProvider: str("VISION_PROVIDER", "llm") as "llm" | "qwen",
  qwenBaseUrl: str("QWEN_BASE_URL", "https://dashscope-intl.aliyuncs.com/compatible-mode/v1").replace(/\/$/, ""),
  qwenKey: str("QWEN_API_KEY") || str("WAN_API_KEY"),
  qwenVlModel: str("QWEN_VL_MODEL", "qwen-vl-max"),

  // ── Wan video (Phase 2: Alibaba Model Studio or Atlas Cloud) ──
  wanProvider: str("WAN_PROVIDER", "alibaba") as "alibaba" | "atlas",
  wanKey: str("WAN_API_KEY") || str("DASHSCOPE_API_KEY"),
  wanBaseUrl: str("WAN_BASE_URL").replace(/\/$/, ""),
  wanModel: str("WAN_MODEL", "wan3.0-video"),
  wanResolution: str("WAN_RESOLUTION", "480P"),
  wanAtlasExtra: str("WAN_ATLAS_EXTRA_JSON"), // extra JSON fields for Atlas (duration/resolution names)

  // ── Payments ──
  paymentMode: str("PAYMENT_MODE", "manual_qr") as "manual_qr" | "bkash_api",
  bkashMode: str("BKASH_MODE", "sandbox"),
  bkashAppKey: str("BKASH_APP_KEY"),
  bkashAppSecret: str("BKASH_APP_SECRET"),
  bkashUsername: str("BKASH_USERNAME"),
  bkashPassword: str("BKASH_PASSWORD"),

  // ── Phone login (Firebase Phone Auth) ──
  firebase: {
    apiKey: str("FIREBASE_API_KEY") || str("NEXT_PUBLIC_FIREBASE_API_KEY"),
    authDomain: str("FIREBASE_AUTH_DOMAIN") || str("NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN"),
    projectId: str("FIREBASE_PROJECT_ID") || str("NEXT_PUBLIC_FIREBASE_PROJECT_ID"),
    appId: str("FIREBASE_APP_ID") || str("NEXT_PUBLIC_FIREBASE_APP_ID"),
  },

  // ── Notifications ──
  telegramBotToken: str("TELEGRAM_BOT_TOKEN"),
  telegramChatId: str("TELEGRAM_CHAT_ID"),
  smsProvider: str("SMS_PROVIDER", "none"),
  smsApiKey: str("SMS_API_KEY"),

  // ── Storage ──
  storageProvider: str("STORAGE_PROVIDER", isProd ? "drive" : "local") as "drive" | "local" | "r2",
  google: {
    clientId: str("GOOGLE_CLIENT_ID"),
    clientSecret: str("GOOGLE_CLIENT_SECRET"),
    refreshToken: str("GOOGLE_REFRESH_TOKEN"),
    rootFolderId: str("DRIVE_ROOT_FOLDER_ID"),
  },
  r2: {
    accountId: str("R2_ACCOUNT_ID"),
    accessKey: str("R2_ACCESS_KEY"),
    secretKey: str("R2_SECRET_KEY"),
    bucket: str("R2_BUCKET"),
  },
  localUploadDir: str("LOCAL_UPLOAD_DIR", "./upload"),

  // ── Limits, admin, misc ──
  previewDailyCap: int("PREVIEW_DAILY_CAP", 100),
  adminEmail: str("ADMIN_EMAIL", "admin@dreamstudio.bd"),
  adminPassword: isProd ? str("ADMIN_PASSWORD") : str("ADMIN_PASSWORD", "admin12345"),
  sessionSecret: SESSION_SECRET || "dev-secret-change-me-please-make-it-long-enough",
  usdToBdt: int("USD_TO_BDT", 122),
  workerConcurrency: int("WORKER_CONCURRENCY", 6),
};

// Which login mode the site uses: Firebase in production when configured,
// the built-in OTP (mock code 123456) in local/mock mode.
export function authMode(): "firebase" | "otp" {
  const f = env.firebase;
  if (!env.mockMode && f.apiKey && f.projectId && f.authDomain && f.appId) return "firebase";
  return "otp";
}

export function isMock(): boolean {
  return env.mockMode;
}
