// lib/crypto.ts — password hashing + signed session tokens.
// Item 4: separate secrets for customer (preview) tokens vs staff sessions
// so one can never be used as the other. Uses crypto.timingSafeEqual for
// signature and password checks.
import crypto from "crypto";
import { env } from "@/lib/env";

const SESSION_SECRET = env.sessionSecret;

// ─── Password hashing (PBKDF2) ──────────────────────────────
export function hashPassword(pw: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto
    .pbkdf2Sync(pw, salt, 100000, 32, "sha256")
    .toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(pw: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const h = crypto.pbkdf2Sync(pw, salt, 100000, 32, "sha256").toString("hex");
  // timingSafeEqual on equal-length hex strings
  if (h.length !== hash.length) return false;
  try {
    return crypto.timingSafeEqual(Buffer.from(h), Buffer.from(hash));
  } catch {
    return false;
  }
}

export function generateOtp(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// ─── Signed session helpers ──────────────────────────────────
// We namespace the payload so a customer token (role=preview) and a staff
// token (role=operator/editor/admin) are computed under different HMAC
// prefixes. A leaked customer token can never be replayed as a staff session.
const CUSTOMER_PREFIX = "customer:";
const STAFF_PREFIX = "staff:";

function hmac(message: string): string {
  return crypto.createHmac("sha256", SESSION_SECRET).update(message).digest("hex");
}

function sign(payloadStr: string, prefix: string): string {
  // sign the prefix+payload together so a customer payload under the staff
  // prefix has a different signature
  const signed = prefix + payloadStr;
  const sig = hmac(signed);
  return `${payloadStr}.${sig}.${prefix === STAFF_PREFIX ? "s" : "c"}`;
}

function parse(value: string, expectedPrefix: string): { payload: any } | null {
  const [payloadStr, sig, tag] = value.split(".");
  if (!payloadStr || !sig || !tag) return null;
  const expectedTag = expectedPrefix === STAFF_PREFIX ? "s" : "c";
  if (tag !== expectedTag) return null; // wrong token type
  const expected = hmac(expectedPrefix + payloadStr);
  if (expected.length !== sig.length) return null;
  try {
    if (!crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(sig))) return null;
  } catch {
    return null;
  }
  try {
    return { payload: JSON.parse(Buffer.from(payloadStr, "base64url").toString()) };
  } catch {
    return null;
  }
}

// ─── Customer (preview) tokens ───────────────────────────────
export function buildCustomerSession(phone: string): string {
  const payload = JSON.stringify({ id: phone, email: phone, role: "preview", iat: Date.now() });
  const b64 = Buffer.from(payload).toString("base64url");
  return sign(b64, CUSTOMER_PREFIX);
}

export function parseCustomerSession(value: string): { id: string; email: string; role: string; iat: number } | null {
  const r = parse(value, CUSTOMER_PREFIX);
  if (!r) return null;
  const p = r.payload;
  if (p.role !== "preview") return null;
  if (Date.now() - p.iat > 12 * 60 * 60 * 1000) return null;
  return p;
}

// ─── Staff session tokens ────────────────────────────────────
export function buildStaffSession(staffId: string, email: string, role: string): string {
  const payload = JSON.stringify({ id: staffId, email, role, iat: Date.now() });
  const b64 = Buffer.from(payload).toString("base64url");
  return sign(b64, STAFF_PREFIX);
}

export function parseStaffSession(value: string): { id: string; email: string; role: string; iat: number } | null {
  const r = parse(value, STAFF_PREFIX);
  if (!r) return null;
  const p = r.payload;
  if (Date.now() - p.iat > 12 * 60 * 60 * 1000) return null;
  return p;
}

// ─── Signed file (storage) URLs — HMAC + expiry ─────────────
// Item 7: /api/storage/* serves files only through signed, expiring URLs.
// Format: <key>|<expiry>|<sig>  →  /api/storage/<key>?exp=<expiry>&sig=<sig>
const FILE_PREFIX = "file:";

export function signFileUrl(key: string, expiresAtMs: number, salt = ""): { exp: string; sig: string } {
  const message = `${FILE_PREFIX}${salt}|${key}|${expiresAtMs}`;
  return { exp: String(expiresAtMs), sig: hmac(message) };
}

export function verifyFileUrl(key: string, exp: string, sig: string, salt = "", maxAgeMs = 7 * 24 * 60 * 60 * 1000): boolean {
  if (!exp || !sig) return false;
  const expiry = Number(exp);
  if (!Number.isFinite(expiry)) return false;
  if (expiry < Date.now()) return false;
  if (expiry > Date.now() + maxAgeMs) return false; // cap at 7d
  const message = `${FILE_PREFIX}${salt}|${key}|${expiry}`;
  const expected = hmac(message);
  if (expected.length !== sig.length) return false;
  try {
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(sig));
  } catch {
    return false;
  }
}

// ─── Back-compat re-exports (deprecated; use the typed builders above) ─
export const buildSession = buildStaffSession;
export const parseSession = (value: string) => {
  // Tries staff first, then customer, so legacy callers that called
  // parseSession on a customer token still work. Returns null if neither.
  return parseStaffSession(value) || parseCustomerSession(value);
};

export { SESSION_SECRET };
