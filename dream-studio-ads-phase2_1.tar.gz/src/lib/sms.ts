// lib/sms.ts — SMS provider adapter (mock default)
import { env } from "@/lib/env";
import { db } from "@/lib/db";

export interface SmsResult {
  ok: boolean;
  provider: string;
  detail: string;
  // for mock mode we return the code/message so dev can see it
  debug?: string;
}

export async function sendSms(phone: string, message: string): Promise<SmsResult> {
  // Phase 2: default provider is "none" — customer updates are shown on the
  // account page and sent by staff via WhatsApp. The adapter stays for later.
  if (env.smsProvider === "none") {
    return { ok: true, provider: "none", detail: "sms-disabled" };
  }
  if (env.mockMode || env.smsProvider === "mock" || !env.smsApiKey) {
    console.log(`[SMS mock] to=${phone} body=${message}`);
    return {
      ok: true,
      provider: "mock",
      detail: "logged-to-stdout",
      debug: message,
    };
  }
  // Real adapters
  try {
    if (env.smsProvider === "bulksmsbd") {
      const r = await fetch(
        `https://api.bulksmsbd.com/?api_key=${env.smsApiKey}&sender_id=dreamstudio&mobile=${phone}&message=${encodeURIComponent(message)}`
      );
      const txt = await r.text();
      return { ok: r.ok, provider: "bulksmsbd", detail: txt };
    }
    if (env.smsProvider === "sslwireless") {
      const r = await fetch("https://api.sslwireless.com/sms/send", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          api_token: env.smsApiKey,
          sid: "DREAMSTUDIO",
          msisdn: phone,
          message,
        }),
      });
      const txt = await r.text();
      return { ok: r.ok, provider: "sslwireless", detail: txt };
    }
    return { ok: false, provider: env.smsProvider, detail: "unknown-provider" };
  } catch (e: unknown) {
    return { ok: false, provider: env.smsProvider, detail: String(e) };
  }
}

// standardised Bangla messages
export const smsTemplates = {
  otp: (code: string) => `আপনার Dream Studio OTP: ${code}। ৫ মিনিটে মেয়াদ শেষ।`,
  paymentReceived: (orderCode: string, amountBdt: number) =>
    `ধন্যবাদ! ${orderCode} এর জন্য ৳${amountBdt} পেয়েছি। আপনার বিজ্ঞাপন তৈরি শুরু হয়েছে।`,
  adDelivered: (orderCode: string, link: string) =>
    `আপনার বিজ্ঞাপন তৈরি! ${orderCode} — ডাউনলোড: ${link}`,
  revisionDelivered: (orderCode: string, link: string) =>
    `আপনার রিভিশন প্রস্তুত! ${orderCode} — ডাউনলোড: ${link}`,
  monthlyExpiring: (phone: string) =>
    `আপনার Monthly Plan ৩ দিনের মধ্যে শেষ হবে। নবায়ন করতে লগইন করুন।`,
  orderOverdueAdmin: (orderCode: string) =>
    `⚠️ ${orderCode} এর SLA পার হয়ে গেছে। দ্রুত দেখুন।`,
  // Phase 1C Item 5: refund / rejection SMS sent to the customer when an
  // admin rejects a MANUAL_REVIEW order (or any paid order is refunded).
  orderRejected: (orderCode: string) =>
    `আপনার অর্ডার ${orderCode} গ্রহণ করা যায়নি। টাকা ফেরত দেওয়া হবে, আমরা শীঘ্রই যোগাযোগ করব।`,
};

// queue an SMS send through the worker
export async function queueSms(phone: string, message: string) {
  await db.job.create({
    data: {
      type: "send_sms",
      payloadJson: JSON.stringify({ phone, message }),
      status: "QUEUED",
    },
  });
}
