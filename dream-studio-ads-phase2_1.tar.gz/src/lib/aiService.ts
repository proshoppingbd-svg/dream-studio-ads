// lib/aiService.ts — script + safety AI and the Wan re-exports.
// The LLM provider is chosen by LLM_PROVIDER (DeepSeek by default, Claude
// optional) — see lib/llm.ts. In MOCK mode it returns canned JSON so the
// whole site works without keys. Outside mock mode a missing key is an
// error (never a silent "allowed"). Every JSON reply goes through the shared
// parser (strip fences + zod validate): unparseable moderation is treated
// as REJECTED (previews) / MANUAL_REVIEW (paid orders); an unparseable
// script is retried once, then the order becomes SCRIPT_FAILED.
import { env } from "@/lib/env";
import { db } from "@/lib/db";
import { promises as fs } from "fs";
import path from "path";
import { z } from "zod";
import type {
  AiCost,
  ModerationResult,
  PreviewPromptResult,
  Script,
} from "@/lib/types";
import { parseAIJson } from "@/lib/aiJson";
import { getSettingCosts, costFromTokens as costFromTokensCfg, costFromWanSeconds } from "@/lib/costs";
import { callLLM, LlmError, type LlmImage, type LlmResult } from "@/lib/llm";
export { submitWanJob, pollWanTask, runWanToCompletion, WanError } from "@/lib/wan";

const PROMPTS_DIR = path.join(process.cwd(), "prompts");

async function loadPrompt(name: string): Promise<string> {
  try {
    return await fs.readFile(path.join(PROMPTS_DIR, name), "utf8");
  } catch {
    return "";
  }
}

// ─── zod schemas for model outputs ───────────────
const moderationSchema = z.object({
  allowed: z.boolean(),
  reason_bn: z.string(),
  category: z.string(),
});
const previewPromptSchema = z.object({
  prompt: z.string(),
  negative_prompt: z.string(),
});
const shotSchema = z.object({
  shot_no: z.number().int(),
  purpose: z.string(),
  image_to_video_prompt: z.string(),
  negative_prompt: z.string(),
  camera: z.string(),
  on_screen_text: z.string(),
  which_product_photo: z.number().int(),
});
const scriptSchema = z.object({
  script_bn: z.string(),
  shots: z.array(shotSchema).min(1),
  music_mood: z.string(),
  edit_notes: z.string(),
  cta_endcard_text: z.string(),
  premium_15s_cut_plan: z.string().optional(),
});

// mock deterministically returns a JSON string that satisfies our schemas
function mockLlmJSON(kind: "script" | "preview" | "moderation", userText: string): string {
  if (kind === "moderation") {
    const r: ModerationResult = {
      allowed: true,
      reason_bn: "ধন্যবাদ, আপনার পণ্য গ্রহণযোগ্য।",
      category: "ok",
    };
    return JSON.stringify(r);
  }
  if (kind === "preview") {
    const r: PreviewPromptResult = {
      prompt: `A cinematic 5-second vertical 9:16 hero shot of ${userText.slice(0, 80)}. Slow dolly-in, soft studio lighting, plain dark background, realistic, premium, 16mm film grain.`,
      negative_prompt:
        "blurry, watermark, text artifacts, extra fingers, deformed faces, cartoon, lowres, jpg compression",
    };
    return JSON.stringify(r);
  }
  // script
  const productName = userText.match(/productName=([^,]+)/)?.[1] || "your product";
  const lang = userText.match(/language=([^,]+)/)?.[1] || "Bangla";
  const tone = userText.match(/tone=([^,]+)/)?.[1] || "premium";
  const script: Script = {
    script_bn: `${productName} — মানেই আস্থা। এবার আপনার পণ্যের বিজ্ঞাপন একেবারে প্রফেশনাল।`,
    shots: [
      { shot_no: 1, purpose: "Establish product on a dark pedestal", image_to_video_prompt: `Cinematic 5s vertical shot, ${productName} on dark pedestal, slow rotate, soft key light, realistic, 16mm grain`, negative_prompt: "blurry, watermark, text artifacts, cartoon, deformed", camera: "Slow rotate", on_screen_text: productName, which_product_photo: 0 },
      { shot_no: 2, purpose: "Detail close-up of texture", image_to_video_prompt: `Macro 5s vertical, ${productName} texture close-up, soft bokeh, realistic lighting`, negative_prompt: "blurry, watermark, text artifacts, cartoon, deformed", camera: "Macro push-in", on_screen_text: "", which_product_photo: 0 },
      { shot_no: 3, purpose: "Lifestyle context", image_to_video_prompt: `5s vertical, ${productName} in a clean lifestyle setting, realistic, soft daylight`, negative_prompt: "blurry, watermark, text artifacts, cartoon, deformed", camera: "Locked off", on_screen_text: "", which_product_photo: 1 },
      { shot_no: 4, purpose: "Highlight feature", image_to_video_prompt: `5s vertical, ${productName} feature highlight, product hero, dramatic rim light`, negative_prompt: "blurry, watermark, text artifacts, cartoon, deformed", camera: "Dolly-in", on_screen_text: "", which_product_photo: 2 },
      { shot_no: 5, purpose: "Offer / price reveal", image_to_video_prompt: `5s vertical, ${productName} with price card ৳, realistic, premium, soft glow`, negative_prompt: "blurry, watermark, text artifacts, cartoon, deformed", camera: "Slow zoom", on_screen_text: "অফার চলছে", which_product_photo: 3 },
      { shot_no: 6, purpose: "CTA endcard", image_to_video_prompt: `5s vertical, ${productName} CTA endcard, product center, contact info overlay, realistic`, negative_prompt: "blurry, watermark, text artifacts, cartoon, deformed", camera: "Static", on_screen_text: lang === "English" ? "Order now" : "এখনই অর্ডার করুন", which_product_photo: 0 },
    ],
    music_mood: tone === "exciting" ? "uplifting energetic" : "warm ambient premium",
    edit_notes: "Cut on the beat. Hold endcard 1.5s. 16mm grain overlay at 15%.",
    cta_endcard_text: lang === "English" ? "Order now" : "এখনই অর্ডার করুন",
    premium_15s_cut_plan: "Use shots 1, 4, 6 for the 15s cut.",
  };
  return JSON.stringify(script);
}

// ─── Public AI service ───────────────────────────────────────
async function llmCost(r: LlmResult): Promise<AiCost> {
  return costFromTokensCfg(r.inputTokens, r.outputTokens, r.model, r.cacheHitTokens);
}

const VISION_ADDENDUM = `

You will also receive the product photo(s). Inspect them. Reject (allowed=false) if a photo shows a real person's face or recognisable likeness, nudity or sexual content, another brand's logo/trademark that is not the customer's own product, weapons, drugs, alcohol, tobacco or other banned products. Plain product photos, packaging and the customer's own logo are fine.`;

export const aiService = {
  // Moderation of the brief text + (optionally) the product photos.
  // Unparseable / unavailable output → parseFailed=true (callers treat it as
  // REJECTED for free previews and MANUAL_REVIEW for paid orders).
  async moderation(brief: string, images: LlmImage[] = []): Promise<{ result: ModerationResult | null; cost: AiCost; parseFailed: boolean; visionUsed?: string; error?: string }> {
    const sys = await loadPrompt("moderation.txt");
    if (env.mockMode) {
      const result = parseAIJson(mockLlmJSON("moderation", brief), moderationSchema);
      return { result, cost: { usd: 0, bdt: 0, detail: "mock-moderation" }, parseFailed: result === null };
    }
    const system = images.length ? sys + VISION_ADDENDUM : sys;
    const user = images.length ? `${brief}\n\n(${images.length} product photo(s) attached.)` : brief;
    let res: LlmResult | null = null;
    let visionUsed: string | undefined;
    try {
      if (images.length && env.visionProvider === "qwen") {
        res = await callLLM({ role: "vision", system, user, images, json: true, maxTokens: 512, provider: "qwen" });
        visionUsed = "qwen";
      } else {
        res = await callLLM({ role: images.length ? "vision" : "light", system, user, images, json: true, maxTokens: 512 });
        visionUsed = images.length ? env.llmProvider : undefined;
      }
    } catch (e) {
      // Vision not supported by the main model → fall back to Qwen-VL.
      if (e instanceof LlmError && e.code === "vision_unsupported" && images.length && env.qwenKey) {
        try {
          res = await callLLM({ role: "vision", system, user, images, json: true, maxTokens: 512, provider: "qwen" });
          visionUsed = "qwen";
        } catch (e2) {
          return { result: null, cost: { usd: 0, bdt: 0, detail: "moderation-failed" }, parseFailed: true, error: String((e2 as Error).message) };
        }
      } else {
        return { result: null, cost: { usd: 0, bdt: 0, detail: "moderation-failed" }, parseFailed: true, error: String((e as Error).message) };
      }
    }
    const result = parseAIJson(res!.text, moderationSchema);
    return { result, cost: await llmCost(res!), parseFailed: result === null, visionUsed };
  },

  async previewPrompt(brief: string): Promise<{ result: PreviewPromptResult | null; cost: AiCost; parseFailed: boolean }> {
    const sys = await loadPrompt("preview.txt");
    if (env.mockMode) {
      const result = parseAIJson(mockLlmJSON("preview", brief), previewPromptSchema);
      return { result, cost: { usd: 0, bdt: 0, detail: "mock-preview" }, parseFailed: result === null };
    }
    const res = await callLLM({ role: "light", system: sys, user: brief, json: true, maxTokens: 700 });
    const result = parseAIJson(res.text, previewPromptSchema);
    return { result, cost: await llmCost(res), parseFailed: result === null };
  },

  // If script output can't be parsed, the worker retries once, then marks
  // the order SCRIPT_FAILED.
  async generateScript(briefJson: string): Promise<{ script: Script | null; cost: AiCost; parseFailed: boolean }> {
    const sys = await loadPrompt("script.txt");
    if (env.mockMode) {
      const script = parseAIJson(mockLlmJSON("script", briefJson), scriptSchema) as Script | null;
      return { script, cost: { usd: 0, bdt: 0, detail: "mock-script" }, parseFailed: script === null };
    }
    const res = await callLLM({ role: "heavy", system: sys, user: briefJson, json: true, maxTokens: 6000 });
    const script = parseAIJson(res.text, scriptSchema) as Script | null;
    return { script, cost: await llmCost(res), parseFailed: script === null };
  },
};

// log cost helper
export async function logCost(opts: {
  orderId?: string;
  type: string;
  cost: AiCost;
}) {
  await db.costLog.create({
    data: {
      orderId: opts.orderId || null,
      type: opts.type,
      usdCost: opts.cost.usd,
      bdtCost: opts.cost.bdt,
      detail: opts.cost.detail,
    },
  });
}

// re-export for tests / callers
export { costFromTokensCfg, costFromWanSeconds, getSettingCosts };
export type { CostSettings } from "@/lib/costs";
