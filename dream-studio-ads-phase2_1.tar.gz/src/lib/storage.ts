// lib/storage.ts — file storage adapters (Phase 2).
//   STORAGE_PROVIDER=drive → owner's Google Drive (OAuth refresh token)
//   STORAGE_PROVIDER=local → local disk (dev / tests)
//   STORAGE_PROVIDER=r2    → Cloudflare R2 (kept for later)
// Every adapter returns a durable `key` from save(); callers must store
// THAT key (Drive keys look like "gd/<fileId>").
// Files are served only through signed, expiring URLs via /api/storage/*.
import { env } from "@/lib/env";
import { promises as fs } from "fs";
import path from "path";
import crypto from "crypto";
import { Readable } from "stream";
import { signFileUrl, verifyFileUrl } from "@/lib/crypto";

export interface StorageAdapter {
  name: "local" | "drive" | "r2";
  save(buffer: Buffer, key: string, contentType: string): Promise<{ url: string; key: string }>;
  read(key: string): Promise<Buffer>;
  signedUrl(key: string, expiresInSec?: number): Promise<string>;
  delete(key: string): Promise<void>;
  folderUrl(prefix: string): Promise<string | null>;
}

// Random, phone-free key. The directory part decides the Drive folder.
export function generateStorageKey(prefix: string, ext: string): string {
  const id = crypto.randomBytes(10).toString("hex");
  const ts = Date.now().toString(36);
  return `${prefix}/${id}-${ts}.${ext.replace(/^\./, "")}`;
}

export function contentTypeFor(name: string): string {
  const ext = path.extname(name.split("?")[0] || "").toLowerCase();
  return ext === ".mp4" ? "video/mp4"
    : ext === ".jpg" || ext === ".jpeg" ? "image/jpeg"
    : ext === ".png" ? "image/png"
    : ext === ".webp" ? "image/webp"
    : ext === ".webm" ? "video/webm"
    : "application/octet-stream";
}

function localSignedPath(key: string, expiresInSec: number): string {
  const exp = Date.now() + expiresInSec * 1000;
  const { exp: e, sig } = signFileUrl(key, exp);
  return `/api/storage/${key}?exp=${e}&sig=${sig}`;
}

export function verifySignedKey(key: string, exp: string, sig: string): boolean {
  return verifyFileUrl(key, exp, sig);
}

// ─── Local disk ─────────────────────────────────────────────
const LOCAL_ROOT = path.resolve(process.cwd(), env.localUploadDir);
class LocalStorage implements StorageAdapter {
  name = "local" as const;
  async save(buffer: Buffer, key: string) {
    const full = path.join(LOCAL_ROOT, key);
    await fs.mkdir(path.dirname(full), { recursive: true });
    await fs.writeFile(full, buffer);
    return { url: `/api/storage/${key}`, key };
  }
  async read(key: string) {
    return fs.readFile(path.join(LOCAL_ROOT, safeKey(key)));
  }
  async signedUrl(key: string, expiresInSec = 60 * 60 * 24 * 7) {
    return localSignedPath(key, expiresInSec);
  }
  async delete(key: string) {
    try { await fs.unlink(path.join(LOCAL_ROOT, safeKey(key))); } catch { /* already gone */ }
  }
  async folderUrl() { return null; }
  static root() { return LOCAL_ROOT; }
}

export function safeKey(key: string): string {
  return path.normalize(key).replace(/^(\.\.[/\\])+/, "").replace(/^[/\\]+/, "");
}

// ─── Google Drive (owner's account, OAuth2 refresh token) ───
const FOLDER_MIME = "application/vnd.google-apps.folder";
const ROOT_FOLDER_NAME = "DreamStudioAds";

// Map a key's directory to the Drive folder layout:
//   preview/…                      → DreamStudioAds/previews
//   orders/<CODE>/photos|shots|delivered/… → DreamStudioAds/orders/<CODE>/…
//   settings/…                     → DreamStudioAds/settings
function folderPartsFor(key: string): string[] {
  const dir = path.posix.dirname(key.replace(/\\/g, "/"));
  if (!dir || dir === ".") return [];
  const parts = dir.split("/").filter(Boolean);
  if (parts[0] === "preview") parts[0] = "previews";
  return parts;
}

type DriveClient = import("@googleapis/drive").drive_v3.Drive;

class DriveStorage implements StorageAdapter {
  name = "drive" as const;
  private client: DriveClient | null = null;
  private folderCache = new Map<string, Promise<string>>();
  private metaCache = new Map<string, { size: number; mimeType: string; at: number }>();

  async drive(): Promise<DriveClient> {
    if (this.client) return this.client;
    const { drive_v3, auth } = await import("@googleapis/drive");
    const oauth = new auth.OAuth2(env.google.clientId, env.google.clientSecret);
    oauth.setCredentials({ refresh_token: env.google.refreshToken });
    this.client = new drive_v3.Drive({ auth: oauth });
    return this.client;
  }

  private async findOrCreateFolder(name: string, parentId: string | null): Promise<string> {
    const d = await this.drive();
    const esc = name.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
    const q = [`name='${esc}'`, `mimeType='${FOLDER_MIME}'`, "trashed=false", parentId ? `'${parentId}' in parents` : "'root' in parents"].join(" and ");
    const found = await d.files.list({ q, fields: "files(id)", pageSize: 1, spaces: "drive" });
    const id = found.data.files?.[0]?.id;
    if (id) return id;
    const created = await d.files.create({
      requestBody: { name, mimeType: FOLDER_MIME, parents: parentId ? [parentId] : undefined },
      fields: "id",
    });
    return created.data.id!;
  }

  private rootId(): Promise<string> {
    const cacheKey = "__root__";
    if (!this.folderCache.has(cacheKey)) {
      const p = env.google.rootFolderId
        ? Promise.resolve(env.google.rootFolderId)
        : this.findOrCreateFolder(ROOT_FOLDER_NAME, null);
      p.catch(() => this.folderCache.delete(cacheKey));
      this.folderCache.set(cacheKey, p);
    }
    return this.folderCache.get(cacheKey)!;
  }

  async ensureFolder(parts: string[]): Promise<string> {
    let parent = await this.rootId();
    let pathSoFar = "";
    for (const part of parts) {
      pathSoFar += "/" + part;
      if (!this.folderCache.has(pathSoFar)) {
        const parentId = parent;
        const p = this.findOrCreateFolder(part, parentId);
        p.catch(() => this.folderCache.delete(pathSoFar));
        this.folderCache.set(pathSoFar, p);
      }
      parent = await this.folderCache.get(pathSoFar)!;
    }
    return parent;
  }

  async save(buffer: Buffer, key: string, contentType: string) {
    const d = await this.drive();
    const folderId = await this.ensureFolder(folderPartsFor(key));
    const res = await d.files.create({
      requestBody: { name: path.posix.basename(key), parents: [folderId] },
      media: { mimeType: contentType, body: Readable.from(buffer) },
      fields: "id,size,mimeType",
    });
    const id = res.data.id!;
    this.metaCache.set(id, { size: buffer.length, mimeType: contentType, at: Date.now() });
    return { url: `gd/${id}`, key: `gd/${id}` };
  }

  async read(key: string) {
    const d = await this.drive();
    const res = await d.files.get({ fileId: driveId(key), alt: "media" }, { responseType: "arraybuffer" });
    return Buffer.from(res.data as ArrayBuffer);
  }

  async meta(key: string): Promise<{ size: number; mimeType: string }> {
    const id = driveId(key);
    const hit = this.metaCache.get(id);
    if (hit && Date.now() - hit.at < 10 * 60 * 1000) return hit;
    const d = await this.drive();
    const res = await d.files.get({ fileId: id, fields: "size,mimeType" });
    const m = { size: Number(res.data.size || 0), mimeType: res.data.mimeType || "application/octet-stream", at: Date.now() };
    this.metaCache.set(id, m);
    return m;
  }

  // Stream (optionally a byte range) for the /api/storage route.
  async stream(key: string, range?: string): Promise<{ status: number; headers: Record<string, string>; body: ReadableStream }> {
    const d = await this.drive();
    const m = await this.meta(key);
    const headers: Record<string, string> = { "content-type": m.mimeType, "accept-ranges": "bytes", "cache-control": "private, max-age=3600" };
    let status = 200;
    let reqHeaders: Record<string, string> | undefined;
    const r = range?.match(/^bytes=(\d*)-(\d*)$/);
    if (r && m.size > 0) {
      let start = r[1] ? Number(r[1]) : 0;
      let end = r[2] ? Number(r[2]) : m.size - 1;
      if (!r[1] && r[2]) { start = Math.max(0, m.size - Number(r[2])); end = m.size - 1; }
      end = Math.min(end, m.size - 1);
      if (start > end) return { status: 416, headers: { "content-range": `bytes */${m.size}` }, body: new ReadableStream({ start(c) { c.close(); } }) };
      reqHeaders = { Range: `bytes=${start}-${end}` };
      status = 206;
      headers["content-range"] = `bytes ${start}-${end}/${m.size}`;
      headers["content-length"] = String(end - start + 1);
    } else if (m.size > 0) {
      headers["content-length"] = String(m.size);
    }
    const res = await d.files.get({ fileId: driveId(key), alt: "media" }, { responseType: "stream", headers: reqHeaders });
    const node = res.data as unknown as Readable;
    return { status, headers, body: Readable.toWeb(node) as unknown as ReadableStream };
  }

  async signedUrl(key: string, expiresInSec = 60 * 60 * 24 * 7) {
    return localSignedPath(key, expiresInSec);
  }

  async delete(key: string) {
    const d = await this.drive();
    await d.files.delete({ fileId: driveId(key) }).catch(() => {});
  }

  async folderUrl(prefix: string) {
    const id = await this.ensureFolder(folderPartsFor(`${prefix}/x`));
    return `https://drive.google.com/drive/folders/${id}`;
  }

  // Health check: can we reach Drive with this token?
  async ping(): Promise<boolean> {
    const d = await this.drive();
    await d.files.list({ pageSize: 1, fields: "files(id)" });
    return true;
  }
}

function driveId(key: string): string {
  return key.replace(/^gd\//, "");
}

// ─── Cloudflare R2 (S3-compatible, kept for later) ──────────
class R2Storage implements StorageAdapter {
  name = "r2" as const;
  private async client() {
    const { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } = await import("@aws-sdk/client-s3");
    const { getSignedUrl } = await import("@aws-sdk/s3-request-presigner");
    const s3 = new S3Client({
      region: "auto",
      endpoint: `https://${env.r2.accountId}.r2.cloudflarestorage.com`,
      credentials: { accessKeyId: env.r2.accessKey, secretAccessKey: env.r2.secretKey },
    });
    return { s3, PutObjectCommand, GetObjectCommand, DeleteObjectCommand, getSignedUrl };
  }
  async save(buffer: Buffer, key: string, contentType: string) {
    const { s3, PutObjectCommand } = await this.client();
    await s3.send(new PutObjectCommand({ Bucket: env.r2.bucket, Key: key, Body: buffer, ContentType: contentType }));
    return { url: key, key };
  }
  async read(key: string) {
    const { s3, GetObjectCommand } = await this.client();
    const r = await s3.send(new GetObjectCommand({ Bucket: env.r2.bucket, Key: key }));
    return Buffer.from(await r.Body!.transformToByteArray());
  }
  async signedUrl(key: string, expiresInSec = 604800) {
    const { s3, GetObjectCommand, getSignedUrl } = await this.client();
    return getSignedUrl(s3, new GetObjectCommand({ Bucket: env.r2.bucket, Key: key }), { expiresIn: expiresInSec });
  }
  async delete(key: string) {
    const { s3, DeleteObjectCommand } = await this.client();
    await s3.send(new DeleteObjectCommand({ Bucket: env.r2.bucket, Key: key }));
  }
  async folderUrl() { return null; }
}

export function driveConfigured(): boolean {
  const g = env.google;
  return !!(g.clientId && g.clientSecret && g.refreshToken);
}

function pickStorage(): StorageAdapter {
  if (env.storageProvider === "drive" && driveConfigured()) return new DriveStorage();
  if (env.storageProvider === "r2" && env.r2.accountId && env.r2.bucket && env.r2.accessKey) return new R2Storage();
  if (env.isProd && !env.mockMode) {
    console.error(`[storage] WARNING: STORAGE_PROVIDER=${env.storageProvider} is not configured — falling back to local disk, which is WIPED on every Railway deploy.`);
  }
  return new LocalStorage();
}

export const storage: StorageAdapter = pickStorage();
export const driveStorage: DriveStorage | null = storage instanceof DriveStorage ? storage : null;
export const LocalStorageHelpers = LocalStorage;

// Absolute signed URL (for external services like Wan that must fetch the file).
export async function absoluteSignedUrl(key: string, expiresInSec = 3600): Promise<string> {
  const u = await storage.signedUrl(key, expiresInSec);
  return u.startsWith("http") ? u : `${env.appUrl}${u}`;
}

// Read a stored file OR a bundled /public sample (mock mode) into memory.
export async function readStored(key: string): Promise<Buffer> {
  if (key.startsWith("/samples/") || key.startsWith("samples/")) {
    return fs.readFile(path.join(process.cwd(), "public", key.replace(/^\//, "")));
  }
  if (key.startsWith("gd/") && !driveStorage) throw new Error("Drive file but Drive storage is not configured");
  return storage.read(key);
}
