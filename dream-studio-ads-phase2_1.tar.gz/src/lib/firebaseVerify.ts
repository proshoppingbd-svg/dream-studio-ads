// lib/firebaseVerify.ts — verify a Firebase Phone Auth ID token on the server.
// Uses Google's public signing keys (no service-account secret needed):
// signature, issuer, audience (= project id), expiry and sign-in provider.
import { createRemoteJWKSet, jwtVerify } from "jose";
import { env } from "@/lib/env";

const JWKS = createRemoteJWKSet(
  new URL("https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com")
);

// "+8801712345678" → "01712345678"; returns null for non-Bangladeshi numbers.
export function toLocalBdPhone(e164: string): string | null {
  const m = e164.replace(/\s/g, "").match(/^\+?880(1[3-9]\d{8})$/);
  return m ? "0" + m[1] : null;
}

export async function verifyFirebasePhoneToken(idToken: string): Promise<{ phone: string } | { error: string }> {
  const projectId = env.firebase.projectId;
  if (!projectId) return { error: "firebase_not_configured" };
  try {
    const { payload } = await jwtVerify(idToken, JWKS, {
      issuer: `https://securetoken.google.com/${projectId}`,
      audience: projectId,
    });
    const provider = (payload.firebase as { sign_in_provider?: string } | undefined)?.sign_in_provider;
    if (provider !== "phone") return { error: "not_phone_login" };
    const phone = toLocalBdPhone(String(payload.phone_number || ""));
    if (!phone) return { error: "not_bd_number" };
    return { phone };
  } catch {
    return { error: "invalid_token" };
  }
}
