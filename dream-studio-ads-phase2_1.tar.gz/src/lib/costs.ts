// lib/costs.ts — read configurable cost rates from admin settings (Item 18).
// All prices are configurable; the cost report reads these values.
import { db } from "@/lib/db";
import { env } from "@/lib/env";

// Cache for the lifetime of the process; settings change rarely and admin
// can refresh by restarting. 5s TTL to pick up edits.
let cache: { at: number; data: CostSettings | null } = { at: 0, data: null };
const TTL_MS = 5_000;

export interface ModelPrice { in: number; out: number; cache?: number }

export interface CostSettings {
  usdToBdt: number;
  wanCostPerSecUsd: number;
  // per-million-token USD prices, keyed by model id (lowercased)
  llmPerMillion: Record<string, ModelPrice>;
}

// Defaults (USD per 1M tokens). Every value is editable in admin settings
// through the "llm_prices_json" setting — check your provider's price page.
export const DEFAULT_LLM_PRICES: Record<string, ModelPrice> = {
  "deepseek-flash": { in: 0.3, out: 1.2, cache: 0.006 },
  "deepseek-v4-pro": { in: 0.435, out: 0.87, cache: 0.0036 },
  "claude-opus-5-5": { in: 5, out: 25, cache: 0.5 },
  "qwen-vl-max": { in: 0.8, out: 3.2 },
};

async function readSettings(): Promise<Record<string, string>> {
  const rows = await db.setting.findMany();
  const out: Record<string, string> = {};
  for (const r of rows) out[r.key] = r.value;
  return out;
}

export async function getSettingCosts(): Promise<CostSettings> {
  const now = Date.now();
  if (cache.data && now - cache.at < TTL_MS) return cache.data;
  const s = await readSettings();
  const num = (k: string, fallback: number) => {
    const v = Number(s[k]);
    return s[k] !== undefined && Number.isFinite(v) && v >= 0 ? v : fallback;
  };
  let custom: Record<string, ModelPrice> = {};
  try {
    const parsed = JSON.parse(s["llm_prices_json"] || "{}");
    if (parsed && typeof parsed === "object") custom = parsed;
  } catch { /* ignore bad JSON; defaults apply */ }
  const llmPerMillion: Record<string, ModelPrice> = {};
  for (const [k, v] of Object.entries({ ...DEFAULT_LLM_PRICES, ...custom })) llmPerMillion[k.toLowerCase()] = v;
  const data: CostSettings = {
    usdToBdt: num("usd_to_bdt", env.usdToBdt),
    wanCostPerSecUsd: num("wan_cost_per_sec_usd", 0.05),
    llmPerMillion,
  };
  cache = { at: now, data };
  return data;
}

// Compute cost from token counts using the configured rates for a model.
// cacheHit tokens (DeepSeek context cache) are billed at the cache rate.
export async function costFromTokens(input: number, output: number, model: string, cacheHit = 0): Promise<{ usd: number; bdt: number; detail: string }> {
  const c = await getSettingCosts();
  const p = c.llmPerMillion[model.toLowerCase()] || { in: 1, out: 3 };
  const miss = Math.max(0, input - cacheHit);
  const usd = (miss / 1_000_000) * p.in + (cacheHit / 1_000_000) * (p.cache ?? p.in) + (output / 1_000_000) * p.out;
  return { usd, bdt: usd * c.usdToBdt, detail: `${model} in=${input} cache=${cacheHit} out=${output}` };
}

// Compute Wan cost from seconds using the configured rate.
export async function costFromWanSeconds(seconds: number): Promise<{ usd: number; bdt: number; detail: string }> {
  const c = await getSettingCosts();
  const usd = c.wanCostPerSecUsd * seconds;
  return { usd, bdt: usd * c.usdToBdt, detail: `wan ${seconds}s @ ${c.wanCostPerSecUsd}/s` };
}
