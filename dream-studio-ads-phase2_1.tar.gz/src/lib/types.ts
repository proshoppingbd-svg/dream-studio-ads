// lib/types.ts — shared domain types
export type Role = "operator" | "editor" | "admin";

export const ORDER_STATUS = [
  "PENDING_PAYMENT",
  "PAID",
  "SCRIPTING",
  "SCRIPT_READY",
  "GENERATING",
  "QC",
  "EDITING",
  "DELIVERED",
  "REVISION_REQUESTED",
  "CLOSED",
  "REJECTED",
  "REFUNDED",
] as const;
export type OrderStatus = (typeof ORDER_STATUS)[number];

export const SHOT_STATUS = ["PENDING", "GENERATING", "READY", "REJECTED", "APPROVED"] as const;
export type ShotStatus = (typeof SHOT_STATUS)[number];

export interface Brief {
  productName: string;
  category: string;
  priceOffer?: string;
  photos: string[]; // stored paths
  logo?: string;
  targetCustomer: string;
  tone: "exciting" | "emotional" | "premium" | "funny" | "simple";
  language: "Bangla" | "English" | "Banglish";
  cta: string;
  phoneOrPage: string;
  notes?: string;
  rightsConfirmed: boolean;
}

export interface ShotPlan {
  shot_no: number;
  purpose: string;
  image_to_video_prompt: string;
  negative_prompt: string;
  camera: string;
  on_screen_text: string;
  which_product_photo: number;
}

export interface Script {
  script_bn: string;
  shots: ShotPlan[];
  music_mood: string;
  edit_notes: string;
  cta_endcard_text: string;
  premium_15s_cut_plan?: string;
}

export interface ModerationResult {
  allowed: boolean;
  reason_bn: string;
  category: string;
}

export interface PreviewPromptResult {
  prompt: string;
  negative_prompt: string;
}

export interface AiCost {
  usd: number;
  bdt: number;
  detail: string;
}
