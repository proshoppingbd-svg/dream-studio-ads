"use client";
// components/chrome.ts — shared header, footer, WhatsApp button, mobile nav
import Link from "next/link";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { MessageCircle, Menu, Film } from "lucide-react";
import { cn } from "@/lib/utils";

interface Setting {
  whatsapp_number?: string;
  bkash_personal?: string;
}

export function SiteHeader({ settings, navigate }: { settings: Setting; navigate: (to: string) => void }) {
  const [open, setOpen] = useState(false);
  const wa = settings.whatsapp_number || "";
  const links: { label: string; to: string }[] = [
    { label: "হোম", to: "#/" },
    { label: "ফ্রি প্রিভিউ", to: "#/preview" },
    { label: "অর্ডার", to: "#/order/STANDARD" },
    { label: "আমার অর্ডার", to: "#/account" },
  ];
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
        <button onClick={() => navigate("#/")} className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Film className="h-5 w-5" />
          </div>
          <div className="text-left leading-tight">
            <div className="text-sm font-bold">Dream Studio</div>
            <div className="text-[10px] text-muted-foreground">by Digital Sign</div>
          </div>
        </button>
        <nav className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <Button key={l.to} variant="ghost" size="sm" asChild>
              <a href={l.to}>{l.label}</a>
            </Button>
          ))}
          <Button size="sm" asChild>
            <a href="#/preview">ফ্রি প্রিভিউ দেখুন</a>
          </Button>
        </nav>
        <div className="md:hidden">
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" aria-label="Menu">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <nav className="mt-8 flex flex-col gap-2">
                {links.map((l) => (
                  <Button key={l.to} variant="ghost" className="justify-start" asChild>
                    <a href={l.to} onClick={() => setOpen(false)}>{l.label}</a>
                  </Button>
                ))}
                <Button className="mt-2" asChild>
                  <a href="#/preview" onClick={() => setOpen(false)}>ফ্রি প্রিভিউ দেখুন</a>
                </Button>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}

export function SiteFooter({ settings, navigate }: { settings: Setting; navigate: (to: string) => void }) {
  return (
    <footer className="mt-auto border-t bg-muted/40">
      <div className="mx-auto max-w-6xl px-4 py-8">
        <div className="grid gap-6 sm:grid-cols-3">
          <div>
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded bg-primary text-primary-foreground">
                <Film className="h-4 w-4" />
              </div>
              <span className="font-bold">Dream Studio Ads</span>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              by Digital Sign, Bangladesh. AI ভিডিও বিজ্ঞাপন — ফেসবুক সেলারদের জন্য।
            </p>
          </div>
          <div>
            <div className="text-sm font-semibold">প্রতিষ্ঠান</div>
            <ul className="mt-2 space-y-1 text-xs text-muted-foreground">
              <li><a className="hover:underline" href="#/terms">শর্তাবলী</a></li>
              <li><a className="hover:underline" href="#/privacy">প্রাইভেসি</a></li>
              <li><a className="hover:underline" href="#/refund">রিফান্ড</a></li>
              <li><a className="hover:underline" href="#/studio">Studio (скоро)</a></li>
            </ul>
          </div>
          <div>
            <div className="text-sm font-semibold">যোগাযোগ</div>
            <ul className="mt-2 space-y-1 text-xs text-muted-foreground">
              {settings.whatsapp_number && <li>WhatsApp: {settings.whatsapp_number}</li>}
              {settings.bkash_personal && <li>bKash: {settings.bkash_personal}</li>}
            </ul>
          </div>
        </div>
        <div className="mt-6 border-t pt-4 text-center text-[11px] text-muted-foreground">
          © {new Date().getFullYear()} Dream Studio Ads · Digital Sign Bangladesh · সকল স্বত্ব সংরক্ষিত
        </div>
      </div>
    </footer>
  );
}

export function WhatsAppFloat({ number }: { number?: string }) {
  if (!number) return null;
  const wa = number;
  const href = `https://wa.me/${wa.replace(/[^\d]/g, "")}`;
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="WhatsApp"
      className={cn(
        "fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full shadow-lg",
        "bg-[#25D366] text-white transition-transform hover:scale-110"
      )}
    >
      <MessageCircle className="h-7 w-7" />
      <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#25D366] opacity-30" />
    </a>
  );
}
