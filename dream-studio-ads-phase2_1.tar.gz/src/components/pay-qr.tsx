"use client";
// components/pay-qr.tsx — manual bKash QR payment (Phase 2).
// Customer scans the QR (or sends to the number), then submits the TrxID.
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Copy, Loader2, QrCode, AlertTriangle, ImageIcon } from "lucide-react";
import { api, compressImage, getCustomerSession } from "@/hooks/use-api";
import { getPublicConfig, type PublicConfig } from "@/lib/phoneAuth";

const ERRORS: Record<string, string> = {
  trxid_used: "এই TrxID আগেই ব্যবহার হয়েছে। সঠিক TrxID দিন।",
  bad_trxid: "TrxID ১০ অক্ষরের হয় (যেমন: 9ABC1DEF2G)। bKash মেসেজ থেকে দেখে দিন।",
  bad_sender: "যে bKash নম্বর থেকে টাকা পাঠিয়েছেন সেটি সঠিকভাবে দিন।",
  bad_amount: "কত টাকা পাঠিয়েছেন লিখুন।",
  too_many_submissions: "আজ এই অর্ডারে ৩ বার জমা দেওয়া হয়েছে। আগামীকাল চেষ্টা করুন বা WhatsApp-এ যোগাযোগ করুন।",
  not_pending: "এই অর্ডারের পেমেন্ট ইতিমধ্যে জমা হয়েছে।",
  unauthorized: "আবার লগইন করুন।",
};

async function copy(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    toast.success("কপি হয়েছে");
  } catch {
    toast.info(text);
  }
}

export function PayQr({ orderId, orderCode, amount, rejectReason, onSubmitted }: {
  orderId: string;
  orderCode: string;
  amount: number;
  rejectReason?: string | null;
  onSubmitted: () => void;
}) {
  const [cfg, setCfg] = useState<PublicConfig | null>(null);
  const [sender, setSender] = useState("");
  const [trxId, setTrxId] = useState("");
  const [paid, setPaid] = useState(String(amount));
  const [shot, setShot] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    getPublicConfig().then(setCfg).catch(() => setCfg(null));
  }, []);

  async function submit() {
    if (!/^01[3-9]\d{8}$/.test(sender.replace(/\s|-/g, ""))) return toast.error(ERRORS.bad_sender);
    if (!/^[A-Za-z0-9]{10}$/.test(trxId.trim())) return toast.error(ERRORS.bad_trxid);
    setBusy(true);
    try {
      const s = getCustomerSession();
      await api("/api/payment/submit", {
        method: "POST",
        body: JSON.stringify({ token: s.token, orderId, senderNumber: sender, trxId: trxId.trim().toUpperCase(), amount: Number(paid), screenshot: shot }),
      });
      toast.success("পেমেন্ট জমা হয়েছে! যাচাই করে দ্রুত নিশ্চিত করব।");
      onSubmitted();
    } catch (e: any) {
      toast.error(ERRORS[e.message] || e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card className="mt-4 border-primary/40">
      <CardHeader>
        <div className="flex items-center gap-2 font-semibold"><QrCode className="h-5 w-5 text-primary" /> bKash-এ পেমেন্ট করুন</div>
      </CardHeader>
      <CardContent className="space-y-4">
        {rejectReason && (
          <div className="flex gap-2 rounded-lg border border-destructive/40 bg-destructive/5 p-3 text-sm">
            <AlertTriangle className="h-4 w-4 shrink-0 text-destructive" />
            <div><b>আগের পেমেন্ট নিশ্চিত করা যায়নি:</b> {rejectReason}। অনুগ্রহ করে সঠিক তথ্য দিয়ে আবার জমা দিন।</div>
          </div>
        )}

        <ol className="list-decimal space-y-1 pl-5 text-sm">
          <li>bKash অ্যাপ খুলে <b>Send Money</b> বা <b>Scan QR</b> বাছুন।</li>
          <li>ঠিক <b>৳{amount.toLocaleString("en-US")}</b> পাঠান।</li>
          <li>Reference-এ অর্ডার কোড <b>{orderCode}</b> লিখুন।</li>
          <li>bKash মেসেজে পাওয়া <b>TrxID</b> নিচে দিন।</li>
        </ol>

        <div className="grid gap-4 sm:grid-cols-[200px_1fr]">
          <div className="flex items-center justify-center rounded-xl border bg-white p-2">
            {cfg?.bkashQrUrl ? (
              <img src={cfg.bkashQrUrl} alt="bKash QR" className="h-44 w-44 object-contain" />
            ) : (
              <div className="p-6 text-center text-xs text-muted-foreground">QR শীঘ্রই যোগ হবে — নিচের নম্বরে Send Money করুন</div>
            )}
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between rounded-lg border p-2">
              <span>bKash নম্বর: <b className="tabular-nums">{cfg?.bkashNumber || "—"}</b></span>
              {cfg?.bkashNumber && <Button size="sm" variant="ghost" onClick={() => copy(cfg.bkashNumber)}><Copy className="h-4 w-4" /></Button>}
            </div>
            <div className="flex items-center justify-between rounded-lg border p-2">
              <span>পরিমাণ: <b className="tabular-nums">৳{amount}</b></span>
              <Button size="sm" variant="ghost" onClick={() => copy(String(amount))}><Copy className="h-4 w-4" /></Button>
            </div>
            <div className="flex items-center justify-between rounded-lg border p-2">
              <span>Reference: <b>{orderCode}</b></span>
              <Button size="sm" variant="ghost" onClick={() => copy(orderCode)}><Copy className="h-4 w-4" /></Button>
            </div>
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-3">
          <div className="space-y-1">
            <Label htmlFor="pay-sender" className="text-xs">যে নম্বর থেকে পাঠিয়েছেন</Label>
            <Input id="pay-sender" inputMode="numeric" placeholder="01XXXXXXXXX" value={sender} onChange={(e) => setSender(e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label htmlFor="pay-trx" className="text-xs">TrxID</Label>
            <Input id="pay-trx" placeholder="যেমন 9ABC1DEF2G" maxLength={10} className="uppercase" value={trxId} onChange={(e) => setTrxId(e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label htmlFor="pay-amount" className="text-xs">কত টাকা পাঠিয়েছেন</Label>
            <Input id="pay-amount" inputMode="numeric" value={paid} onChange={(e) => setPaid(e.target.value.replace(/[^\d]/g, ""))} />
          </div>
        </div>

        <label className="flex cursor-pointer items-center gap-2 text-xs text-muted-foreground">
          <ImageIcon className="h-4 w-4" />
          {shot ? "স্ক্রিনশট যোগ হয়েছে ✓" : "পেমেন্টের স্ক্রিনশট (ঐচ্ছিক)"}
          <input
            id="pay-shot"
            type="file"
            accept="image/*"
            className="hidden"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (f) setShot(await compressImage(f, 1080, 1920, 0.8));
            }}
          />
        </label>

        <Button className="w-full" onClick={submit} disabled={busy}>
          {busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} পেমেন্ট জমা দিন
        </Button>
      </CardContent>
    </Card>
  );
}
