"use client";
// components/views/legal.tsx — terms/privacy/refund (placeholder text from settings)
import { Card, CardContent, CardHeader } from "@/components/ui/card";

const titles: Record<string, string> = {
  terms: "শর্তাবলী",
  privacy: "প্রাইভেসি পলিসি",
  refund: "রিফান্ড পলিসি",
};

export function LegalView({ kind, settings }: { kind: "terms" | "privacy" | "refund"; settings: Record<string, string> }) {
  const text = settings[`${kind}_text`] || "এই বিভাগের টেক্সট শীঘ্রই আপডেট হবে। অনুগ্রহ করে পরে দেখুন বা admin এর সাথে যোগাযোগ করুন।";
  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <Card>
        <CardHeader><h1 className="text-2xl font-bold">{titles[kind]}</h1></CardHeader>
        <CardContent>
          <div className="prose-bn whitespace-pre-line text-sm text-muted-foreground">{text}</div>
        </CardContent>
      </Card>
    </div>
  );
}
