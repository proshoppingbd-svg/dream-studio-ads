"use client";
// components/views/order.tsx — brief form + bKash payment
// Phase 1C Item 1: the customer must log in by phone+OTP before submitting.
// The login reuses the account OTP flow (preview/start + preview/verify with
// purpose=login). The brief stays filled in component state during login.
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Upload, ArrowRight, ShieldCheck, CreditCard, ImageIcon, Phone, ShieldCheck as ShieldIcon } from "lucide-react";
import { api, compressImage, getCustomerSession, setCustomerSession } from "@/hooks/use-api";
import { sendLoginCode, verifyLoginCode, getPublicConfig } from "@/lib/phoneAuth";

const categories = [
  { id: "clothing", label: "পোশাক" },
  { id: "cosmetics", label: "কসমেটিকস" },
  { id: "food", label: "খাবার" },
  { id: "electronics", label: "ইলেকট্রনিক্স" },
  { id: "restaurant", label: "রেস্টুরেন্ট" },
  { id: "other", label: "অন্যান্য" },
];
const tones = [
  { id: "exciting", label: "Exciting (উত্তেজনাময়)" },
  { id: "emotional", label: "Emotional (আবেগপূর্ণ)" },
  { id: "premium", label: "Premium (প্রিমিয়াম)" },
  { id: "funny", label: "Funny (মজার)" },
  { id: "simple", label: "Simple (সহজ)" },
];
const langs = [
  { id: "Bangla", label: "বাংলা" },
  { id: "English", label: "English" },
  { id: "Banglish", label: "Banglish" },
];

export function OrderView({ productCode, navigate }: { productCode?: string; navigate: (to: string) => void }) {
  const [products, setProducts] = useState<any[]>([]);
  const [product, setProduct] = useState<any | null>(null);
  const [name, setName] = useState("");
  const [productName, setProductName] = useState("");
  const [category, setCategory] = useState("clothing");
  const [priceOffer, setPriceOffer] = useState("");
  const [photos, setPhotos] = useState<string[]>([]);
  const [logo, setLogo] = useState<string | null>(null);
  const [target, setTarget] = useState("সাধারণ ক্রেতা");
  const [tone, setTone] = useState("premium");
  const [language, setLanguage] = useState("Bangla");
  const [cta, setCta] = useState("ইনবক্স করুন");
  const [pageLink, setPageLink] = useState("");
  const [notes, setNotes] = useState("");
  const [rights, setRights] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  // Phase 1C Item 1: phone+OTP login before submitting. The brief state
  // above stays intact during the OTP step. The phone is pre-filled from
  // the existing session (if any) so a returning customer can skip the OTP.
  const existing = typeof window !== "undefined" ? getCustomerSession() : { phone: null, token: null };
  const [phone, setPhone] = useState(existing.phone || "");
  const [authStep, setAuthStep] = useState<"none" | "otp">("none");
  const [otp, setOtp] = useState("");
  const [debugOtp, setDebugOtp] = useState<string | null>(null);
  const [otpSending, setOtpSending] = useState(false);

  useEffect(() => {
    api<{ products: any[] }>("/api/orders/create").then((d) => {
      setProducts(d.products);
      const p = d.products.find((x) => x.code === productCode) || d.products.find((x) => x.code === "STANDARD");
      setProduct(p || null);
    });
  }, [productCode]);

  async function addPhoto(file: File) {
    if (photos.length >= 5) return toast.error("সর্বোচ্চ ৫টি ছবি");
    try {
      const d = await compressImage(file, 1280, 1280, 0.85);
      setPhotos((p) => [...p, d]);
    } catch (e: any) { toast.error(e.message); }
  }
  async function addLogo(file: File) {
    try { const d = await compressImage(file, 512, 512, 0.85); setLogo(d); } catch (e: any) { toast.error(e.message); }
  }

  // Phase 1C Item 1: validate the brief, then ensure the customer is logged
  // in by phone+OTP before creating the order. The brief stays filled in
  // component state during the OTP step.
  async function submit() {
    if (!product) return toast.error("প্যাকেজ বাছুন");
    if (!/^01[3-9]\d{8}$/.test(phone)) return toast.error("সঠিক মোবাইল নম্বর দিন");
    if (photos.length < 1) return toast.error("অন্তত ১টি পণ্যের ছবি দিন");
    if (!productName) return toast.error("পণ্যের নাম দিন");
    if (!rights) return toast.error("অধিকার সম্পর্কিত চেকবক্স টিক করুন");

    // If the customer already has a valid session for this exact phone,
    // skip the OTP step and create the order directly.
    const s = getCustomerSession();
    if (s.token && s.phone === phone) {
      createOrder(s.token);
      return;
    }
    // Otherwise send an OTP (reuses the account login flow).
    await sendOtp();
  }

  async function sendOtp() {
    setOtpSending(true);
    setOtp("");
    try {
      const r = await sendLoginCode(phone, { purpose: "login" });
      if (r.debugOtp) setDebugOtp(r.debugOtp);
      setAuthStep("otp");
      toast.success("OTP পাঠানো হয়েছে। ৫ মিনিট মেয়াদ।");
    } catch (e: any) {
      toast.error(e.message);
    }
    setOtpSending(false);
  }

  async function verifyOtp() {
    if (otp.length !== 6) return toast.error("৬ ডিজিটের OTP দিন");
    try {
      const token = await verifyLoginCode(phone, otp, "login");
      setCustomerSession(phone, token);
      setAuthStep("none");
      toast.success("ভেরিফাইড! অর্ডার তৈরি হচ্ছে…");
      createOrder(token);
    } catch (e: any) {
      toast.error(/wrong_code|no_otp|expired|max_attempts/.test(e.message) ? "ভুল OTP। আবার চেষ্টা করুন।" : e.message);
    }
  }

  // Phase 1C Item 1: phone comes ONLY from the token (server-side), never
  // from this request body — we send `token`, not `phone`.
  async function createOrder(token: string) {
    setSubmitting(true);
    try {
      const r = await api<{ order: { id: string; code: string }; paidWithCredit?: boolean }>("/api/orders/create", {
        method: "POST",
        body: JSON.stringify({
          token, name, productCode: product!.code,
          brief: { productName, category, priceOffer, target, tone, language, cta, phoneOrPage: pageLink || phone, notes, rightsConfirmed: rights },
          photos, logo,
        }),
      });
      if (r.paidWithCredit) {
        toast.success(`অর্ডার ${r.order.code} ক্রেডিটে পরিশোধিত!`);
        navigate(`#/account/orders/${r.order.id}`);
      } else {
        toast.success(`অর্ডার ${r.order.code} তৈরি! এখন bKash-এ পেমেন্ট করুন।`);
        const cfg = await getPublicConfig().catch(() => null);
        if (cfg?.paymentMode === "bkash_api") startPayment(r.order.id);
        else navigate(`#/account/orders/${r.order.id}`);
      }
    } catch (e: any) {
      toast.error(e.message);
      setSubmitting(false);
    }
  }

  async function startPayment(orderId: string) {
    try {
      const r = await api<{ payUrl: string; amount: number; provider: string }>("/api/payment/create", {
        method: "POST",
        body: JSON.stringify({ orderId }),
      });
      // mock: payUrl is /api/payment/mock-callback — auto-redirect
      // live: payUrl is the bKash gateway
      window.location.href = r.payUrl;
    } catch (e: any) {
      toast.error("পেমেন্ট শুরু হয়নি: " + e.message);
      setSubmitting(false);
    }
  }

  if (!product) {
    return <div className="mx-auto max-w-2xl px-4 py-10"><div className="h-64 animate-pulse rounded-xl bg-muted" /></div>;
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <div className="text-center">
        <Badge className="bg-primary/10 text-primary">{product.nameBn || product.name}</Badge>
        <h1 className="mt-2 text-2xl font-bold md:text-3xl">অর্ডার ফর্ম</h1>
        <p className="mt-1 text-sm text-muted-foreground">৳{product.priceBdt.toLocaleString("en-BD")} · {product.deliverySla} ডেলিভারি · {product.revisions} রিভিশন</p>
      </div>

      <Card className="mt-6">
        <CardHeader><div className="font-semibold">আপনার তথ্য</div></CardHeader>
        <CardContent className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <Label>মোবাইল *</Label>
              <Input className="mt-1" inputMode="numeric" placeholder="01XXXXXXXXX" value={phone} onChange={(e) => setPhone(e.target.value.replace(/[^\d]/g, ""))} maxLength={11} />
            </div>
            <div>
              <Label>নাম</Label>
              <Input className="mt-1" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="mt-4">
        <CardHeader><div className="font-semibold">পণ্যের বিবরণ</div></CardHeader>
        <CardContent className="space-y-3">
          <div>
            <Label>পণ্যের নাম *</Label>
            <Input className="mt-1" value={productName} onChange={(e) => setProductName(e.target.value)} placeholder="যেমন: লাল শাড়ি, মাস্টার পিস" />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <Label>ক্যাটেগরি</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>{categories.map((c) => <SelectItem key={c.id} value={c.id}>{c.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>দাম / অফার (ঐচ্ছিক)</Label>
              <Input className="mt-1" value={priceOffer} onChange={(e) => setPriceOffer(e.target.value)} placeholder="যেমন: ৳999, ফ্রি ডেলিভারি" />
            </div>
          </div>
          <div>
            <Label>পণ্যের ছবি * ({photos.length}/5)</Label>
            <div className="mt-2 grid grid-cols-5 gap-2">
              {photos.map((p, i) => (
                <div key={i} className="aspect-square overflow-hidden rounded-lg border">
                  <img src={p} alt={`photo-${i}`} className="h-full w-full object-cover" />
                </div>
              ))}
              {photos.length < 5 && (
                <label className="flex aspect-square cursor-pointer items-center justify-center rounded-lg border-2 border-dashed text-muted-foreground hover:bg-muted">
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && addPhoto(e.target.files[0])} />
                  <ImageIcon className="h-5 w-5" />
                </label>
              )}
            </div>
          </div>
          <div>
            <Label>লোগো (ঐচ্ছিক)</Label>
            <div className="mt-2 flex items-center gap-2">
              {logo ? (
                <img src={logo} alt="logo" className="h-12 w-12 rounded border object-contain" />
              ) : (
                <label className="flex h-12 w-12 cursor-pointer items-center justify-center rounded border-2 border-dashed text-muted-foreground hover:bg-muted">
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && addLogo(e.target.files[0])} />
                  <Upload className="h-4 w-4" />
                </label>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="mt-4">
        <CardHeader><div className="font-semibold">বিজ্ঞাপনের ধরন</div></CardHeader>
        <CardContent className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-3">
            <div>
              <Label>টার্গেট ক্রেতা</Label>
              <Input className="mt-1" value={target} onChange={(e) => setTarget(e.target.value)} />
            </div>
            <div>
              <Label>টোন</Label>
              <Select value={tone} onValueChange={setTone}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>{tones.map((t) => <SelectItem key={t.id} value={t.id}>{t.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>ভাষা</Label>
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>{langs.map((l) => <SelectItem key={l.id} value={l.id}>{l.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <Label>কল টু অ্যাকশন</Label>
              <Input className="mt-1" value={cta} onChange={(e) => setCta(e.target.value)} placeholder="ইনবক্স করুন" />
            </div>
            <div>
              <Label>ফোন / পেজ লিংক (শেষে দেখাবে)</Label>
              <Input className="mt-1" value={pageLink} onChange={(e) => setPageLink(e.target.value)} placeholder="01XXX / facebook.com/..." />
            </div>
          </div>
          <div>
            <Label>অতিরিক্ত নোট (ঐচ্ছিক)</Label>
            <Textarea className="mt-1" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
          <label className="flex items-start gap-2 text-xs text-muted-foreground">
            <Checkbox checked={rights} onCheckedChange={(v) => setRights(!!v)} className="mt-0.5" />
            <span>আমি নিশ্চিত করছি যে এই ছবিগুলি আমার নিজের এবং পণ্যটি বৈধ।</span>
          </label>
        </CardContent>
      </Card>

      {/* Phase 1C Item 1: phone+OTP login before submitting. The brief
          above stays filled while the customer verifies their phone. */}
      {authStep === "otp" && (
        <Card className="mt-4 border-primary/40">
          <CardHeader><div className="flex items-center gap-2 text-sm font-semibold"><Phone className="h-4 w-4 text-primary" /> ফোন যাচাই</div></CardHeader>
          <CardContent className="space-y-3 text-center">
            <p className="text-xs text-muted-foreground">{phone} এ ৬ ডিজিট OTP পাঠানো হয়েছে।</p>
            {debugOtp && <p className="rounded bg-amber-100 px-2 py-1 text-[11px] text-amber-800">MOCK OTP: <b>{debugOtp}</b></p>}
            <InputOTP maxLength={6} value={otp} onChange={(v) => setOtp(v)}>
              <InputOTPGroup>{Array.from({length:6}).map((_,i)=><InputOTPSlot key={i} index={i} />)}</InputOTPGroup>
            </InputOTP>
            <Button className="w-full" onClick={verifyOtp}><ShieldIcon className="mr-2 h-4 w-4" /> যাচাই করে অর্ডার করুন</Button>
            <Button variant="link" size="sm" onClick={sendOtp} disabled={otpSending}>পুনরায় OTP পাঠান</Button>
          </CardContent>
        </Card>
      )}

      <Card className="mt-4">
        <CardHeader><div className="flex items-center justify-between"><span className="font-semibold">পেমেন্ট</span><CreditCard className="h-5 w-5 text-primary" /></div></CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between rounded-lg bg-muted/60 p-3">
            <div className="text-sm">
              <div className="font-semibold">{product.nameBn || product.name}</div>
              <div className="text-xs text-muted-foreground">{product.deliverySla} ডেলিভারি · {product.revisions} রিভিশন</div>
            </div>
            <div className="text-lg font-extrabold">৳{product.priceBdt.toLocaleString("en-BD")}</div>
          </div>
          {product.code === "LAUNCH" && (
            <div className="rounded-lg bg-primary/10 p-2 text-xs text-primary">
              🎉 লঞ্চ দাম — প্রথম ১০ জনের জন্য।
            </div>
          )}
          <Button className="w-full" size="lg" disabled={submitting || otpSending || authStep === "otp"} onClick={submit}>
            {otpSending ? <ShieldCheck className="mr-2 h-4 w-4 animate-pulse" /> : <ShieldCheck className="mr-2 h-4 w-4" />}
            {otpSending ? "OTP পাঠানো হচ্ছে…" : authStep === "otp" ? "OTP যাচাই করুন ↑" : "অর্ডার কনফার্ম করুন"}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
          <p className="text-center text-[11px] text-muted-foreground">
            পরের ধাপে bKash QR / নম্বরে পেমেন্ট করে TrxID জমা দেবেন।
          </p>
        </CardContent>
      </Card>

      <div className="mt-4 text-center">
        <Button variant="link" onClick={() => navigate("#/preview")}>আগে ফ্রি প্রিভিউ দেখুন</Button>
      </div>
    </div>
  );
}
