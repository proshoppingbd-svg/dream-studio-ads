"use client";
// components/views/order-detail.tsx — single order detail for customers
import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { api, getCustomerSession } from "@/hooks/use-api";
import { statusLabelBn, statusColor, isOverdue, statusMessageBn } from "@/lib/status";
import { PayQr } from "@/components/pay-qr";
import { Download, RotateCcw, AlertCircle, CheckCircle2, Clock } from "lucide-react";

const STATUS_ORDER = [
  "PENDING_PAYMENT", "PAYMENT_SUBMITTED", "PAID", "SCRIPTING", "SCRIPT_READY",
  "GENERATING", "QC", "EDITING", "DELIVERED", "CLOSED",
];

export function OrderDetailView({ id, navigate, query }: { id: string; navigate: (to: string) => void; query: Record<string, string> }) {
  const [data, setData] = useState<any | null>(null);
  const [revNote, setRevNote] = useState("");
  const s = getCustomerSession();

  const load = useCallback(async () => {
    try {
      const r = await api<any>(`/api/orders/${id}?token=${encodeURIComponent(s.token || "")}`);
      setData(r);
    } catch (e: any) { toast.error(e.message); }
  }, [id, s.token]);

  useEffect(() => {
    if (query.paid === "1") toast.success("পেমেন্ট সফল! অর্ডার প্রসেস হচ্ছে।");
    if (query.paid === "0") toast.error("পেমেন্ট ব্যর্থ: " + (query.err || ""));
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load();
    const t = setInterval(load, 15000);
    return () => clearInterval(t);
  }, [load, query.paid, query.err]);

  async function requestRevision() {
    if (!revNote.trim()) return toast.error("কি পরিবর্তন চান লিখুন");
    try {
      await api(`/api/orders/${id}`, {
        method: "POST",
        body: JSON.stringify({ note: revNote, token: s.token }),
      });
      toast.success("রিভিশন অনুরোধ পাঠানো হয়েছে");
      setRevNote("");
      load();
    } catch (e: any) { toast.error(e.message); }
  }

  if (!data) return <div className="mx-auto max-w-2xl px-4 py-10"><div className="h-64 animate-pulse rounded-xl bg-muted" /></div>;
  const o = data.order;
  const stepIdx = STATUS_ORDER.indexOf(o.status);
  const progress = o.status === "DELIVERED" || o.status === "CLOSED" ? 100 : Math.max(0, stepIdx) / (STATUS_ORDER.length - 1) * 100;
  const overdue = isOverdue(o.slaDeadline);
  const revisionsLeft = o.revisionsMax - o.revisionsUsed;
  const canRevise = (o.status === "DELIVERED" || o.status === "CLOSED") && revisionsLeft > 0;

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">{o.code}</h1>
          <p className="text-xs text-muted-foreground">{o.product?.nameBn || o.product?.name} · ৳{o.product?.priceBdt}</p>
        </div>
        <Badge className={statusColor[o.status]}>{statusLabelBn[o.status] || o.status}</Badge>
      </div>

      {/* What's happening now */}
      {statusMessageBn[o.status] && (
        <p className="mt-3 rounded-lg bg-muted/60 p-3 text-sm">{statusMessageBn[o.status]}</p>
      )}

      {/* Manual bKash QR payment */}
      {o.status === "PENDING_PAYMENT" && (
        <PayQr
          orderId={o.id}
          orderCode={o.code}
          amount={o.product?.priceBdt || 0}
          rejectReason={data.payment?.rejectReason}
          onSubmitted={load}
        />
      )}

      {/* SLA countdown */}
      {o.paidAt && o.status !== "DELIVERED" && o.status !== "CLOSED" && o.status !== "REJECTED" && o.status !== "REFUNDED" && (
        <Card className="mt-4"><CardContent className="p-4">
          <div className="flex items-center justify-between text-xs">
            <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> SLA: {o.product?.deliverySla}</span>
            <span className={overdue ? "font-bold text-destructive" : "text-muted-foreground"}>
              {overdue ? "সময় পার হয়েছে" : `ডেডলাইন: ${new Date(o.slaDeadline).toLocaleString("en-GB")}`}
            </span>
          </div>
          <Progress value={progress} className="mt-2" />
        </CardContent></Card>
      )}

      {/* Status timeline */}
      <Card className="mt-4"><CardHeader><div className="text-sm font-semibold">স্ট্যাটাস টাইমলাইন</div></CardHeader>
        <CardContent>
          <ol className="relative space-y-2">
            {STATUS_ORDER.map((st, i) => {
              const done = i <= stepIdx;
              const active = i === stepIdx;
              return (
                <li key={st} className="flex items-center gap-2 text-xs">
                  {done ? <CheckCircle2 className="h-4 w-4 text-emerald-500" /> : <div className="h-4 w-4 rounded-full border" />}
                  <span className={active ? "font-bold" : "text-muted-foreground"}>{statusLabelBn[st] || st}</span>
                </li>
              );
            })}
          </ol>
        </CardContent>
      </Card>

      {/* Final video */}
      {o.status === "DELIVERED" && data.finalVideoUrl && (
        <Card className="mt-4"><CardHeader><div className="text-sm font-semibold">আপনার বিজ্ঞাপন</div></CardHeader>
          <CardContent className="space-y-3">
            <video src={data.finalVideoUrl} className="mx-auto aspect-[9/16] max-h-[420px] w-auto rounded-xl bg-black" controls playsInline />
            {data.finalVideo15Url && (
              <div>
                <p className="text-xs text-muted-foreground">১৫সে কাট (Premium):</p>
                <video src={data.finalVideo15Url} className="mx-auto aspect-[9/16] max-h-80 w-auto rounded bg-black" controls playsInline />
              </div>
            )}
            <Button className="w-full" onClick={() => window.open(data.finalVideoUrl, "_blank")}>
              <Download className="mr-2 h-4 w-4" /> ডাউনলোড করুন
            </Button>
          </CardContent>
        </Card>
      )}

      {o.status === "REJECTED" && (
        <Card className="mt-4 border-destructive"><CardContent className="p-4 text-center">
          <AlertCircle className="mx-auto h-8 w-8 text-destructive" />
          <p className="mt-2 font-semibold">অর্ডার প্রত্যাখ্যাত</p>
          <p className="text-xs text-muted-foreground">আমাদের নিয়মাবলী অনুযায়ী এই পণ্য গ্রহণযোগ্য নয়। রিফান্ডের জন্য যোগাযোগ করুন।</p>
        </CardContent></Card>
      )}

      {/* Revision */}
      {canRevise ? (
        <Card className="mt-4"><CardHeader><div className="text-sm font-semibold">রিভিশন চান</div></CardHeader>
          <CardContent className="space-y-3">
            <p className="text-xs text-muted-foreground">বাকি রিভিশন: {revisionsLeft}</p>
            <Textarea rows={3} maxLength={500} placeholder="কি পরিবর্তন চান লিখুন (সর্বোচ্চ ৫০০ অক্ষর)" value={revNote} onChange={(e) => setRevNote(e.target.value)} />
            <Button className="w-full" onClick={requestRevision}><RotateCcw className="mr-2 h-4 w-4" /> রিভিশন অনুরোধ</Button>
          </CardContent>
        </Card>
      ) : (o.status === "DELIVERED" || o.status === "CLOSED") && revisionsLeft === 0 ? (
        <Card className="mt-4"><CardContent className="p-4 text-center">
          <p className="text-xs text-muted-foreground">রিভিশন শেষ। নতুন বিজ্ঞাপন চাইলে অর্ডার করুন।</p>
          <Button className="mt-2" variant="outline" onClick={() => navigate("#/order/STANDARD")}>নতুন অর্ডার</Button>
        </CardContent></Card>
      ) : null}

      <div className="mt-4 text-center">
        <Button variant="link" onClick={() => navigate("#/account")}>অর্ডার তালিকায় ফিরুন</Button>
      </div>
    </div>
  );
}
