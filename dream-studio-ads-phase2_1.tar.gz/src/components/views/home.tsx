"use client";
// components/views/home.tsx — landing page
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Upload, Play, CreditCard, Clock, Sparkles, Check, Star, Film } from "lucide-react";
import { api } from "@/hooks/use-api";

interface PublicContent {
  products: any[];
  samples: any[];
  faqs: any[];
  testimonials: any[];
  settings: Record<string, string>;
}

const categories = [
  { id: "all", label: "সব" },
  { id: "clothing", label: "পোশাক" },
  { id: "cosmetics", label: "কসমেটিকস" },
  { id: "food", label: "খাবার" },
  { id: "electronics", label: "ইলেকট্রনিক্স" },
  { id: "restaurant", label: "রেস্টুরেন্ট" },
  { id: "other", label: "অন্যান্য" },
];

export function HomeView({ navigate }: { navigate: (to: string) => void }) {
  const [data, setData] = useState<PublicContent | null>(null);
  const [cat, setCat] = useState("all");

  useEffect(() => {
    api<PublicContent>("/api/public/content").then(setData).catch(console.error);
  }, []);

  if (!data) {
    return (
      <div className="space-y-4 p-6">
        <div className="h-72 animate-pulse rounded-2xl bg-muted" />
        <div className="h-8 w-2/3 animate-pulse rounded bg-muted" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[1,2,3].map(i => <div key={i} className="h-48 animate-pulse rounded-xl bg-muted" />)}
        </div>
      </div>
    );
  }

  const samples = data.samples.filter((s) => cat === "all" || s.category === cat);
  const launch = data.products.find((p) => p.code === "LAUNCH");

  return (
    <div>
      {/* ─── Hero ──────────────────────────────────────────── */}
      <section className="relative overflow-hidden studio-gradient text-white">
        <div className="mx-auto max-w-6xl px-4 py-10 md:py-16">
          <div className="grid items-center gap-6 md:grid-cols-2">
            <div>
              <Badge className="mb-3 bg-primary/20 text-primary-foreground border-primary/30">
                <Sparkles className="mr-1 h-3 w-3" /> AI-powered · Bangladesh
              </Badge>
              <h1 className="text-3xl font-extrabold leading-tight md:text-4xl lg:text-5xl">
                শুটিং ছাড়া, মডেল ছাড়া — আপনার পণ্যের{" "}
                <span className="studio-gold-text">৩০ সেকেন্ডের বাংলা ভিডিও বিজ্ঞাপন</span>
              </h1>
              <p className="mt-3 text-sm text-white/80 md:text-base">
                শুধু পণ্যের ছবি দিন। ১ মিনিটে ফ্রি প্রিভিউ দেখুন। পছন্দ হলে bKash এ পেমেন্ট করুন, ৪৮ ঘণ্টায় সম্পূর্ণ বিজ্ঞাপন পান।
              </p>
              <div className="mt-5 flex flex-col gap-3 sm:flex-row">
                <Button size="lg" className="text-base" onClick={() => navigate("#/preview")}>
                  <Upload className="mr-2 h-5 w-5" /> পণ্যের ছবি দিন — ১ মিনিটে ফ্রি প্রিভিউ
                </Button>
                <Button size="lg" variant="secondary" onClick={() => navigate("#/order/STANDARD")}>
                  অর্ডার করুন
                </Button>
              </div>
              <div className="mt-4 flex items-center gap-4 text-xs text-white/70">
                <span className="flex items-center gap-1"><Check className="h-3 w-3" /> ফ্রি প্রিভিউ</span>
                <span className="flex items-center gap-1"><Check className="h-3 w-3" /> ৪৮ ঘণ্টায় ডেলিভারি</span>
                <span className="flex items-center gap-1"><Check className="h-3 w-3" /> bKash পেমেন্ট</span>
              </div>
            </div>
            <div className="relative">
              <div className="relative mx-auto aspect-[9/16] max-w-[280px] overflow-hidden rounded-2xl border-2 border-white/10 shadow-2xl">
                <img src="/samples/hero.png" alt="Before/after product ad" className="h-full w-full object-cover" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-3 left-3 right-3">
                  <div className="flex items-center gap-2 text-xs text-white/90">
                    <span className="rounded bg-primary px-2 py-0.5 font-semibold">BEFORE → AFTER</span>
                    <span>পণ্য ছবি → সম্পূর্ণ বিজ্ঞাপন</span>
                  </div>
                </div>
              </div>
              <div className="absolute -right-2 top-2 hidden rounded-lg bg-background/90 px-3 py-1 text-xs font-semibold text-foreground shadow md:block">
                ৯:১৬ · ভার্টিকাল
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ─── Sample gallery ───────────────────────────────── */}
      <section className="mx-auto max-w-6xl px-4 py-10">
        <div className="flex flex-col items-start justify-between gap-2 sm:flex-row sm:items-end">
          <div>
            <h2 className="text-2xl font-bold md:text-3xl">স্যাম্পল গ্যালারি</h2>
            <p className="mt-1 text-sm text-muted-foreground">ক্যাটেগরি অনুযায়ী আমাদের তৈরি বিজ্ঞাপন</p>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {categories.map((c) => (
            <Button
              key={c.id}
              variant={cat === c.id ? "default" : "outline"}
              size="sm"
              onClick={() => setCat(c.id)}
            >
              {c.label}
            </Button>
          ))}
        </div>
        <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {samples.map((s) => (
            <Card key={s.id} className="overflow-hidden p-0">
              <div className="relative aspect-[9/16] bg-muted">
                {s.posterUrl ? (
                  <img src={s.posterUrl} alt={s.title} className="h-full w-full object-cover" loading="lazy" />
                ) : (
                  <div className="flex h-full items-center justify-center"><Film className="h-8 w-8 text-muted-foreground" /></div>
                )}
                <video
                  src={s.videoUrl}
                  poster={s.posterUrl}
                  className="absolute inset-0 h-full w-full object-cover"
                  controls
                  playsInline
                  preload="none"
                />
              </div>
              <div className="p-2 text-xs">
                <div className="truncate font-medium">{s.title}</div>
                <div className="text-muted-foreground">{categories.find((c) => c.id === s.category)?.label}</div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* ─── 3 steps ──────────────────────────────────────── */}
      <section className="bg-muted/40 py-10">
        <div className="mx-auto max-w-6xl px-4">
          <h2 className="text-center text-2xl font-bold md:text-3xl">৩ ধাপে আপনার বিজ্ঞাপন</h2>
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {[
              { icon: Upload, t: "ছবি আপলোড করুন", d: "পণ্যের ছবি, ক্যাটেগরি আর সি টি এ দিন।" },
              { icon: Play, t: "প্রিভিউ দেখুন", d: "১ মিনিটে ফ্রি প্রিভিউ। পছন্দ হলে অর্ডার।" },
              { icon: CreditCard, t: "bKash পেমেন্ট করুন", d: "৪৮ ঘণ্টায় সম্পূর্ণ বিজ্ঞাপন পান।" },
            ].map((s, i) => (
              <Card key={i} className="relative">
                <CardHeader>
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <s.icon className="h-5 w-5" />
                  </div>
                  <span className="absolute right-4 top-4 text-3xl font-black text-muted/40">{i + 1}</span>
                </CardHeader>
                <CardContent>
                  <div className="font-semibold">{s.t}</div>
                  <p className="mt-1 text-sm text-muted-foreground">{s.d}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="mt-6 text-center">
            <Button size="lg" onClick={() => navigate("#/preview")}>ফ্রি প্রিভিউ শুরু করুন</Button>
          </div>
        </div>
      </section>

      {/* ─── Price cards ──────────────────────────────────── */}
      <section className="mx-auto max-w-6xl px-4 py-10">
        <h2 className="text-center text-2xl font-bold md:text-3xl">প্যাকেজ ও দাম</h2>
        <p className="mt-1 text-center text-sm text-muted-foreground">শুরু হয় ৳0 থেকে। লুকিয়ে থাকা চার্জ নেই।</p>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {data.products
            .filter((p) => p.code !== "PREVIEW")
            .map((p) => {
              const isLaunch = p.code === "LAUNCH";
              const comingSoon = p.code === "EXPRESS";
              const featured = p.code === "STANDARD" || p.code === "PREMIUM";
              return (
                <Card
                  key={p.id}
                  className={
                    "relative flex flex-col " +
                    (featured ? "border-primary shadow-md ring-1 ring-primary/20" : "")
                  }
                >
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="font-bold">{p.nameBn || p.name}</div>
                      {comingSoon && <Badge variant="secondary">শিগ্রই</Badge>}
                      {isLaunch && <Badge className="bg-primary text-primary-foreground">লঞ্চ অফার</Badge>}
                    </div>
                    <p className="text-xs text-muted-foreground">{p.description}</p>
                  </CardHeader>
                  <CardContent className="flex-1">
                    <div className="flex items-baseline gap-1">
                      <span className="text-2xl font-extrabold">৳{p.priceBdt.toLocaleString("en-BD")}</span>
                      {p.code === "MONTHLY" && <span className="text-xs text-muted-foreground">/মাস</span>}
                    </div>
                    <ul className="mt-3 space-y-1 text-xs text-muted-foreground">
                      <li className="flex items-center gap-1"><Check className="h-3 w-3 text-primary" /> {p.revisions} ফ্রি রিভিশন</li>
                      <li className="flex items-center gap-1"><Clock className="h-3 w-3 text-primary" /> {p.deliverySla} ডেলিভারি</li>
                      <li className="flex items-center gap-1"><Check className="h-3 w-3 text-primary" /> ৯:১৬ ভার্টিকাল MP4</li>
                      {p.code === "PREMIUM" && <li className="flex items-center gap-1"><Check className="h-3 w-3 text-primary" /> ১৫সে কাট সংস্করণ</li>}
                      {p.code === "MONTHLY" && <li className="flex items-center gap-1"><Check className="h-3 w-3 text-primary" /> ৪টি স্ট্যান্ডার্ড বিজ্ঞাপন</li>}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button
                      className="w-full"
                      disabled={comingSoon}
                      variant={featured ? "default" : "outline"}
                      onClick={() => navigate(`#/order/${p.code}`)}
                    >
                      {comingSoon ? "শিগ্রই" : "অর্ডার করুন"}
                    </Button>
                  </CardFooter>
                </Card>
              );
            })}
        </div>
        <p className="mt-4 text-center text-xs text-muted-foreground">
          bKash-এ পেমেন্ট · লঞ্চ দাম প্রথম ১০ জনের জন্য।
        </p>
      </section>

      {/* ─── Testimonials ─────────────────────────────────── */}
      {data.testimonials.length > 0 && (
        <section className="bg-muted/40 py-10">
          <div className="mx-auto max-w-6xl px-4">
            <h2 className="text-center text-2xl font-bold md:text-3xl">গ্রাহকদের মতামত</h2>
            <Carousel className="mx-auto mt-6 max-w-4xl">
              <CarouselContent>
                {data.testimonials.map((t) => (
                  <CarouselItem key={t.id} className="md:basis-1/2">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex gap-1">
                          {Array.from({ length: t.rating }).map((_, i) => (
                            <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                          ))}
                        </div>
                        <p className="mt-3 text-sm italic">“{t.quote}”</p>
                        <div className="mt-3 text-xs">
                          <div className="font-semibold">{t.name}</div>
                          <div className="text-muted-foreground">{t.role}</div>
                        </div>
                      </CardContent>
                    </Card>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious />
              <CarouselNext />
            </Carousel>
          </div>
        </section>
      )}

      {/* ─── FAQ ──────────────────────────────────────────── */}
      {data.faqs.length > 0 && (
        <section className="mx-auto max-w-3xl px-4 py-10">
          <h2 className="text-center text-2xl font-bold md:text-3xl">প্রশ্ন ও উত্তর</h2>
          <Accordion type="single" collapsible className="mt-6">
            {data.faqs.map((f, i) => (
              <AccordionItem key={f.id} value={`item-${i}`}>
                <AccordionTrigger className="text-left">{f.question}</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground">{f.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </section>
      )}

      {/* ─── CTA ──────────────────────────────────────────── */}
      <section className="studio-gradient text-white">
        <div className="mx-auto max-w-3xl px-4 py-12 text-center">
          <h2 className="text-2xl font-bold md:text-3xl">এখনই শুরু করুন</h2>
          <p className="mt-2 text-sm text-white/80">১ মিনিটের ফ্রি প্রিভিউ। কার্ড বা কিছু লাগে না।</p>
          <Button size="lg" className="mt-4" onClick={() => navigate("#/preview")}>
            <Upload className="mr-2 h-5 w-5" /> ফ্রি প্রিভিউ শুরু করুন
          </Button>
        </div>
      </section>
    </div>
  );
}
