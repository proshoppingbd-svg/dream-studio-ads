"use client";
// components/views/studio.tsx — hidden "coming soon" + waitlist
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { api } from "@/hooks/use-api";
import { Sparkles, Bell } from "lucide-react";

export function StudioView({ navigate }: { navigate: (to: string) => void }) {
  const [phone, setPhone] = useState("");
  const [name, setName] = useState("");
  const [note, setNote] = useState("");
  const [done, setDone] = useState(false);

  async function join() {
    if (!phone) return toast.error("মোবাইল দিন");
    try {
      await api("/api/studio/waitlist", { method: "POST", body: JSON.stringify({ phone, name, note }) });
      setDone(true);
      toast.success("ওয়েটলিস্টে যুক্ত হয়েছেন!");
    } catch (e: any) { toast.error(e.message); }
  }

  return (
    <div className="mx-auto max-w-md px-4 py-16 text-center">
      <Sparkles className="mx-auto h-12 w-12 text-primary" />
      <h1 className="mt-4 text-3xl font-bold">Studio</h1>
      <p className="mt-2 text-sm text-muted-foreground">সেলফ-সার্ভ ক্রেডিট প্ল্যাটফর্ম — শীঘ্রই আসছে।</p>

      {!done ? (
        <Card className="mt-8 text-left"><CardHeader><div className="flex items-center gap-2 text-sm font-semibold"><Bell className="h-4 w-4 text-primary" /> ওয়েটলিস্টে যুক্ত হন</div></CardHeader>
          <CardContent className="space-y-3">
            <div><Label>মোবাইল *</Label><Input className="mt-1" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="01XXXXXXXXX" /></div>
            <div><Label>নাম</Label><Input className="mt-1" value={name} onChange={(e) => setName(e.target.value)} /></div>
            <div><Label>নোট</Label><Textarea className="mt-1" rows={2} value={note} onChange={(e) => setNote(e.target.value)} placeholder="কতগুলি বিজ্ঞাপন মাসে লাগে?" /></div>
            <Button className="w-full" onClick={join}>যুক্ত হন</Button>
          </CardContent>
        </Card>
      ) : (
        <Card className="mt-8"><CardContent className="p-6">
          <p className="font-semibold">ধন্যবাদ! 🎉</p>
          <p className="mt-1 text-sm text-muted-foreground">লঞ্চের সময় আমরা আপনাকে জানাব।</p>
        </CardContent></Card>
      )}

      <Button variant="link" className="mt-4" onClick={() => navigate("#/")}>হোমে ফিরুন</Button>
    </div>
  );
}
