"use client";
// components/views/preview.tsx — free preview flow (the sales engine)
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { Upload, Phone, ShieldCheck, Sparkles, ArrowRight, AlertTriangle } from "lucide-react";
import { api, compressImage, setCustomerSession } from "@/hooks/use-api";
import { sendLoginCode, verifyLoginCode } from "@/lib/phoneAuth";

const categories = [
  { id: "clothing", label: "পোশাক" },
  { id: "cosmetics", label: "কসমেটিকস" },
  { id: "food", label: "খাবার" },
  { id: "electronics", label: "ইলেকট্রনিক্স" },
  { id: "restaurant", label: "রেস্টুরেন্ট" },
  { id: "other", label: "অন্যান্য" },
];

type Step = "upload" | "phone" | "otp" | "generating" | "ready" | "rejected" | "failed";

export function PreviewView({ navigate }: { navigate: (to: string) => void }) {
  const [step, setStep] = useState<Step>("upload");
  const [photo, setPhoto] = useState<string | null>(null);
  const [category, setCategory] = useState("clothing");
  const [promptText, setPromptText] = useState("");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [debugOtp, setDebugOtp] = useState<string | null>(null);
  const [previewId, setPreviewId] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [progress, setProgress] = useState(5);
  const [rejectReason, setRejectReason] = useState("");
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => () => { if (pollRef.current) clearInterval(pollRef.current); }, []);

  async function onPickPhoto(file: File) {
    try {
      const dataUrl = await compressImage(file, 1280, 1280, 0.85);
      setPhoto(dataUrl);
    } catch (e: any) {
      toast.error("ছবি লোড হয়নি: " + e.message);
    }
  }

  async function sendOtp() {
    if (!photo) return toast.error("আগে পণ্যের ছবি দিন");
    if (!/^01[3-9]\d{8}$/.test(phone)) return toast.error("সঠিক বাংলাদেশি মোবাইল নম্বর দিন");
    try {
      const r = await sendLoginCode(phone, { purpose: "preview", category });
      if (r.debugOtp) setDebugOtp(r.debugOtp);
      setStep("otp");
      toast.success("OTP পাঠানো হয়েছে। ৫ মিনিট মেয়াদ।");
    } catch (e: any) {
      if (e.message === "already_used_preview") {
        toast.error("এই নম্বরে একবার ফ্রি প্রিভিউ ব্যবহার হয়েছে।");
        navigate("#/order/STANDARD");
      } else if (e.message === "ip_limit") {
        toast.error("আজ এই নেটওয়ার্ক থেকে ৩ বার প্রিভিউ নেওয়া হয়েছে।");
      } else if (e.message === "daily_cap") {
        toast.error("আজকের ফ্রি প্রিভিউ শেষ। আগামীকাল চেষ্টা করুন বা সরাসরি অর্ডার করুন।");
      } else {
        toast.error(e.message);
      }
    }
  }

  async function verifyOtp() {
    if (otp.length !== 6) return toast.error("৬ ডিজিটের OTP দিন");
    try {
      const token = await verifyLoginCode(phone, otp, "preview");
      setCustomerSession(phone, token);
      toast.success("ভেরিফাইড! প্রিভিউ তৈরি শুরু হচ্ছে…");
      generatePreview(token);
    } catch (e: any) {
      toast.error(/wrong_code|no_otp|expired|max_attempts/.test(e.message) ? "ভুল OTP। আবার চেষ্টা করুন।" : e.message);
    }
  }

  async function generatePreview(token: string) {
    setStep("generating");
    setProgress(8);
    try {
      const r = await api<{ ok: boolean; previewId: string }>("/api/preview/generate", {
        method: "POST",
        body: JSON.stringify({ token, category, photo, promptText }),
      });
      setPreviewId(r.previewId);
      // poll status
      pollRef.current = setInterval(async () => {
        try {
          const s = await api<{ status: string; videoUrl: string | null }>("/api/preview/status?id=" + r.previewId);
          setProgress((p) => Math.min(95, p + 8));
          if (s.status === "READY" && s.videoUrl) {
            setVideoUrl(s.videoUrl);
            setProgress(100);
            setStep("ready");
            if (pollRef.current) clearInterval(pollRef.current);
          } else if (s.status === "FAILED") {
            setStep("failed");
            if (pollRef.current) clearInterval(pollRef.current);
          }
        } catch {}
      }, 2500);
    } catch (e: any) {
      // rejection
      const payload = (e as any).payload;
      if (payload?.error === "rejected") {
        setRejectReason(payload.reason || "পণ্য গ্রহণযোগ্য নয়।");
        setStep("rejected");
      } else {
        setStep("failed");
        toast.error(e.message);
      }
    }
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <div className="text-center">
        <Badge2 />
        <h1 className="mt-2 text-2xl font-bold md:text-3xl">ফ্রি প্রিভিউ</h1>
        <p className="mt-1 text-sm text-muted-foreground">পণ্যের ছবি দিন, ১ মিনিটে একটি ৫ সেকেন্ডের ফ্রি ভিডিও পান।</p>
      </div>

      <Card className="mt-6">
        <CardContent className="p-4 md:p-6">
          {step === "upload" && (
            <div className="space-y-4">
              <div>
                <Label>পণ্যের ছবি *</Label>
                <label className="mt-2 block cursor-pointer">
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    className="hidden"
                    onChange={(e) => e.target.files?.[0] && onPickPhoto(e.target.files[0])}
                  />
                  <div className="flex aspect-[9/16] max-w-[220px] items-center justify-center rounded-xl border-2 border-dashed bg-muted text-center">
                    {photo ? (
                      <img src={photo} alt="product" className="h-full w-full rounded-xl object-cover" />
                    ) : (
                      <div className="px-3 text-xs text-muted-foreground">
                        <Upload className="mx-auto mb-1 h-6 w-6" />
                        ট্যাপ করে ছবি দিন
                      </div>
                    )}
                  </div>
                </label>
              </div>
              <div>
                <Label>ক্যাটেগরি</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {categories.map((c) => <SelectItem key={c.id} value={c.id}>{c.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>পণ্যের নাম / বিবরণ (ঐচ্ছিক)</Label>
                <Textarea className="mt-1" rows={2} value={promptText} onChange={(e) => setPromptText(e.target.value)} placeholder="যেমন: লাল শাড়ি, শুটকি, হাতে তৈরি কাপ" />
              </div>
              <Button className="w-full" size="lg" disabled={!photo} onClick={() => setStep("phone")}>
                চালিয়ে যান <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          )}

          {step === "phone" && (
            <div className="space-y-4">
              <div>
                <Label><Phone className="mr-1 inline h-3 w-3" /> মোবাইল নম্বর</Label>
                <Input className="mt-1" inputMode="numeric" placeholder="01XXXXXXXXX" value={phone} onChange={(e) => setPhone(e.target.value.replace(/[^\d]/g, ""))} maxLength={11} />
                <p className="mt-1 text-[11px] text-muted-foreground">ফ্রি প্রিভিউ প্রতি ফোনে একবার। আমরা OTP পাঠাব।</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setStep("upload")}>পেছনে</Button>
                <Button className="flex-1" onClick={sendOtp}>OTP পাঠান</Button>
              </div>
            </div>
          )}

          {step === "otp" && (
            <div className="space-y-4 text-center">
              <ShieldCheck className="mx-auto h-10 w-10 text-primary" />
              <div>
                <Label>OTP যাচাই</Label>
                <p className="text-xs text-muted-foreground">{phone} এ ৬ ডিজিট কোড পাঠানো হয়েছে।</p>
                {debugOtp && <p className="mt-1 rounded bg-amber-100 px-2 py-1 text-[11px] text-amber-800">MOCK OTP: <b>{debugOtp}</b></p>}
              </div>
              <InputOTP maxLength={6} value={otp} onChange={(v) => setOtp(v)}>
                <InputOTPGroup>
                  {Array.from({ length: 6 }).map((_, i) => <InputOTPSlot key={i} index={i} />)}
                </InputOTPGroup>
              </InputOTP>
              <Button className="w-full" onClick={verifyOtp}>যাচাই করুন</Button>
              <Button variant="link" size="sm" onClick={sendOtp}>পুনরায় OTP পাঠান</Button>
            </div>
          )}

          {step === "generating" && (
            <div className="space-y-4 text-center">
              <Sparkles className="mx-auto h-10 w-10 animate-pulse text-primary" />
              <div>
                <p className="font-semibold">আপনার প্রিভিউ তৈরি হচ্ছে…</p>
                <p className="text-xs text-muted-foreground">~১ মিনিট সময় লাগে।</p>
              </div>
              <Progress value={progress} className="mx-auto max-w-xs" />
              <p className="text-[11px] text-muted-foreground">AI আপনার পণ্য দেখে স্ক্রিপ্ট ও ভিডিও তৈরি করছে।</p>
            </div>
          )}

          {step === "ready" && videoUrl && (
            <div className="space-y-4">
              <div className="relative mx-auto max-w-[280px]">
                <div className="preview-watermark relative overflow-hidden rounded-xl">
                  <video src={videoUrl} poster={photo || undefined} className="aspect-[9/16] w-full rounded-xl bg-black object-contain" controls autoPlay playsInline />
                </div>
              </div>
              <div className="rounded-lg bg-muted/60 p-3 text-center text-xs text-muted-foreground">
                এটি ফ্রি প্রিভিউ — পানিরমার্ক সহ। পুরো ৩০ সেকেন্ডের বিজ্ঞাপন চাইলে অর্ডার করুন।
              </div>
              <Button className="w-full" size="lg" onClick={() => navigate(`#/order/STANDARD`)}>
                পুরো ৩০ সেকেন্ডের বিজ্ঞাপন চাই <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button variant="link" className="w-full" onClick={() => navigate("#/")}>হোমে ফিরুন</Button>
            </div>
          )}

          {step === "rejected" && (
            <div className="space-y-4 text-center">
              <AlertTriangle className="mx-auto h-10 w-10 text-destructive" />
              <p className="font-semibold">পণ্য গ্রহণযোগ্য নয়</p>
              <p className="text-sm text-muted-foreground">{rejectReason}</p>
              <Button variant="outline" onClick={() => navigate("#/order/STANDARD")}>সরাসরি অর্ডার করুন</Button>
              <Button variant="link" onClick={() => navigate("#/")}>হোমে ফিরুন</Button>
            </div>
          )}

          {step === "failed" && (
            <div className="space-y-4 text-center">
              <AlertTriangle className="mx-auto h-10 w-10 text-amber-500" />
              <p className="font-semibold">কিছু সমস্যা হয়েছে</p>
              <p className="text-xs text-muted-foreground">আবার চেষ্টা করুন।</p>
              <Button onClick={() => { setStep("upload"); setPhoto(null); }}>আবার চেষ্টা করুন</Button>
              <Button variant="link" onClick={() => navigate("#/order/STANDARD")}>সরাসরি অর্ডার করুন</Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function Badge2() {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-3 py-0.5 text-xs font-medium text-primary">
      <Sparkles className="h-3 w-3" /> ফ্রি · ১ মিনিট
    </span>
  );
}
