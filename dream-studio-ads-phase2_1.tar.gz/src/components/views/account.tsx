"use client";
// components/views/account.tsx — OTP login + order list
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { toast } from "sonner";
import { api, setCustomerSession, getCustomerSession, clearCustomerSession } from "@/hooks/use-api";
import { sendLoginCode, verifyLoginCode } from "@/lib/phoneAuth";
import { statusLabelBn, statusColor } from "@/lib/status";
import { Phone, ShieldCheck, ArrowRight } from "lucide-react";

export function AccountView({ navigate }: { navigate: (to: string) => void }) {
  const existing = getCustomerSession();
  const [authed, setAuthed] = useState(!!existing.token && !!existing.phone);
  const [phone, setPhone] = useState(existing.phone || "");
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState("");
  const [debugOtp, setDebugOtp] = useState<string | null>(null);
  const [orders, setOrders] = useState<any[]>([]);
  const [planCredits, setPlanCredits] = useState(0);
  const [planExpiresAt, setPlanExpiresAt] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function sendOtp() {
    if (!/^01[3-9]\d{8}$/.test(phone)) return toast.error("সঠিক মোবাইল দিন");
    try {
      const r = await sendLoginCode(phone, { purpose: "login" });
      if (r.debugOtp) setDebugOtp(r.debugOtp);
      setOtpSent(true);
      toast.success("OTP পাঠানো হয়েছে");
    } catch (e: any) { toast.error(e.message); }
  }

  async function verifyOtp() {
    if (otp.length !== 6) return toast.error("৬ ডিজিট OTP");
    try {
      const token = await verifyLoginCode(phone, otp, "login");
      setCustomerSession(phone, token);
      setAuthed(true);
      loadOrders();
    } catch (e: any) { toast.error(/wrong_code|no_otp|expired|max_attempts/.test(e.message) ? "ভুল OTP" : e.message); }
  }

  async function loadOrders() {
    const s = getCustomerSession();
    setLoading(true);
    try {
      const r = await api<{ orders: any[]; planCredits?: number; planExpiresAt?: string | null }>(`/api/orders/list?token=${encodeURIComponent(s.token || "")}`);
      setOrders(r.orders);
      setPlanCredits(r.planCredits ?? 0);
      setPlanExpiresAt(r.planExpiresAt ?? null);
    } catch (e: any) { toast.error(e.message); }
    setLoading(false);
  }

  if (authed) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">আমার অর্ডার</h1>
            <p className="text-sm text-muted-foreground">{phone}</p>
          </div>
          <Button variant="outline" size="sm" onClick={() => { clearCustomerSession(); setAuthed(false); setOrders([]); }}>লগআউট</Button>
        </div>

        {/* Item 13: show monthly plan credits left */}
        {(planCredits > 0 || planExpiresAt) && (
          <Card className="mt-4 border-primary/30 bg-primary/5">
            <CardContent className="flex items-center justify-between p-4">
              <div>
                <div className="text-sm font-semibold">মান্থলি প্ল্যান ক্রেডিট</div>
                <div className="text-xs text-muted-foreground">
                  {planExpiresAt
                    ? `মেয়াদ: ${new Date(planExpiresAt).toLocaleDateString("en-GB")}`
                    : "কোন সক্রিয় প্ল্যান নেই"}
                </div>
              </div>
              <div className="text-2xl font-extrabold text-primary">{planCredits}</div>
            </CardContent>
          </Card>
        )}

        {orders.length === 0 && !loading && (
          <Card className="mt-6 text-center"><CardContent className="py-10">
            <p className="text-sm text-muted-foreground">কোন অর্ডার নেই।</p>
            <Button className="mt-4" onClick={() => navigate("#/order/STANDARD")}>অর্ডার করুন</Button>
          </CardContent></Card>
        )}

        <div className="mt-6 space-y-3">
          {orders.map((o) => (
            <Card key={o.id} className="cursor-pointer hover:shadow-md" onClick={() => navigate(`#/account/orders/${o.id}`)}>
              <CardContent className="flex items-center justify-between p-4">
                <div>
                  <div className="font-semibold">{o.code}</div>
                  <div className="text-xs text-muted-foreground">{o.product?.nameBn || o.product?.name} · ৳{o.product?.priceBdt}</div>
                  <div className="mt-1 text-[11px] text-muted-foreground">
                    {new Date(o.createdAt).toLocaleDateString("en-GB")}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge className={statusColor[o.status]}>{statusLabelBn[o.status] || o.status}</Badge>
                  <ArrowRight className="h-4 w-4 text-muted-foreground" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        {loading && <p className="mt-4 text-center text-sm text-muted-foreground">লোড হচ্ছে…</p>}
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-md px-4 py-10">
      <div className="text-center">
        <h1 className="text-2xl font-bold">লগইন</h1>
        <p className="mt-1 text-sm text-muted-foreground">অর্ডার দেখতে OTP দিন</p>
      </div>
      <Card className="mt-6"><CardContent className="space-y-4 p-6">
        {!otpSent ? (
          <>
            <div>
              <Label><Phone className="mr-1 inline h-3 w-3" /> মোবাইল</Label>
              <Input className="mt-1" inputMode="numeric" value={phone} onChange={(e) => setPhone(e.target.value.replace(/[^\d]/g, ""))} maxLength={11} placeholder="01XXXXXXXXX" />
            </div>
            <Button className="w-full" onClick={sendOtp}>OTP পাঠান</Button>
          </>
        ) : (
          <div className="space-y-3 text-center">
            <ShieldCheck className="mx-auto h-8 w-8 text-primary" />
            <p className="text-sm">{phone} এ OTP পাঠানো হয়েছে</p>
            {debugOtp && <p className="rounded bg-amber-100 px-2 py-1 text-[11px] text-amber-800">MOCK OTP: <b>{debugOtp}</b></p>}
            <InputOTP maxLength={6} value={otp} onChange={setOtp}>
              <InputOTPGroup>{Array.from({length:6}).map((_,i)=><InputOTPSlot key={i} index={i} />)}</InputOTPGroup>
            </InputOTP>
            <Button className="w-full" onClick={verifyOtp}>লগইন</Button>
            <Button variant="link" size="sm" onClick={sendOtp}>পুনরায় OTP</Button>
          </div>
        )}
      </CardContent></Card>
      <div className="mt-4 text-center">
        <Button variant="link" onClick={() => navigate("#/order/STANDARD")}>অর্ডার করুন</Button>
      </div>
    </div>
  );
}
