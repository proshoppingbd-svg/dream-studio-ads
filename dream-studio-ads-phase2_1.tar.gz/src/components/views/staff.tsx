"use client";
// components/views/staff.tsx — Staff Dashboard (operator / editor / admin)
import { useEffect, useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardFooter, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableHeader, TableBody, TableRow, TableHead, TableCell,
} from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { api, uploadFile } from "@/hooks/use-api";
import { statusColor, statusLabelBn, isOverdue, whatsappLink, whatsappMessageBn } from "@/lib/status";
import { cn } from "@/lib/utils";
import {
  LogOut, ArrowLeft, ClipboardList, Film, Upload as UploadIcon,
  CheckCircle2, AlertCircle, Clock, RefreshCw, Sparkles, Download, Search,
  Settings as SettingsIcon, Package, FileText, DollarSign, ShieldCheck,
  BarChart3, Users, Loader2, Plus, Trash2, Save, ListChecks, ExternalLink,
  AlertTriangle, ShoppingCart, MessageCircle, FolderOpen, Wallet, Activity,
} from "lucide-react";

// ───────────────────────── Types ─────────────────────────
type Staff = { id: string; email: string; name: string; role: "operator" | "editor" | "admin" };

// ───────────────────────── Helpers ─────────────────────────
function fmtDate(d?: string | Date | null): string {
  if (!d) return "—";
  return new Date(d).toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
}
function fmtBdt(n: number): string {
  return "৳" + (n || 0).toLocaleString("en-IN");
}
function slaCountdown(deadline?: string | Date | null): { text: string; overdue: boolean; soon: boolean } {
  if (!deadline) return { text: "—", overdue: false, soon: false };
  const d = new Date(deadline);
  const diff = d.getTime() - Date.now();
  if (diff < 0) return { text: "অতিবাহিত", overdue: true, soon: false };
  const hours = Math.floor(diff / 3600000);
  const mins = Math.floor((diff % 3600000) / 60000);
  if (hours >= 24) return { text: `${Math.floor(hours / 24)} দিন ${hours % 24}ঘ`, overdue: false, soon: false };
  if (hours >= 1) return { text: `${hours}ঘ ${mins}মি`, overdue: false, soon: hours < 4 };
  return { text: `${mins} মি`, overdue: false, soon: true };
}
function Section({ title, icon: Icon, children }: { title: string; icon: any; children: React.ReactNode }) {
  return (
    <div className="mb-8">
      <div className="mb-3 flex items-center gap-2">
        <Icon className="h-4 w-4 text-muted-foreground" />
        <h2 className="text-sm font-semibold tracking-wide text-muted-foreground">{title}</h2>
      </div>
      {children}
    </div>
  );
}

// ───────────────────────── Login ─────────────────────────
function LoginScreen({ navigate, onLogin }: { navigate: (to: string) => void; onLogin: () => void }) {
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim() || !pw) return toast.error("ইমেইল ও পাসওয়ার্ড দিন");
    setBusy(true);
    try {
      await api("/api/staff/login", { method: "POST", body: JSON.stringify({ email: email.trim().toLowerCase(), password: pw }) });
      toast.success("লগইন সফল");
      onLogin();
    } catch (err: any) {
      toast.error(err.message || "লগইন ব্যর্থ");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="bangla mx-auto flex min-h-screen max-w-md flex-col justify-center px-4 py-10">
      <div className="text-center">
        <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-primary text-primary-foreground">
          <Film className="h-6 w-6" />
        </div>
        <h1 className="text-2xl font-bold">Dream Studio Staff</h1>
        <p className="mt-1 text-sm text-muted-foreground">অপারেটর / এডিটর / অ্যাডমিন ড্যাশবোর্ড</p>
      </div>

      <Card className="mt-6">
        <form onSubmit={submit}>
          <CardContent className="space-y-4 p-6">
            <div className="space-y-1.5">
              <Label htmlFor="se">ইমেইল</Label>
              <Input id="se" type="email" autoComplete="email" value={email}
                onChange={(e) => setEmail(e.target.value)} placeholder="admin@dreamstudio.bd" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="sp">পাসওয়ার্ড</Label>
              <Input id="sp" type="password" autoComplete="current-password" value={pw}
                onChange={(e) => setPw(e.target.value)} placeholder="••••••" />
            </div>
            <Button type="submit" className="w-full" disabled={busy}>
              {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              লগইন
            </Button>
          </CardContent>
        </form>
      </Card>

      <div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-[11px] leading-relaxed text-amber-900">
        <p className="font-semibold">ডেমো অ্যাকাউন্ট:</p>
        <p>admin@dreamstudio.bd / admin12345</p>
        <p>operator@dreamstudio.bd / operator12345</p>
        <p>editor@dreamstudio.bd / editor12345</p>
      </div>

      <div className="mt-4 text-center">
        <Button variant="link" size="sm" onClick={() => navigate("#/")}>← সাইটে ফিরুন</Button>
      </div>
    </div>
  );
}

// ───────────────────────── Top bar ─────────────────────────
function TopBar({ me, onLogout, navigate }: { me: Staff; onLogout: () => void; navigate: (to: string) => void }) {
  const roleBn = me.role === "admin" ? "অ্যাডমিন" : me.role === "editor" ? "এডিটর" : "অপারেটর";
  return (
    <header className="sticky top-0 z-30 border-b bg-background/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-2 px-3 py-2.5 sm:px-4">
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Film className="h-4 w-4" />
          </div>
          <div className="leading-tight">
            <div className="text-sm font-bold">Dream Studio Staff</div>
            <div className="text-[10px] text-muted-foreground">internal dashboard</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="hidden text-right sm:block">
            <div className="text-xs font-medium">{me.name}</div>
            <div className="text-[10px] text-muted-foreground">{me.email}</div>
          </div>
          <Badge variant="secondary" className="capitalize">{roleBn}</Badge>
          <Button variant="outline" size="sm" onClick={() => navigate("#/")}>
            <ExternalLink className="mr-1 h-3 w-3" /> সাইট
          </Button>
          <Button variant="ghost" size="sm" onClick={onLogout}>
            <LogOut className="h-3 w-3" /> লগআউট
          </Button>
        </div>
      </div>
    </header>
  );
}

// ───────────────────────── Production panel (shared) ─────────────────────────
function ProductionPanel({ orderId, onBack, me }: { orderId: string; onBack: () => void; me: Staff }) {
  const [data, setData] = useState<any | null>(null);
  const [promptEdits, setPromptEdits] = useState<Record<string, string>>({});
  const [qc, setQc] = useState({ productCorrect: false, noDeformed: false, noGarbledText: false, noWatermark: false, toneMatch: false });
  const [busy, setBusy] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await api<any>(`/api/orders/${orderId}`);
      setData(r);
    } catch (e: any) {
      // silent on poll
    }
  }, [orderId]);

  useEffect(() => {
    setData(null);
    setPromptEdits({});
    load();
    pollRef.current = setInterval(load, 5000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [load]);

  async function claim() {
    setBusy(true);
    try {
      await api(`/api/staff/order/${orderId}/claim`, { method: "POST" });
      toast.success("অর্ডার ক্লেইম করা হয়েছে");
      load();
    } catch (e: any) { toast.error(e.message); }
    finally { setBusy(false); }
  }
  async function generateAll() {
    setBusy(true);
    try {
      await api(`/api/staff/order/${orderId}/generate`, { method: "POST" });
      toast.success("শট জেনারেশন শুরু");
      load();
    } catch (e: any) { toast.error(e.message); }
    finally { setBusy(false); }
  }
  async function approveShot(shotId: string) {
    setBusy(true);
    try {
      await api(`/api/staff/order/${orderId}/approve`, { method: "POST", body: JSON.stringify({ shotId, approve: true }) });
      toast.success("শট অনুমোদিত");
      load();
    } catch (e: any) { toast.error(e.message); }
    finally { setBusy(false); }
  }
  async function regenShot(shotId: string) {
    setBusy(true);
    try {
      await api(`/api/staff/order/${orderId}/regenerate`, {
        method: "POST",
        body: JSON.stringify({ shotId, newPrompt: promptEdits[shotId] }),
      });
      toast.success("রিজেনারেশন শুরু");
      load();
    } catch (e: any) { toast.error(e.message); }
    finally { setBusy(false); }
  }
  async function submitQc() {
    const allTrue = Object.values(qc).every(Boolean);
    if (!allTrue) return toast.error("সব QC চেক টিক করুন");
    setBusy(true);
    try {
      await api(`/api/staff/order/${orderId}/qc`, { method: "POST", body: JSON.stringify(qc) });
      toast.success("QC সাবমিট — এডিটিং ধাপে পাঠানো হয়েছে");
      load();
    } catch (e: any) { toast.error(e.message); }
    finally { setBusy(false); }
  }

  if (!data) {
    return (
      <div className="space-y-3">
        <Button variant="ghost" size="sm" onClick={onBack}><ArrowLeft className="mr-1 h-4 w-4" /> ফিরুন</Button>
        <div className="h-64 animate-pulse rounded-xl bg-muted" />
      </div>
    );
  }

  const o = data.order;
  let brief: any = {};
  try { brief = JSON.parse(o.briefJson); } catch {}
  let script: any = null;
  try { script = o.scriptJson ? JSON.parse(o.scriptJson) : null; } catch {}
  const shots: any[] = data.shots || [];
  const photos: string[] = data.photos || [];
  const allApproved = shots.length > 0 && shots.every((s) => s.status === "APPROVED");
  const claimedByOther = o.operatorId && o.operatorId !== me.id;
  const sla = slaCountdown(o.slaDeadline);

  return (
    <div className="space-y-4">
      <Button variant="ghost" size="sm" onClick={onBack}><ArrowLeft className="mr-1 h-4 w-4" /> কিউতে ফিরুন</Button>

      {/* Header */}
      <Card>
        <CardContent className="p-4 sm:p-5">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold">{o.code}</h2>
                <Badge className={statusColor[o.status] || "bg-zinc-200"}>{statusLabelBn[o.status] || o.status}</Badge>
              </div>
              <p className="mt-0.5 text-sm text-muted-foreground">{o.product?.nameBn || o.product?.name}</p>
              <p className="mt-1 text-xs text-muted-foreground">কাস্টমার: {o.customerPhone}</p>
            </div>
            <div className="text-right">
              <div className={cn("text-xs font-medium", sla.overdue ? "text-destructive" : sla.soon ? "text-amber-600" : "text-muted-foreground")}>
                <Clock className="mr-1 inline h-3 w-3" /> SLA: {sla.text}
              </div>
              <div className="mt-1 text-[11px] text-muted-foreground">ডেডলাইন: {fmtDate(o.slaDeadline)}</div>
              <div className="mt-1 text-[11px] text-muted-foreground">অপারেটর: {o.operator?.name || "—"}</div>
            </div>
          </div>

          {claimedByOther && (
            <div className="mt-3 flex items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 p-2 text-xs text-amber-800">
              <AlertTriangle className="h-4 w-4" /> এই অর্ডার অন্য অপারেটর ({o.operator?.name || "—"}) ক্লেইম করেছেন।
            </div>
          )}

          <div className="mt-3 flex flex-wrap gap-2">
            <Button size="sm" variant="outline" asChild>
              <a
                href={whatsappLink(o.customerPhone, whatsappMessageBn(o, `${typeof window !== "undefined" ? window.location.origin : ""}/#/account/orders/${o.id}`))}
                target="_blank"
                rel="noreferrer"
              >
                <MessageCircle className="mr-1 h-3.5 w-3.5" /> WhatsApp করুন
              </a>
            </Button>
            {o.driveFolderUrl && (
              <Button size="sm" variant="outline" asChild>
                <a href={o.driveFolderUrl} target="_blank" rel="noreferrer"><FolderOpen className="mr-1 h-3.5 w-3.5" /> Drive ফোল্ডার</a>
              </Button>
            )}
            {!o.operatorId && (
              <Button size="sm" onClick={claim} disabled={busy}>
                <CheckCircle2 className="mr-1 h-3.5 w-3.5" /> ক্লেইম করুন
              </Button>
            )}
            {script && (
              <Button size="sm" variant="secondary" onClick={generateAll} disabled={busy || !script}>
                <Sparkles className="mr-1 h-3.5 w-3.5" /> সব শট জেনারেট করুন
              </Button>
            )}
            {o.status === "GENERATING" && (
              <Badge variant="outline" className="animate-pulse"><Loader2 className="mr-1 h-3 w-3 animate-spin" /> জেনারেট হচ্ছে…</Badge>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Brief */}
        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-sm">ব্রিফ</CardTitle></CardHeader>
          <CardContent className="space-y-2 text-sm">
            <Row k="প্রোডাক্ট" v={brief.productName} />
            <Row k="ক্যাটাগরি" v={brief.category} />
            <Row k="টোন" v={brief.tone} />
            <Row k="ভাষা" v={brief.language} />
            <Row k="CTA" v={brief.cta} />
            <Row k="ফোন/পেজ" v={brief.phoneOrPage} />
            <Row k="টার্গেট কাস্টমার" v={brief.targetCustomer} />
            <Row k="প্রাইস/অফার" v={brief.priceOffer} />
            {brief.notes && <Row k="নোট" v={brief.notes} />}
            {photos.length > 0 && (
              <div className="pt-2">
                <div className="mb-1.5 text-xs text-muted-foreground">প্রোডাক্ট ফটো ({photos.length})</div>
                <div className="flex flex-wrap gap-1.5">
                  {photos.map((p, i) => (
                    <a key={i} href={p} target="_blank" rel="noreferrer">
                      <img src={p} alt={`photo-${i}`} className="h-12 w-12 rounded border object-cover" />
                    </a>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Script */}
        {script && (
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-sm">স্ক্রিপ্ট</CardTitle></CardHeader>
            <CardContent className="space-y-2 text-sm">
              {script.script_bn && (
                <div>
                  <div className="mb-1 text-xs text-muted-foreground">স্ক্রিপ্ট (বাংলা)</div>
                  <div className="max-h-40 overflow-y-auto scroll-fancy whitespace-pre-wrap rounded bg-muted/50 p-2 text-[13px] leading-relaxed">
                    {script.script_bn}
                  </div>
                </div>
              )}
              <Row k="মিউজিক মুড" v={script.music_mood} />
              <Row k="এডিট নোট" v={script.edit_notes} />
              <Row k="CTA এন্ডকার্ড" v={script.cta_endcard_text} />
            </CardContent>
          </Card>
        )}
      </div>

      {/* Shots */}
      <div>
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-sm font-semibold">শটস ({shots.length})</h3>
          {allApproved && <Badge className="bg-emerald-100 text-emerald-800"><CheckCircle2 className="mr-1 h-3 w-3" /> সব অনুমোদিত</Badge>}
        </div>
        {shots.length === 0 ? (
          <Card><CardContent className="py-8 text-center text-sm text-muted-foreground">কোন শট নেই। স্ক্রিপ্ট তৈরি হলে শট আসবে।</CardContent></Card>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">
            {shots.map((s: any) => {
              const pe = promptEdits[s.id] ?? s.prompt;
              const edited = promptEdits[s.id] !== undefined && promptEdits[s.id] !== s.prompt;
              const approved = s.status === "APPROVED";
              const generating = s.status === "GENERATING";
              return (
                <Card key={s.id} className={cn(approved && "border-emerald-300")}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm">শট {s.shotNo} — {s.purpose}</CardTitle>
                      <Badge className={cn(
                        s.status === "APPROVED" ? "bg-emerald-100 text-emerald-800" :
                        s.status === "GENERATING" ? "bg-purple-100 text-purple-800" :
                        s.status === "REJECTED" ? "bg-rose-100 text-rose-800" :
                        "bg-zinc-200 text-zinc-800"
                      )}>
                        {s.status === "APPROVED" ? "অনুমোদিত" : s.status === "GENERATING" ? "চলছে" : s.status === "REJECTED" ? "বাতিল" : "অপেক্ষায়"}
                      </Badge>
                    </div>
                    {s.camera && <div className="text-[11px] text-muted-foreground">ক্যামেরা: {s.camera}</div>}
                    {s.onScreenText && <div className="text-[11px] text-muted-foreground">স্ক্রিন টেক্সট: {s.onScreenText}</div>}
                    <div className="text-[11px] text-muted-foreground">রিজেন: {s.regenCount} বার</div>
                  </CardHeader>
                  <CardContent className="space-y-2 pt-0">
                    {s.videoUrl && (
                      <video src={s.videoUrl} controls className="w-full rounded border" />
                    )}
                    {generating && !s.videoUrl && (
                      <div className="flex h-24 items-center justify-center rounded border bg-muted/40 text-xs text-muted-foreground">
                        <Loader2 className="mr-1 h-3 w-3 animate-spin" /> ভিডিও তৈরি হচ্ছে…
                      </div>
                    )}
                    <div>
                      <Label className="text-[11px] text-muted-foreground">প্রম্পট</Label>
                      <Textarea
                        className="mt-1 text-xs"
                        rows={3}
                        value={pe}
                        disabled={approved}
                        onChange={(e) => setPromptEdits((p) => ({ ...p, [s.id]: e.target.value }))}
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="secondary" onClick={() => approveShot(s.id)} disabled={busy || approved || !s.videoUrl}>
                        <CheckCircle2 className="mr-1 h-3 w-3" /> অনুমোদন
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => regenShot(s.id)} disabled={busy || approved || !script}>
                        <RefreshCw className="mr-1 h-3 w-3" /> রিজেন
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* QC checklist */}
      {allApproved && (
        <Card className="border-emerald-300">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm"><ListChecks className="h-4 w-4" /> QC চেকলিস্ট — এডিটিং ধাপে পাঠান</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {[
              ["productCorrect", "প্রোডাক্ট সঠিকভাবে দেখানো হয়েছে"],
              ["noDeformed", "কোন ডিফর্মড আর্ট/হাত/চেহারা নেই"],
              ["noGarbledText", "স্ক্রিন টেক্সট পরিষ্কার (কোন গার্বল নেই)"],
              ["noWatermark", "কোন ওয়াটারমার্ক নেই"],
              ["toneMatch", "টোন ও ব্র্যান্ডিং ম্যাচ করে"],
            ].map(([k, label]) => (
              <div key={k} className="flex items-center gap-2">
                <Checkbox
                  id={k}
                  checked={(qc as any)[k]}
                  onCheckedChange={(v) => setQc((q) => ({ ...q, [k]: !!v }))}
                />
                <Label htmlFor={k} className="text-sm font-normal cursor-pointer">{label}</Label>
              </div>
            ))}
            <Button className="mt-2" onClick={submitQc} disabled={busy}>
              <ShieldCheck className="mr-1 h-4 w-4" /> QC সাবমিট → এডিটিং
            </Button>
          </CardContent>
        </Card>
      )}

      {(o.qaFlag || o.qaNote) && (
        <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">
          <div className="font-semibold">QA ফ্ল্যাগ চালু</div>
          {o.qaNote && <div className="mt-1">{o.qaNote}</div>}
        </div>
      )}
    </div>
  );
}

function Row({ k, v }: { k: string; v?: any }) {
  return (
    <div className="flex gap-2">
      <div className="w-28 shrink-0 text-xs text-muted-foreground">{k}</div>
      <div className="flex-1 break-words text-sm">{v || "—"}</div>
    </div>
  );
}

// ───────────────────────── Operator view ─────────────────────────
function OperatorView({ me }: { me: Staff }) {
  const [orders, setOrders] = useState<any[]>([]);
  const [currentOrderId, setCurrentOrderId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await api<{ orders: any[] }>("/api/staff/queue");
      setOrders(r.orders || []);
    } catch (e: any) {
      // silent on poll; first load show toast
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    pollRef.current = setInterval(load, 5000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [load]);

  return (
    <Section title="অপারেটর ড্যাশবোর্ড" icon={ClipboardList}>
      <Tabs defaultValue="queue" value={currentOrderId ? "prod" : "queue"}>
        <TabsList>
          <TabsTrigger value="queue" onClick={() => setCurrentOrderId(null)}>কিউ ({orders.length})</TabsTrigger>
          <TabsTrigger value="prod" disabled={!currentOrderId}>প্রোডাকশন</TabsTrigger>
        </TabsList>

        <TabsContent value="queue" className="mt-3">
          {loading ? (
            <div className="h-40 animate-pulse rounded-xl bg-muted" />
          ) : orders.length === 0 ? (
            <Card><CardContent className="py-10 text-center text-sm text-muted-foreground">
              <ClipboardList className="mx-auto mb-2 h-8 w-8 opacity-40" />
              কিউতে কোন অর্ডার নেই।
            </CardContent></Card>
          ) : (
            <Card>
              <CardContent className="p-0">
                <div className="max-h-96 overflow-y-auto scroll-fancy">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>কোড</TableHead>
                        <TableHead>প্রোডাক্ট</TableHead>
                        <TableHead>স্ট্যাটাস</TableHead>
                        <TableHead>SLA</TableHead>
                        <TableHead>অপারেটর</TableHead>
                        <TableHead className="text-right">অ্যাকশন</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orders.map((o) => {
                        const sla = slaCountdown(o.slaDeadline);
                        return (
                          <TableRow key={o.id} className={cn(o.overdue && "bg-destructive/5")}>
                            <TableCell className="font-mono text-xs font-semibold">{o.code}</TableCell>
                            <TableCell className="text-xs">{o.product?.nameBn || o.product?.name}</TableCell>
                            <TableCell><Badge className={statusColor[o.status]}>{statusLabelBn[o.status] || o.status}</Badge></TableCell>
                            <TableCell className={cn("text-xs", sla.overdue ? "text-destructive font-semibold" : sla.soon ? "text-amber-600" : "text-muted-foreground")}>
                              {sla.text}
                            </TableCell>
                            <TableCell className="text-xs">{o.operator?.name || "—"}</TableCell>
                            <TableCell className="text-right">
                              <Button size="sm" variant="secondary" onClick={() => setCurrentOrderId(o.id)}>খুলুন</Button>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="prod" className="mt-3">
          {currentOrderId ? (
            <ProductionPanel orderId={currentOrderId} onBack={() => setCurrentOrderId(null)} me={me} />
          ) : (
            <Card><CardContent className="py-10 text-center text-sm text-muted-foreground">
              কিউ থেকে কোন অর্ডার খুলুন।
            </CardContent></Card>
          )}
        </TabsContent>
      </Tabs>
    </Section>
  );
}

// ───────────────────────── Editor view ─────────────────────────
function EditorView({ me }: { me: Staff }) {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [detailId, setDetailId] = useState<string | null>(null);
  const [detail, setDetail] = useState<any | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // upload form
  const [uploadOrderId, setUploadOrderId] = useState<string>("");
  const [manualOrderId, setManualOrderId] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [file15, setFile15] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  const load = useCallback(async () => {
    try {
      const r = await api<{ orders: any[] }>("/api/staff/queue");
      // queue excludes EDITING status; show what we can + note
      setOrders((r.orders || []).filter((o) => o.status === "EDITING"));
    } catch {
      // editors may 403 on queue; show note
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    pollRef.current = setInterval(load, 10000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [load]);

  const loadDetail = useCallback(async (id: string) => {
    try {
      const r = await api<any>(`/api/orders/${id}`);
      setDetail(r);
    } catch (e: any) { toast.error(e.message); }
  }, []);

  useEffect(() => {
    if (detailId) loadDetail(detailId);
    else setDetail(null);
  }, [detailId, loadDetail]);

  function downloadScript() {
    if (!detail) return;
    let script: any = null;
    try { script = detail.order.scriptJson ? JSON.parse(detail.order.scriptJson) : null; } catch {}
    const lines: string[] = [];
    lines.push(`Order: ${detail.order.code}`);
    lines.push(`Product: ${detail.order.product?.name || ""}`);
    lines.push("=".repeat(40));
    if (script) {
      if (script.script_bn) { lines.push("SCRIPT (BN):"); lines.push(script.script_bn); lines.push(""); }
      if (script.music_mood) { lines.push(`Music mood: ${script.music_mood}`); }
      if (script.edit_notes) { lines.push(`Edit notes: ${script.edit_notes}`); }
      if (script.cta_endcard_text) { lines.push(`CTA endcard: ${script.cta_endcard_text}`); }
      lines.push(""); lines.push("=".repeat(40)); lines.push("SHOTS:");
      (detail.shots || []).forEach((s: any) => {
        lines.push(`#${s.shotNo} — ${s.purpose}`);
        if (s.prompt) lines.push(`  Prompt: ${s.prompt}`);
        if (s.camera) lines.push(`  Camera: ${s.camera}`);
        if (s.onScreenText) lines.push(`  On-screen: ${s.onScreenText}`);
        if (s.videoUrl) lines.push(`  Video: ${s.videoUrl}`);
        lines.push("");
      });
    }
    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${detail.order.code}-script.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  async function doUpload() {
    const oid = uploadOrderId || manualOrderId.trim();
    if (!oid) return toast.error("অর্ডার নির্বাচন করুন বা ID লিখুন");
    if (!file) return toast.error("ভিডিও ফাইল দিন");
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("video", file);
      if (file15) fd.append("video15", file15);
      const r: any = await uploadFile(`/api/staff/order/${oid}/upload`, fd);
      toast.success("ডেলিভার হয়েছে!");
      if (r?.qaFlag) toast.info("এই অর্ডারটি র‍্যান্ডম QA-তে ফ্ল্যাগ করা হয়েছে।");
      setFile(null); setFile15(null); setManualOrderId(""); setUploadOrderId("");
      // refresh editing list
      load();
    } catch (e: any) {
      toast.error(e.message);
    } finally {
      setUploading(false);
    }
  }

  return (
    <Section title="এডিটর ড্যাশবোর্ড" icon={Film}>
      <Tabs defaultValue="queue">
        <TabsList>
          <TabsTrigger value="queue">এডিটিং কিউ ({orders.length})</TabsTrigger>
          <TabsTrigger value="upload">আপলোড</TabsTrigger>
        </TabsList>

        <TabsContent value="queue" className="mt-3">
          <Card>
            <CardContent className="p-4">
              <div className="mb-3 flex items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 p-2 text-[11px] text-amber-800">
                <AlertTriangle className="h-3.5 w-3.5" />
                নোট: স্টাফ কিউ এন্ডপয়েন্ট বর্তমানে EDITING স্ট্যাটাস অর্ডার ফেরত দেয় না। নিচে অর্ডার ID লিখে বিস্তারিত দেখুন।
              </div>

              <div className="mb-4 flex gap-2">
                <Input placeholder="অর্ডার ID (DSA-…)" value={manualOrderId} onChange={(e) => setManualOrderId(e.target.value)} className="text-sm" />
                <Button size="sm" onClick={() => setDetailId(manualOrderId.trim() || detailId)} disabled={!manualOrderId.trim()}>
                  বিস্তারিত দেখুন
                </Button>
              </div>

              {orders.length > 0 && (
                <div className="grid gap-2 sm:grid-cols-2">
                  {orders.map((o) => (
                    <Button key={o.id} variant="outline" size="sm" className="justify-start" onClick={() => { setDetailId(o.id); setManualOrderId(o.id); }}>
                      {o.code} — {o.product?.nameBn || o.product?.name}
                    </Button>
                  ))}
                </div>
              )}

              {detail && (
                <div className="mt-4 rounded-lg border p-3">
                  <div className="mb-2 flex items-center justify-between">
                    <div>
                      <span className="font-mono text-sm font-semibold">{detail.order.code}</span>
                      <Badge className={cn("ml-2", statusColor[detail.order.status])}>{statusLabelBn[detail.order.status]}</Badge>
                    </div>
                    <Button size="sm" variant="secondary" onClick={downloadScript}>
                      <Download className="mr-1 h-3.5 w-3.5" /> স্ক্রিপ্ট ডাউনলোড
                    </Button>
                  </div>
                  <div className="text-xs text-muted-foreground">{detail.order.product?.nameBn || detail.order.product?.name}</div>

                  {(() => {
                    let script: any = null;
                    try { script = detail.order.scriptJson ? JSON.parse(detail.order.scriptJson) : null; } catch {}
                    if (!script) return <div className="mt-2 text-xs text-muted-foreground">স্ক্রিপ্ট নেই।</div>;
                    return (
                      <div className="mt-3 space-y-2 text-sm">
                        {script.script_bn && (
                          <div>
                            <div className="text-[11px] text-muted-foreground">স্ক্রিপ্ট (বাংলা):</div>
                            <div className="max-h-40 overflow-y-auto scroll-fancy whitespace-pre-wrap rounded bg-muted/50 p-2 text-[13px]">{script.script_bn}</div>
                          </div>
                        )}
                        {script.edit_notes && <Row k="এডিট নোট" v={script.edit_notes} />}
                        {script.cta_endcard_text && <Row k="CTA এন্ডকার্ড" v={script.cta_endcard_text} />}
                        {script.music_mood && <Row k="মিউজিক" v={script.music_mood} />}
                      </div>
                    );
                  })()}

                  <div className="mt-3">
                    <div className="mb-1 text-[11px] text-muted-foreground">অনুমোদিত শট ভিডিও ({(detail.shots || []).filter((s:any)=>s.videoUrl).length}):</div>
                    <div className="max-h-60 space-y-2 overflow-y-auto scroll-fancy">
                      {(detail.shots || []).filter((s:any)=>s.videoUrl).map((s:any) => (
                        <div key={s.id} className="rounded border p-2 text-xs">
                          <div className="font-medium">শট {s.shotNo} — {s.purpose}</div>
                          <a href={s.videoUrl} target="_blank" rel="noreferrer" className="break-all text-primary underline">
                            {s.videoUrl}
                          </a>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="upload" className="mt-3">
          <Card>
            <CardHeader className="pb-3"><CardTitle className="text-sm">ফাইনাল ভিডিও আপলোড → ডেলিভারি</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1.5">
                <Label>অর্ডার (EDITING)</Label>
                <Select value={uploadOrderId} onValueChange={setUploadOrderId}>
                  <SelectTrigger><SelectValue placeholder="অর্ডার বাছুন" /></SelectTrigger>
                  <SelectContent>
                    {orders.map((o) => (
                      <SelectItem key={o.id} value={o.id}>{o.code} — {o.product?.nameBn || o.product?.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="flex items-center gap-2 pt-1">
                  <Input placeholder="অথবা অর্ডার ID লিখুন" value={manualOrderId} onChange={(e) => setManualOrderId(e.target.value)} className="text-sm" />
                </div>
              </div>

              <div className="space-y-1.5">
                <Label>ফাইনাল MP4 (৩০সে)</Label>
                <Input type="file" accept="video/mp4" onChange={(e) => setFile(e.target.files?.[0] || null)} />
                {file && <div className="text-[11px] text-muted-foreground">{file.name} ({Math.round(file.size/1024/1024)}MB)</div>}
              </div>

              <div className="space-y-1.5">
                <Label>১৫সে কাট (Premium-এর জন্য, অপশনাল)</Label>
                <Input type="file" accept="video/mp4" onChange={(e) => setFile15(e.target.files?.[0] || null)} />
              </div>

              <Button onClick={doUpload} disabled={uploading} className="w-full">
                {uploading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UploadIcon className="mr-2 h-4 w-4" />}
                {uploading ? "আপলোড হচ্ছে…" : "ডেলিভার করুন"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </Section>
  );
}

// ───────────────────────── Admin view ─────────────────────────
function AdminView() {
  const [payCount, setPayCount] = useState(0);
  useEffect(() => {
    let active = true;
    const tick = () =>
      api<{ count: number }>("/api/admin/payments")
        .then((r) => { if (active) setPayCount(r.count); })
        .catch(() => {});
    tick();
    const t = setInterval(tick, 15000);
    return () => { active = false; clearInterval(t); };
  }, []);
  return (
    <Section title="অ্যাডমিন ড্যাশবোর্ড" icon={ShieldCheck}>
      <Tabs defaultValue={payCount > 0 ? "payments" : "orders"}>
        <ScrollArea className="w-full">
          <TabsList className="flex w-max">
            <TabsTrigger value="payments">
              <Wallet className="mr-1 h-3.5 w-3.5" /> পেমেন্ট যাচাই
              {payCount > 0 && <span className="ml-1 rounded-full bg-destructive px-1.5 text-[10px] font-bold text-white">{payCount}</span>}
            </TabsTrigger>
            <TabsTrigger value="orders"><ShoppingCart className="mr-1 h-3.5 w-3.5" /> অর্ডার</TabsTrigger>
            <TabsTrigger value="products"><Package className="mr-1 h-3.5 w-3.5" /> প্রোডাক্ট</TabsTrigger>
            <TabsTrigger value="content"><FileText className="mr-1 h-3.5 w-3.5" /> কনটেন্ট</TabsTrigger>
            <TabsTrigger value="settings"><SettingsIcon className="mr-1 h-3.5 w-3.5" /> সেটিংস</TabsTrigger>
            <TabsTrigger value="costs"><DollarSign className="mr-1 h-3.5 w-3.5" /> খরচ</TabsTrigger>
            <TabsTrigger value="qa"><ShieldCheck className="mr-1 h-3.5 w-3.5" /> QA রিভিউ</TabsTrigger>
            <TabsTrigger value="stats"><BarChart3 className="mr-1 h-3.5 w-3.5" /> অপারেটর স্ট্যাটস</TabsTrigger>
            <TabsTrigger value="system"><Activity className="mr-1 h-3.5 w-3.5" /> সিস্টেম</TabsTrigger>
          </TabsList>
        </ScrollArea>

        <TabsContent value="payments" className="mt-3"><AdminPayments onCount={setPayCount} /></TabsContent>
        <TabsContent value="orders" className="mt-3"><AdminOrders /></TabsContent>
        <TabsContent value="products" className="mt-3"><AdminProducts /></TabsContent>
        <TabsContent value="content" className="mt-3"><AdminContent /></TabsContent>
        <TabsContent value="settings" className="mt-3"><AdminSettings /></TabsContent>
        <TabsContent value="costs" className="mt-3"><AdminCosts /></TabsContent>
        <TabsContent value="qa" className="mt-3"><AdminQA /></TabsContent>
        <TabsContent value="stats" className="mt-3"><AdminStaffStats /></TabsContent>
        <TabsContent value="system" className="mt-3"><AdminSystem /></TabsContent>
      </Tabs>
    </Section>
  );
}

// ─── Admin: manual bKash payment check ───────────────────────
function AdminPayments({ onCount }: { onCount: (n: number) => void }) {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [reasons, setReasons] = useState<Record<string, string>>({});

  const load = useCallback(() => {
    return api<{ payments: any[]; count: number }>("/api/admin/payments")
      .then((r) => { setRows(r.payments); onCount(r.count); })
      .catch((e) => toast.error(e.message))
      .finally(() => setLoading(false));
  }, [onCount]);

  useEffect(() => {
    let active = true;
    const run = () => { if (active) void load(); };
    run();
    const t = setInterval(run, 15000);
    return () => { active = false; clearInterval(t); };
  }, [load]);

  async function act(id: string, action: "confirm" | "reject") {
    const reason = reasons[id]?.trim();
    if (action === "reject" && !reason) return toast.error("প্রত্যাখ্যানের কারণ লিখুন (কাস্টমার এটি দেখবে)");
    setBusy(id);
    try {
      await api(`/api/admin/payments/${id}`, { method: "POST", body: JSON.stringify({ action, reason }) });
      toast.success(action === "confirm" ? "পেমেন্ট নিশ্চিত — অর্ডার শুরু হয়েছে" : "প্রত্যাখ্যাত — কাস্টমার আবার জমা দিতে পারবে");
      await load();
    } catch (e: any) { toast.error(e.message); }
    finally { setBusy(null); }
  }

  if (loading) return <div className="h-40 animate-pulse rounded-xl bg-muted" />;
  if (rows.length === 0) {
    return <Card><CardContent className="p-6 text-center text-sm text-muted-foreground">যাচাইয়ের জন্য কোনো পেমেন্ট নেই। নতুন পেমেন্ট এলে Telegram-এ জানানো হবে।</CardContent></Card>;
  }
  return (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground">আপনার bKash অ্যাপের স্টেটমেন্টে TrxID, পরিমাণ ও নম্বর মিলিয়ে নিশ্চিত করুন।</p>
      {rows.map((p) => {
        const mismatch = p.amountEntered !== p.amountDue;
        return (
          <Card key={p.id}>
            <CardContent className="space-y-3 p-4">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <div className="font-mono text-sm font-bold">{p.orderCode}</div>
                  <div className="text-xs text-muted-foreground">{p.product} · কাস্টমার {p.customerPhone}</div>
                </div>
                <div className="text-right text-xs text-muted-foreground">{fmtDate(p.submittedAt)}</div>
              </div>
              <div className="grid gap-2 text-sm sm:grid-cols-4">
                <div><div className="text-[11px] text-muted-foreground">প্রাপ্য</div><b className="tabular-nums">৳{p.amountDue}</b></div>
                <div><div className="text-[11px] text-muted-foreground">কাস্টমার লিখেছে</div><b className={cn("tabular-nums", mismatch && "text-destructive")}>৳{p.amountEntered}{mismatch && " ⚠"}</b></div>
                <div><div className="text-[11px] text-muted-foreground">TrxID</div><b className="font-mono">{p.trxId}</b></div>
                <div><div className="text-[11px] text-muted-foreground">যে নম্বর থেকে</div><b className="tabular-nums">{p.senderNumber}</b></div>
              </div>
              {p.screenshotUrl && (
                <a href={p.screenshotUrl} target="_blank" rel="noreferrer" className="inline-flex items-center text-xs text-primary underline">
                  <ExternalLink className="mr-1 h-3 w-3" /> স্ক্রিনশট দেখুন
                </a>
              )}
              <div className="flex flex-col gap-2 sm:flex-row">
                <Input
                  className="h-9 text-sm"
                  placeholder="প্রত্যাখ্যানের কারণ (যেমন: TrxID মেলেনি / টাকা কম)"
                  value={reasons[p.id] || ""}
                  onChange={(e) => setReasons((r) => ({ ...r, [p.id]: e.target.value }))}
                />
                <div className="flex gap-2">
                  <Button size="sm" disabled={busy === p.id} onClick={() => act(p.id, "confirm")}>
                    {busy === p.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="mr-1 h-3.5 w-3.5" />} নিশ্চিত
                  </Button>
                  <Button size="sm" variant="destructive" disabled={busy === p.id} onClick={() => act(p.id, "reject")}>প্রত্যাখ্যান</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

// ─── Admin: system health + service tests ────────────────────
function AdminSystem() {
  const [health, setHealth] = useState<any | null>(null);
  const [ai, setAi] = useState<any | null>(null);
  const [aiBusy, setAiBusy] = useState(false);
  const [wan, setWan] = useState<any | null>(null);

  const loadHealth = useCallback(() => {
    api<any>("/api/health?detail=1").then(setHealth).catch((e) => setHealth({ ok: false, error: e.message }));
  }, []);
  const loadWan = useCallback(() => {
    api<any>("/api/admin/test/wan").then(setWan).catch(() => {});
  }, []);

  useEffect(() => {
    let active = true;
    const run = () => { if (active) { loadHealth(); loadWan(); } };
    run();
    const t = setInterval(run, 10000);
    return () => { active = false; clearInterval(t); };
  }, [loadHealth, loadWan]);

  async function testAi() {
    setAiBusy(true);
    setAi(null);
    try { setAi(await api<any>("/api/admin/test/ai", { method: "POST" })); }
    catch (e: any) { setAi({ error: e.message }); }
    finally { setAiBusy(false); }
  }
  async function testWan() {
    try {
      await api("/api/admin/test/wan", { method: "POST" });
      toast.success("Wan টেস্ট শুরু — ১–৫ মিনিট লাগতে পারে");
      loadWan();
    } catch (e: any) { toast.error(e.message); }
  }

  const checks: { k: string; label: string }[] = [
    { k: "database", label: "ডাটাবেস" },
    { k: "storage", label: "স্টোরেজ (Google Drive)" },
    { k: "worker", label: "ওয়ার্কার (ব্যাকগ্রাউন্ড কাজ)" },
    { k: "watermark", label: "প্রিভিউ ওয়াটারমার্ক (ffmpeg)" },
    { k: "wan", label: "Wan ভিডিও" },
    { k: "llm", label: "AI (স্ক্রিপ্ট ও সেফটি)" },
    { k: "firebase", label: "ফোন লগইন (Firebase)" },
    { k: "telegram", label: "Telegram অ্যালার্ট" },
    { k: "payments", label: "পেমেন্ট মোড" },
  ];

  return (
    <div className="space-y-3">
      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">সিস্টেম অবস্থা</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {!health ? <div className="h-24 animate-pulse rounded bg-muted" /> : checks.map((c) => {
            const v = health.checks?.[c.k];
            return (
              <div key={c.k} className="flex items-start justify-between gap-3 rounded-lg border p-2 text-sm">
                <span>{c.label}</span>
                <span className={cn("text-right text-xs font-medium", v?.ok ? "text-emerald-700" : "text-destructive")}>
                  {v?.ok ? "✓ " : "✗ "}{v?.detail || (v?.ok ? "OK" : "কনফিগার করা নেই")}
                </span>
              </div>
            );
          })}
          {health?.mock && <p className="rounded bg-amber-100 p-2 text-xs text-amber-900">MOCK MODE চালু আছে — সব AI/পেমেন্ট নকল। প্রোডাকশনে MOCK_MODE=false দিন।</p>}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">AI টেস্ট</CardTitle></CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p className="text-xs text-muted-foreground">আপনার key কোন মডেল ব্যবহার করতে পারে, ছবি যাচাই কাজ করে কি না, আর একটি নমুনা বাংলা স্ক্রিপ্ট দেখায়।</p>
          <Button size="sm" onClick={testAi} disabled={aiBusy}>{aiBusy && <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" />} Test AI</Button>
          {ai && <pre className="max-h-96 overflow-auto whitespace-pre-wrap rounded bg-muted p-2 text-[11px]">{JSON.stringify(ai, null, 2)}</pre>}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">Wan টেস্ট</CardTitle></CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p className="text-xs text-muted-foreground">একটি নমুনা পণ্যের ছবি থেকে ৫ সেকেন্ডের ভিডিও বানায় (খরচ হবে ~৫ সেকেন্ডের Wan মূল্য)।</p>
          <Button size="sm" onClick={testWan} disabled={wan?.result?.status === "RUNNING" || wan?.queued}>Test Wan</Button>
          {wan?.result && (
            <div className="space-y-2">
              <p className={cn("text-xs font-medium", wan.result.status === "OK" ? "text-emerald-700" : wan.result.status === "RUNNING" ? "text-amber-600" : "text-destructive")}>
                {wan.result.status} {wan.result.ms ? `· ${(wan.result.ms / 1000).toFixed(0)}s` : ""} {wan.result.costUsd ? `· $${wan.result.costUsd.toFixed(3)}` : ""} · {wan.result.at}
              </p>
              {wan.videoUrl && <video src={wan.videoUrl} controls playsInline className="max-h-80 rounded bg-black" />}
              {(wan.result.error || wan.result.raw) && <pre className="max-h-64 overflow-auto whitespace-pre-wrap rounded bg-muted p-2 text-[11px]">{wan.result.error}{"\n"}{wan.result.raw}</pre>}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function AdminOrders() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [search, setSearch] = useState("");
  const [prodId, setProdId] = useState<string | null>(null);
  const [markingPaid, setMarkingPaid] = useState<string | null>(null);
  const [reviewing, setReviewing] = useState<string | null>(null);

  const load = useCallback(async () => {
    // Item 10 (Phase 1): use /api/admin/orders so PENDING_PAYMENT orders
    // show and "Mark paid" works for them.
    const r = await api<{ orders: any[] }>("/api/admin/orders").catch(() => ({ orders: [] }));
    setOrders(r.orders || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = orders.filter((r) => {
    if (statusFilter !== "ALL" && r.status !== statusFilter) return false;
    if (search && !r.code.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  async function markPaid(orderId: string) {
    setMarkingPaid(orderId);
    try {
      await api("/api/payment/manual", { method: "POST", body: JSON.stringify({ orderId, note: "Manual confirmation" }) });
      toast.success("পেমেন্ট ম্যানুয়ালি কনফার্ম হয়েছে");
      load();
    } catch (e:any) { toast.error(e.message); }
    finally { setMarkingPaid(null); }
  }

  // Item 2 (Phase 1B): admin resolves MANUAL_REVIEW orders.
  async function review(orderId: string, action: "approve" | "reject") {
    setReviewing(orderId);
    try {
      await api(`/api/admin/order/${orderId}/review`, { method: "POST", body: JSON.stringify({ action }) });
      toast.success(action === "approve" ? "অনুমোদিত → স্ক্রিপ্ট শুরু" : "প্রত্যাখ্যাত — রিফান্ড প্রসেস করুন");
      load();
    } catch (e:any) { toast.error(e.message); }
    finally { setReviewing(null); }
  }

  if (prodId) {
    return (
      <ProductionPanel orderId={prodId} onBack={() => setProdId(null)} me={{ id: "", email: "", name: "admin", role: "admin" }} />
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input placeholder="কোড খুঁজুন" value={search} onChange={(e)=>setSearch(e.target.value)} className="h-9 w-44 pl-7 text-sm" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="h-9 w-44 text-sm"><SelectValue placeholder="সব স্ট্যাটাস" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">সব</SelectItem>
            {Object.keys(statusLabelBn).map((s) => <SelectItem key={s} value={s}>{statusLabelBn[s]}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button variant="ghost" size="sm" onClick={load}><RefreshCw className="h-3.5 w-3.5" /></Button>
      </div>

      {loading ? (
        <div className="h-40 animate-pulse rounded-xl bg-muted" />
      ) : filtered.length === 0 ? (
        <Card><CardContent className="py-10 text-center text-sm text-muted-foreground">কোন অর্ডার নেই।</CardContent></Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="max-h-[28rem] overflow-y-auto scroll-fancy">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>কোড</TableHead>
                    <TableHead>ফোন</TableHead>
                    <TableHead>প্রোডাক্ট</TableHead>
                    <TableHead>স্ট্যাটাস</TableHead>
                    <TableHead>রাজস্ব</TableHead>
                    <TableHead>খরচ</TableHead>
                    <TableHead>মার্জিন</TableHead>
                    <TableHead>তারিখ</TableHead>
                    <TableHead className="text-right">অ্যাকশন</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((r) => (
                    <TableRow key={r.id}>
                      <TableCell className="font-mono text-xs font-semibold">{r.code}</TableCell>
                      <TableCell className="text-xs">{r.customerPhone}</TableCell>
                      <TableCell className="text-xs">{r.product?.nameBn || r.product?.name || "—"}</TableCell>
                      <TableCell><Badge className={statusColor[r.status]}>{statusLabelBn[r.status] || r.status}</Badge></TableCell>
                      <TableCell className="text-xs">{fmtBdt(r.revenue)}</TableCell>
                      <TableCell className="text-xs">{fmtBdt(r.costBdt)}</TableCell>
                      <TableCell className={cn("text-xs font-medium", r.margin < 0 ? "text-destructive" : (r.margin / Math.max(1, r.revenue)) < 0.5 ? "text-amber-600" : "text-emerald-700")}>{r.margin >= 0 ? Math.round((r.margin / Math.max(1, r.revenue)) * 100) + "%" : "—"}</TableCell>
                      <TableCell className="text-[11px] text-muted-foreground">{fmtDate(r.createdAt)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          {r.status === "PENDING_PAYMENT" && (
                            <Button size="sm" variant="secondary" disabled={markingPaid === r.id} onClick={() => markPaid(r.id)}>
                              {markingPaid === r.id ? <Loader2 className="h-3 w-3 animate-spin" /> : "পেইড"}
                            </Button>
                          )}
                          {r.status === "MANUAL_REVIEW" && (
                            <>
                              <Button size="sm" variant="default" disabled={reviewing === r.id} onClick={() => review(r.id, "approve")}>
                                {reviewing === r.id ? <Loader2 className="h-3 w-3 animate-spin" /> : "অনুমোদন"}
                              </Button>
                              <Button size="sm" variant="destructive" disabled={reviewing === r.id} onClick={() => review(r.id, "reject")}>
                                প্রত্যাখ্যান
                              </Button>
                            </>
                          )}
                          <Button size="sm" variant="ghost" asChild title="WhatsApp">
                            <a href={whatsappLink(r.customerPhone, whatsappMessageBn(r, `${typeof window !== "undefined" ? window.location.origin : ""}/#/account/orders/${r.id}`))} target="_blank" rel="noreferrer">
                              <MessageCircle className="h-3.5 w-3.5" />
                            </a>
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => setProdId(r.id)}>খুলুন</Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function AdminProducts() {
  const [products, setProducts] = useState<any[]>([]);
  const [edits, setEdits] = useState<Record<string, any>>({});
  const [saving, setSaving] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await api<{ products: any[] }>("/api/admin/products");
      setProducts(r.products || []);
    } catch (e:any) { toast.error(e.message); }
  }, []);

  useEffect(() => { load(); }, [load]);

  function get(id: string, field: string, fallback: any) {
    if (edits[id] && edits[id][field] !== undefined) return edits[id][field];
    return fallback;
  }
  function set(id: string, field: string, value: any) {
    setEdits((e) => ({ ...e, [id]: { ...(e[id] || {}), [field]: value } }));
  }

  async function save(p: any) {
    setSaving(p.id);
    const e = edits[p.id] || {};
    try {
      await api("/api/admin/products", { method: "PUT", body: JSON.stringify({
        id: p.id,
        priceBdt: e.priceBdt !== undefined ? Number(e.priceBdt) : p.priceBdt,
        active: e.active !== undefined ? e.active : p.active,
        name: e.name !== undefined ? e.name : p.name,
        nameBn: e.nameBn !== undefined ? e.nameBn : p.nameBn,
        deliverySla: e.deliverySla !== undefined ? e.deliverySla : p.deliverySla,
        revisions: e.revisions !== undefined ? Number(e.revisions) : p.revisions,
      }) });
      toast.success(`সেভ হয়েছে: ${p.name}`);
      setEdits((cur) => { const n = { ...cur }; delete n[p.id]; return n; });
      load();
    } catch (err:any) { toast.error(err.message); }
    finally { setSaving(null); }
  }

  return (
    <Card>
      <CardContent className="p-0">
        <div className="max-h-[32rem] overflow-y-auto scroll-fancy">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>কোড</TableHead>
                <TableHead>নাম (EN)</TableHead>
                <TableHead>নাম (BN)</TableHead>
                <TableHead>দাম</TableHead>
                <TableHead>SLA</TableHead>
                <TableHead>রিভিশন</TableHead>
                <TableHead>অ্যাকটিভ</TableHead>
                <TableHead className="text-right">সেভ</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {products.map((p) => (
                <TableRow key={p.id}>
                  <TableCell className="font-mono text-xs">{p.code}</TableCell>
                  <TableCell><Input className="h-8 text-xs" value={get(p.id,"name",p.name)} onChange={(e)=>set(p.id,"name",e.target.value)} /></TableCell>
                  <TableCell><Input className="h-8 text-xs" value={get(p.id,"nameBn",p.nameBn)} onChange={(e)=>set(p.id,"nameBn",e.target.value)} /></TableCell>
                  <TableCell><Input type="number" className="h-8 w-20 text-xs" value={get(p.id,"priceBdt",p.priceBdt)} onChange={(e)=>set(p.id,"priceBdt",e.target.value)} /></TableCell>
                  <TableCell><Input className="h-8 w-20 text-xs" value={get(p.id,"deliverySla",p.deliverySla)} onChange={(e)=>set(p.id,"deliverySla",e.target.value)} /></TableCell>
                  <TableCell><Input type="number" className="h-8 w-16 text-xs" value={get(p.id,"revisions",p.revisions)} onChange={(e)=>set(p.id,"revisions",e.target.value)} /></TableCell>
                  <TableCell><Switch checked={get(p.id,"active",p.active)} onCheckedChange={(v)=>set(p.id,"active",v)} /></TableCell>
                  <TableCell className="text-right">
                    <Button size="sm" variant="secondary" disabled={saving === p.id} onClick={() => save(p)}>
                      {saving === p.id ? <Loader2 className="h-3 w-3 animate-spin" /> : <Save className="h-3 w-3" />}
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}

function AdminContent() {
  type Item = { id: string; [k: string]: any };
  const [data, setData] = useState<{ testimonials: Item[]; faqs: Item[]; samples: Item[] }>({ testimonials: [], faqs: [], samples: [] });
  const [loading, setLoading] = useState(true);
  const [edits, setEdits] = useState<Record<string, any>>({});
  const [newItem, setNewItem] = useState<Record<string, any>>({});
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const r = await api<any>("/api/admin/content");
      setData(r);
    } catch (e:any) { toast.error(e.message); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  function get(id: string, field: string, fb: any) {
    if (edits[id]?.[field] !== undefined) return edits[id][field];
    return fb;
  }
  function set(id: string, field: string, v: any) {
    setEdits((e) => ({ ...e, [id]: { ...(e[id] || {}), [field]: v } }));
  }

  async function save(kind: "testimonial" | "faq" | "sample", id: string, base: any) {
    setBusy(true);
    try {
      await api("/api/admin/content", { method: "PUT", body: JSON.stringify({ kind, id, data: edits[id] || {} }) });
      toast.success("সেভ হয়েছে");
      setEdits((c) => { const n = { ...c }; delete n[id]; return n; });
      load();
    } catch (e:any) { toast.error(e.message); }
    finally { setBusy(false); }
  }

  async function add(kind: "testimonial" | "faq" | "sample") {
    setBusy(true);
    try {
      await api("/api/admin/content", { method: "POST", body: JSON.stringify({ kind, data: newItem }) });
      toast.success("যোগ হয়েছে");
      setNewItem({});
      load();
    } catch (e:any) { toast.error(e.message); }
    finally { setBusy(false); }
  }

  async function del(kind: "testimonial" | "faq" | "sample", id: string) {
    if (!confirm("ডিলিট করবেন?")) return;
    try {
      await api(`/api/admin/content?kind=${kind}&id=${id}`, { method: "DELETE" });
      toast.success("ডিলিট হয়েছে");
      load();
    } catch (e:any) { toast.error(e.message); }
  }

  if (loading) return <div className="h-40 animate-pulse rounded-xl bg-muted" />;

  return (
    <Tabs defaultValue="testimonials">
      <TabsList>
        <TabsTrigger value="testimonials">টেস্টিমোনিয়াল ({data.testimonials.length})</TabsTrigger>
        <TabsTrigger value="faqs">FAQ ({data.faqs.length})</TabsTrigger>
        <TabsTrigger value="samples">স্যাম্পল ({data.samples.length})</TabsTrigger>
      </TabsList>

      {/* Testimonials */}
      <TabsContent value="testimonials" className="mt-3 space-y-2">
        {data.testimonials.map((t) => (
          <Card key={t.id}>
            <CardContent className="grid gap-2 p-3 sm:grid-cols-2 lg:grid-cols-6">
              <Input className="h-8 text-xs" placeholder="নাম" value={get(t.id,"name",t.name)} onChange={(e)=>set(t.id,"name",e.target.value)} />
              <Input className="h-8 text-xs" placeholder="রোল" value={get(t.id,"role",t.role)} onChange={(e)=>set(t.id,"role",e.target.value)} />
              <Input className="h-8 text-xs" placeholder="কোট" value={get(t.id,"quote",t.quote)} onChange={(e)=>set(t.id,"quote",e.target.value)} />
              <Input type="number" min={1} max={5} className="h-8 text-xs" placeholder="রেটিং" value={get(t.id,"rating",t.rating)} onChange={(e)=>set(t.id,"rating",e.target.value)} />
              <div className="flex items-center gap-2"><Switch checked={get(t.id,"active",t.active)} onCheckedChange={(v)=>set(t.id,"active",v)} /> <span className="text-xs">অ্যাকটিভ</span></div>
              <div className="flex gap-1">
                <Button size="sm" variant="secondary" disabled={busy} onClick={() => save("testimonial", t.id, t)}><Save className="h-3 w-3" /></Button>
                <Button size="sm" variant="ghost" onClick={() => del("testimonial", t.id)}><Trash2 className="h-3 w-3 text-destructive" /></Button>
              </div>
            </CardContent>
          </Card>
        ))}
        <Card className="border-dashed">
          <CardContent className="grid gap-2 p-3 sm:grid-cols-2 lg:grid-cols-6">
            <Input className="h-8 text-xs" placeholder="নাম" value={newItem.name || ""} onChange={(e)=>setNewItem((n)=>({...n,name:e.target.value}))} />
            <Input className="h-8 text-xs" placeholder="রোল" value={newItem.role || ""} onChange={(e)=>setNewItem((n)=>({...n,role:e.target.value}))} />
            <Input className="h-8 text-xs" placeholder="কোট" value={newItem.quote || ""} onChange={(e)=>setNewItem((n)=>({...n,quote:e.target.value}))} />
            <Input type="number" min={1} max={5} className="h-8 text-xs" placeholder="রেটিং" value={newItem.rating || ""} onChange={(e)=>setNewItem((n)=>({...n,rating:Number(e.target.value)}))} />
            <div className="flex items-center gap-2"><Switch checked={newItem.active ?? true} onCheckedChange={(v)=>setNewItem((n)=>({...n,active:v}))} /> <span className="text-xs">অ্যাকটিভ</span></div>
            <Button size="sm" disabled={busy} onClick={() => add("testimonial")}><Plus className="mr-1 h-3 w-3" /> যোগ</Button>
          </CardContent>
        </Card>
      </TabsContent>

      {/* FAQs */}
      <TabsContent value="faqs" className="mt-3 space-y-2">
        {data.faqs.map((f) => (
          <Card key={f.id}>
            <CardContent className="grid gap-2 p-3 sm:grid-cols-[1fr_1fr_auto_auto_auto]">
              <Input className="h-8 text-xs" placeholder="প্রশ্ন" value={get(f.id,"question",f.question)} onChange={(e)=>set(f.id,"question",e.target.value)} />
              <Input className="h-8 text-xs" placeholder="উত্তর" value={get(f.id,"answer",f.answer)} onChange={(e)=>set(f.id,"answer",e.target.value)} />
              <div className="flex items-center gap-2"><Switch checked={get(f.id,"active",f.active)} onCheckedChange={(v)=>set(f.id,"active",v)} /> <span className="text-xs">অ্যাকটিভ</span></div>
              <Button size="sm" variant="secondary" disabled={busy} onClick={() => save("faq", f.id, f)}><Save className="h-3 w-3" /></Button>
              <Button size="sm" variant="ghost" onClick={() => del("faq", f.id)}><Trash2 className="h-3 w-3 text-destructive" /></Button>
            </CardContent>
          </Card>
        ))}
        <Card className="border-dashed">
          <CardContent className="grid gap-2 p-3 sm:grid-cols-[1fr_1fr_auto]">
            <Input className="h-8 text-xs" placeholder="প্রশ্ন" value={newItem.question || ""} onChange={(e)=>setNewItem((n)=>({...n,question:e.target.value}))} />
            <Input className="h-8 text-xs" placeholder="উত্তর" value={newItem.answer || ""} onChange={(e)=>setNewItem((n)=>({...n,answer:e.target.value}))} />
            <Button size="sm" disabled={busy} onClick={() => add("faq")}><Plus className="mr-1 h-3 w-3" /> যোগ</Button>
          </CardContent>
        </Card>
      </TabsContent>

      {/* Samples */}
      <TabsContent value="samples" className="mt-3 space-y-2">
        {data.samples.map((s) => (
          <Card key={s.id}>
            <CardContent className="grid gap-2 p-3 sm:grid-cols-[1fr_1fr_1fr_1fr_auto_auto_auto]">
              <Input className="h-8 text-xs" placeholder="টাইটেল" value={get(s.id,"title",s.title)} onChange={(e)=>set(s.id,"title",e.target.value)} />
              <Input className="h-8 text-xs" placeholder="ক্যাটাগরি" value={get(s.id,"category",s.category)} onChange={(e)=>set(s.id,"category",e.target.value)} />
              <Input className="h-8 text-xs" placeholder="ভিডিও URL" value={get(s.id,"videoUrl",s.videoUrl)} onChange={(e)=>set(s.id,"videoUrl",e.target.value)} />
              <Input className="h-8 text-xs" placeholder="পোস্টার URL" value={get(s.id,"posterUrl",s.posterUrl)} onChange={(e)=>set(s.id,"posterUrl",e.target.value)} />
              <div className="flex items-center gap-2"><Switch checked={get(s.id,"active",s.active)} onCheckedChange={(v)=>set(s.id,"active",v)} /> <span className="text-xs">অ্যাকটিভ</span></div>
              <Button size="sm" variant="secondary" disabled={busy} onClick={() => save("sample", s.id, s)}><Save className="h-3 w-3" /></Button>
              <Button size="sm" variant="ghost" onClick={() => del("sample", s.id)}><Trash2 className="h-3 w-3 text-destructive" /></Button>
            </CardContent>
          </Card>
        ))}
        <Card className="border-dashed">
          <CardContent className="grid gap-2 p-3 sm:grid-cols-[1fr_1fr_1fr_1fr_auto]">
            <Input className="h-8 text-xs" placeholder="টাইটেল" value={newItem.title || ""} onChange={(e)=>setNewItem((n)=>({...n,title:e.target.value}))} />
            <Input className="h-8 text-xs" placeholder="ক্যাটাগরি" value={newItem.category || ""} onChange={(e)=>setNewItem((n)=>({...n,category:e.target.value}))} />
            <Input className="h-8 text-xs" placeholder="ভিডিও URL" value={newItem.videoUrl || ""} onChange={(e)=>setNewItem((n)=>({...n,videoUrl:e.target.value}))} />
            <Input className="h-8 text-xs" placeholder="পোস্টার URL" value={newItem.posterUrl || ""} onChange={(e)=>setNewItem((n)=>({...n,posterUrl:e.target.value}))} />
            <Button size="sm" disabled={busy} onClick={() => add("sample")}><Plus className="mr-1 h-3 w-3" /> যোগ</Button>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
}

function AdminSettings() {
  const [s, setS] = useState<Record<string,string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    try {
      const r = await api<{ settings: Record<string,string> }>("/api/admin/settings");
      setS(r.settings || {});
    } catch (e:any) { toast.error(e.message); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function save() {
    setSaving(true);
    try {
      await api("/api/admin/settings", { method: "PUT", body: JSON.stringify(s) });
      toast.success("সেটিংস সেভ হয়েছে");
    } catch (e:any) { toast.error(e.message); }
    finally { setSaving(false); }
  }

  if (loading) return <div className="h-40 animate-pulse rounded-xl bg-muted" />;

  const fields = [
    { k: "whatsapp_number", label: "WhatsApp নাম্বার", ta: false },
    { k: "bkash_personal", label: "bKash নম্বর (পেমেন্ট নেওয়ার)", ta: false },
    { k: "launch_remaining", label: "লঞ্চ রিমেইনিং", ta: false },
    { k: "usd_to_bdt", label: "USD → BDT রেট", ta: false },
    { k: "wan_cost_per_sec_usd", label: "Wan খরচ / সেকেন্ড (USD)", ta: false },
  ];
  const legalFields = [
    { k: "terms_text", label: "শর্তাবলী (Terms)" },
    { k: "privacy_text", label: "প্রাইভেসি পলিসি" },
    { k: "refund_text", label: "রিফান্ড পলিসি" },
  ];

  return (
    <div className="space-y-3">
      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">জেনারেল সেটিংস</CardTitle></CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-2">
          {fields.map((f) => (
            <div key={f.k} className="space-y-1.5">
              <Label className="text-xs">{f.label}</Label>
              <Input className="h-9 text-sm" value={s[f.k] || ""} onChange={(e)=>setS((cur)=>({...cur,[f.k]:e.target.value}))} />
            </div>
          ))}
        </CardContent>
      </Card>

      <AdminStaffAccounts />

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">bKash QR কোড</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          <p className="text-xs text-muted-foreground">bKash অ্যাপ → My QR থেকে আপনার QR-এর ছবি আপলোড করুন। কাস্টমার পেমেন্ট পেজে এটি দেখবে।</p>
          <Input
            id="qr-upload"
            type="file"
            accept="image/*"
            className="h-9 text-sm"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              const fd = new FormData();
              fd.append("file", file);
              try { await uploadFile("/api/admin/settings/qr", fd); toast.success("QR আপলোড হয়েছে"); }
              catch (err: any) { toast.error(err.message); }
            }}
          />
          {s.bkash_qr_key && <p className="text-[11px] text-emerald-700">✓ একটি QR সেট করা আছে</p>}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">AI মডেলের দাম (USD / ১০ লাখ টোকেন)</CardTitle></CardHeader>
        <CardContent className="space-y-1.5">
          <p className="text-[11px] text-muted-foreground">JSON ফরম্যাট, যেমন: {`{"deepseek-flash":{"in":0.3,"out":1.2,"cache":0.006}}`} — খালি রাখলে ডিফল্ট দাম ব্যবহার হবে। প্রোভাইডারের দাম পেজ দেখে আপডেট করুন।</p>
          <Textarea rows={4} className="font-mono text-xs" value={s.llm_prices_json || ""} onChange={(e)=>setS((cur)=>({...cur,llm_prices_json:e.target.value}))} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">লিগ্যাল টেক্সট</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          {legalFields.map((f) => (
            <div key={f.k} className="space-y-1.5">
              <Label className="text-xs">{f.label}</Label>
              <Textarea rows={6} className="text-xs" value={s[f.k] || ""} onChange={(e)=>setS((cur)=>({...cur,[f.k]:e.target.value}))} />
            </div>
          ))}
        </CardContent>
      </Card>

      <Button onClick={save} disabled={saving}>
        {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
        সেভ করুন
      </Button>
    </div>
  );
}

function AdminStaffAccounts() {
  const [list, setList] = useState<any[]>([]);
  const [form, setForm] = useState({ email: "", name: "", role: "operator", password: "" });
  const [busy, setBusy] = useState(false);
  const load = useCallback(() => {
    api<{ staff: any[] }>("/api/admin/staff").then((r) => setList(r.staff)).catch((e) => toast.error(e.message));
  }, []);
  useEffect(() => { load(); }, [load]);
  async function add() {
    setBusy(true);
    try {
      await api("/api/admin/staff", { method: "POST", body: JSON.stringify(form) });
      toast.success("স্টাফ সেভ হয়েছে — ইমেইল ও পাসওয়ার্ড তাকে দিন");
      setForm({ email: "", name: "", role: "operator", password: "" });
      load();
    } catch (e: any) {
      toast.error(e.message === "password_min_10" ? "পাসওয়ার্ড কমপক্ষে ১০ অক্ষর" : e.message);
    } finally { setBusy(false); }
  }
  async function remove(id: string) {
    try { await api(`/api/admin/staff?id=${id}`, { method: "DELETE" }); load(); }
    catch (e: any) { toast.error(e.message); }
  }
  return (
    <Card>
      <CardHeader className="pb-3"><CardTitle className="text-sm">স্টাফ অ্যাকাউন্ট (অপারেটর / এডিটর)</CardTitle></CardHeader>
      <CardContent className="space-y-3">
        <div className="space-y-1">
          {list.map((u) => (
            <div key={u.id} className="flex items-center justify-between rounded border p-2 text-xs">
              <span><b>{u.name}</b> · {u.email} · <Badge variant="secondary">{u.role}</Badge></span>
              <Button size="sm" variant="ghost" onClick={() => remove(u.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
            </div>
          ))}
        </div>
        <div className="grid gap-2 sm:grid-cols-5">
          <Input id="staff-email" className="h-9 text-sm sm:col-span-2" placeholder="ইমেইল" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <Input id="staff-name" className="h-9 text-sm" placeholder="নাম" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <select id="staff-role" className="h-9 rounded-md border bg-background px-2 text-sm" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
            <option value="operator">operator</option>
            <option value="editor">editor</option>
            <option value="admin">admin</option>
          </select>
          <Input id="staff-pass" className="h-9 text-sm" type="text" placeholder="পাসওয়ার্ড (১০+)" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
        </div>
        <Button size="sm" onClick={add} disabled={busy}><Plus className="mr-1 h-3.5 w-3.5" /> যোগ করুন / পাসওয়ার্ড রিসেট</Button>
      </CardContent>
    </Card>
  );
}

function AdminCosts() {
  const [data, setData] = useState<{ rows: any[]; totals: any } | null>(null);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let active = true;
    api<{ rows: any[]; totals: any }>("/api/admin/costs")
      .then((r) => { if (active) setData(r); })
      .catch((e:any) => { if (active) toast.error(e.message); });
    return () => { active = false; };
  }, [reloadKey]);

  if (!data) return <div className="h-40 animate-pulse rounded-xl bg-muted" />;

  const t = data.totals || {};
  const rows = [...(data.rows || [])].sort((a,b) => (b.marginPct || 0) - (a.marginPct || 0));

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <StatCard label="মোট রাজস্ব" value={fmtBdt(t.revenue)} />
        <StatCard label="মোট খরচ (BDT)" value={fmtBdt(t.costBdt)} />
        <StatCard label="মোট মার্জিন %" value={`${t.marginPct || 0}%`} />
        <StatCard label="অর্ডার সংখ্যা" value={String(t.orders || 0)} />
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="max-h-[28rem] overflow-y-auto scroll-fancy">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>কোড</TableHead>
                  <TableHead>স্ট্যাটাস</TableHead>
                  <TableHead>রাজস্ব</TableHead>
                  <TableHead>খরচ</TableHead>
                  <TableHead>মার্জিন</TableHead>
                  <TableHead>মার্জিন %</TableHead>
                  <TableHead>রিজেন</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-mono text-xs">{r.code}</TableCell>
                    <TableCell><Badge className={statusColor[r.status]}>{statusLabelBn[r.status]}</Badge></TableCell>
                    <TableCell className="text-xs">{fmtBdt(r.revenue)}</TableCell>
                    <TableCell className="text-xs">{fmtBdt(r.costBdt)}</TableCell>
                    <TableCell className="text-xs">{fmtBdt(r.margin)}</TableCell>
                    <TableCell className={cn("text-xs font-medium", r.marginPct < 50 ? "text-amber-600" : "text-emerald-700")}>{r.marginPct}%</TableCell>
                    <TableCell className="text-xs">{r.regenCount}</TableCell>
                  </TableRow>
                ))}
                {rows.length === 0 && (
                  <TableRow><TableCell colSpan={7} className="py-8 text-center text-sm text-muted-foreground">কোন ডাটা নেই।</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <Card><CardContent className="p-3">
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="mt-1 text-lg font-bold">{value}</div>
    </CardContent></Card>
  );
}

function AdminQA() {
  const [orders, setOrders] = useState<any[]>([]);
  const [notes, setNotes] = useState<Record<string,string>>({});
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await api<{ orders: any[] }>("/api/admin/qa");
      setOrders(r.orders || []);
    } catch (e:any) { toast.error(e.message); }
  }, []);
  useEffect(() => { load(); }, [load]);

  async function decide(orderId: string, close: boolean) {
    setBusy(orderId + (close ? "-c" : "-n"));
    try {
      await api("/api/admin/qa", { method: "POST", body: JSON.stringify({ orderId, note: notes[orderId] || "", close }) });
      toast.success(close ? "অনুমোদিত ও বন্ধ" : "কোয়ালিটি ইস্যু নোট করা হয়েছে");
      load();
    } catch (e:any) { toast.error(e.message); }
    finally { setBusy(null); }
  }

  if (orders.length === 0) {
    return <Card><CardContent className="py-10 text-center text-sm text-muted-foreground">
      <ShieldCheck className="mx-auto mb-2 h-8 w-8 opacity-40" /> কোন QA ফ্ল্যাগড অর্ডার নেই।
    </CardContent></Card>;
  }

  return (
    <div className="space-y-2">
      {orders.map((o) => (
        <Card key={o.id}>
          <CardContent className="p-3">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-sm font-semibold">{o.code}</span>
                  <Badge className="bg-emerald-100 text-emerald-800">ডেলিভার্ড</Badge>
                </div>
                <div className="text-xs text-muted-foreground">{o.product?.nameBn || o.product?.name}</div>
                <div className="text-[11px] text-muted-foreground">অপারেটর: {o.operator?.name || "—"} · ডেলিভারি: {fmtDate(o.deliveredAt)}</div>
              </div>
            </div>
            <Textarea className="mt-2 text-xs" rows={2} placeholder="QA নোট…" value={notes[o.id] || ""} onChange={(e)=>setNotes((n)=>({...n,[o.id]:e.target.value}))} />
            <div className="mt-2 flex gap-2">
              <Button size="sm" variant="secondary" disabled={busy === o.id + "-n"} onClick={() => decide(o.id, false)}>
                {busy === o.id + "-n" ? <Loader2 className="mr-1 h-3 w-3 animate-spin" /> : <AlertCircle className="mr-1 h-3 w-3" />} কোয়ালিটি ইস্যু
              </Button>
              <Button size="sm" disabled={busy === o.id + "-c"} onClick={() => decide(o.id, true)}>
                {busy === o.id + "-c" ? <Loader2 className="mr-1 h-3 w-3 animate-spin" /> : <CheckCircle2 className="mr-1 h-3 w-3" />} অনুমোদন ও বন্ধ
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

function AdminStaffStats() {
  const [stats, setStats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api<{ stats: any[] }>("/api/admin/staff-stats")
      .then((r) => setStats(r.stats || []))
      .catch((e:any) => toast.error(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="h-40 animate-pulse rounded-xl bg-muted" />;
  if (stats.length === 0) return <Card><CardContent className="py-10 text-center text-sm text-muted-foreground">
    <Users className="mx-auto mb-2 h-8 w-8 opacity-40" /> কোন অপারেটর নেই।
  </CardContent></Card>;

  return (
    <Card>
      <CardContent className="p-0">
        <div className="max-h-96 overflow-y-auto scroll-fancy">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>নাম</TableHead>
                <TableHead>ইমেইল</TableHead>
                <TableHead>করা অর্ডার</TableHead>
                <TableHead>গড় রিজেন/শট</TableHead>
                <TableHead>অন-টাইম %</TableHead>
                <TableHead>কোয়ালিটি ইস্যু</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {stats.map((s) => (
                <TableRow key={s.id}>
                  <TableCell className="text-xs font-medium">{s.name}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{s.email}</TableCell>
                  <TableCell className="text-xs">{s.ordersDone}</TableCell>
                  <TableCell className="text-xs">{s.avgRegenPerShot}</TableCell>
                  <TableCell className={cn("text-xs font-medium", s.onTimePct < 80 ? "text-amber-600" : "text-emerald-700")}>{s.onTimePct}%</TableCell>
                  <TableCell className="text-xs">{s.qualityIssues}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}

// ───────────────────────── Root ─────────────────────────
export function StaffView({ navigate }: { navigate: (to: string) => void }) {
  const [me, setMe] = useState<Staff | null>(null);
  const [loadingMe, setLoadingMe] = useState(true);

  const loadMe = useCallback(async () => {
    try {
      const r = await api<{ staff: Staff | null }>("/api/staff/me");
      setMe(r.staff);
    } catch {
      setMe(null);
    } finally {
      setLoadingMe(false);
    }
  }, []);

  useEffect(() => { loadMe(); }, [loadMe]);

  async function logout() {
    try { await api("/api/staff/logout", { method: "POST" }); } catch {}
    await loadMe();
    toast.success("লগআউট হয়েছে");
  }

  if (loadingMe) {
    return (
      <div className="bangla flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!me) {
    return <LoginScreen navigate={navigate} onLogin={loadMe} />;
  }

  const isAdmin = me.role === "admin";
  const isOperator = me.role === "operator" || isAdmin;
  const isEditor = me.role === "editor" || isAdmin;

  return (
    <div className="bangla min-h-screen bg-muted/30">
      <TopBar me={me} onLogout={logout} navigate={navigate} />
      <div className="mx-auto max-w-6xl px-3 py-4 sm:px-4 sm:py-6">
        {isOperator && <OperatorView me={me} />}
        {isEditor && <EditorView me={me} />}
        {isAdmin && <AdminView />}
      </div>
    </div>
  );
}
