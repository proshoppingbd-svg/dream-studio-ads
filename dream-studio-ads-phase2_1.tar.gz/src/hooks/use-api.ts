"use client";
// hooks/use-api.ts — typed fetch helpers + customer OTP session store
const TOKEN_KEY = "dsa_token";
const PHONE_KEY = "dsa_phone";

export function setCustomerSession(phone: string, token: string) {
  localStorage.setItem(PHONE_KEY, phone);
  localStorage.setItem(TOKEN_KEY, token);
}
export function getCustomerSession(): { phone: string | null; token: string | null } {
  if (typeof window === "undefined") return { phone: null, token: null };
  return {
    phone: localStorage.getItem(PHONE_KEY),
    token: localStorage.getItem(TOKEN_KEY),
  };
}
export function clearCustomerSession() {
  localStorage.removeItem(PHONE_KEY);
  localStorage.removeItem(TOKEN_KEY);
}

export async function api<T = unknown>(path: string, opts: RequestInit = {}): Promise<T> {
  const res = await fetch(path, {
    ...opts,
    headers: { "content-type": "application/json", ...(opts.headers || {}) },
  });
  const text = await res.text();
  let data: any = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!res.ok) {
    const msg = data?.error || (typeof data === "string" ? data : `HTTP ${res.status}`);
    const err = new Error(msg) as any;
    err.status = res.status;
    err.payload = data;
    throw err;
  }
  return data as T;
}

// file upload helper
export async function uploadFile(path: string, formData: FormData): Promise<any> {
  const res = await fetch(path, { method: "POST", body: formData });
  const text = await res.text();
  let data: any = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!res.ok) throw new Error(data?.error || `HTTP ${res.status}`);
  return data;
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result as string);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

// resize/compress image client-side before upload
export async function compressImage(file: File, maxW = 1280, maxH = 1280, quality = 0.82): Promise<string> {
  const dataUrl = await fileToDataUrl(file);
  const img = new Image();
  await new Promise((r) => { img.onload = r; img.src = dataUrl; });
  let { width, height } = img;
  if (width > maxW) { height = Math.round(height * maxW / width); width = maxW; }
  if (height > maxH) { width = Math.round(width * maxH / height); height = maxH; }
  const canvas = document.createElement("canvas");
  canvas.width = width; canvas.height = height;
  const ctx = canvas.getContext("2d")!;
  ctx.drawImage(img, 0, 0, width, height);
  return canvas.toDataURL("image/jpeg", quality);
}
