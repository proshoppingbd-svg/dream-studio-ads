"use client";
// hooks/use-hash-route.ts — minimal hash router for the SPA shell.
// Routes:
//   #/                home
//   #/preview         free preview flow
//   #/order/:code     order/brief form
//   #/account          order list (OTP login)
//   #/account/orders/:id
//   #/terms #/privacy #/refund
//   #/studio          hidden studio waitlist
//   #/staff           staff dashboard (operator/editor/admin)
import { useCallback, useSyncExternalStore } from "react";

function subscribe(callback: () => void) {
  window.addEventListener("hashchange", callback);
  return () => window.removeEventListener("hashchange", callback);
}

function getSnapshot() {
  return window.location.hash || "#/";
}

function getServerSnapshot() {
  return "#/";
}

export function useHashRoute() {
  const hash = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  const navigate = useCallback((to: string) => {
    if (typeof window !== "undefined") window.location.hash = to;
  }, []);
  return { route: hash, navigate };
}

export function parseRoute(hash: string): {
  name: "home" | "preview" | "order" | "account" | "orderDetail" | "terms" | "privacy" | "refund" | "studio" | "staff" | "notfound";
  params: Record<string, string>;
} {
  const clean = hash.replace(/^#/, "");
  const parts = clean.split("/").filter(Boolean);
  const [first, second, third] = parts;
  if (!first) return { name: "home", params: {} };
  if (first === "preview") return { name: "preview", params: {} };
  if (first === "order" && second) return { name: "order", params: { productCode: second } };
  if (first === "account" && !second) return { name: "account", params: {} };
  if (first === "account" && second === "orders" && third)
    return { name: "orderDetail", params: { id: third } };
  if (first === "terms") return { name: "terms", params: {} };
  if (first === "privacy") return { name: "privacy", params: {} };
  if (first === "refund") return { name: "refund", params: {} };
  if (first === "studio") return { name: "studio", params: {} };
  if (first === "staff") return { name: "staff", params: {} };
  return { name: "notfound", params: {} };
}

// read query params after "?" inside the hash, e.g. #/account/orders/x?paid=1
export function readHashQuery(hash: string): Record<string, string> {
  const q = hash.split("?")[1] || "";
  const out: Record<string, string> = {};
  new URLSearchParams(q).forEach((v, k) => (out[k] = v));
  return out;
}
