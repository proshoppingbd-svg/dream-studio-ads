// GET /api/storage/[...key]?exp=<ms>&sig=<hex> — serve stored files.
// Only signed, expiring URLs are served. Supports HTTP Range so videos can
// be scrubbed/played on phones. Drive keys ("gd/<id>") stream from Google
// Drive; other keys are read from local disk.
import { promises as fs } from "fs";
import path from "path";
import { NextResponse } from "next/server";
import { LocalStorageHelpers, driveStorage, verifySignedKey, safeKey, contentTypeFor } from "@/lib/storage";

export const dynamic = "force-dynamic";

function sliceRange(size: number, range: string | null): { start: number; end: number } | null | "invalid" {
  if (!range) return null;
  const m = range.match(/^bytes=(\d*)-(\d*)$/);
  if (!m) return null;
  let start = m[1] ? Number(m[1]) : 0;
  let end = m[2] ? Number(m[2]) : size - 1;
  if (!m[1] && m[2]) { start = Math.max(0, size - Number(m[2])); end = size - 1; }
  end = Math.min(end, size - 1);
  if (start > end || start >= size) return "invalid";
  return { start, end };
}

export async function GET(req: Request, ctx: { params: Promise<{ key: string[] }> }) {
  const { key } = await ctx.params;
  const safe = safeKey(key.map(decodeURIComponent).join("/"));
  const url = new URL(req.url);
  const exp = url.searchParams.get("exp") || "";
  const sig = url.searchParams.get("sig") || "";
  if (!verifySignedKey(safe, exp, sig)) {
    return new NextResponse("forbidden", { status: 403 });
  }
  const range = req.headers.get("range");

  if (safe.startsWith("gd/")) {
    if (!driveStorage) return new NextResponse("storage not configured", { status: 503 });
    try {
      const s = await driveStorage.stream(safe, range || undefined);
      return new NextResponse(s.body, { status: s.status, headers: s.headers });
    } catch (e) {
      console.error("[storage] drive stream failed", e);
      return new NextResponse("not found", { status: 404 });
    }
  }

  const full = path.join(LocalStorageHelpers.root(), safe);
  try {
    const buf = await fs.readFile(full);
    const ct = contentTypeFor(full);
    const r = sliceRange(buf.length, range);
    if (r === "invalid") {
      return new NextResponse(null, { status: 416, headers: { "content-range": `bytes */${buf.length}` } });
    }
    if (r) {
      const part = buf.subarray(r.start, r.end + 1);
      return new NextResponse(new Uint8Array(part), {
        status: 206,
        headers: {
          "content-type": ct,
          "accept-ranges": "bytes",
          "content-range": `bytes ${r.start}-${r.end}/${buf.length}`,
          "content-length": String(part.length),
          "cache-control": "private, max-age=3600",
        },
      });
    }
    return new NextResponse(new Uint8Array(buf), {
      headers: { "content-type": ct, "accept-ranges": "bytes", "content-length": String(buf.length), "cache-control": "private, max-age=3600" },
    });
  } catch {
    return new NextResponse("not found", { status: 404 });
  }
}
