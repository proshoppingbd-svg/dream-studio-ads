// GET /api/health — liveness for Railway (200 when the database answers).
// Admins get a full service checklist with ?detail=1 (shown on Admin → System).
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { env, authMode } from "@/lib/env";
import { getStaff } from "@/lib/auth";
import { storage, driveStorage } from "@/lib/storage";
import { wanConfigured } from "@/lib/wan";
import { llmConfigured, modelFor } from "@/lib/llm";

export const dynamic = "force-dynamic";

let driveCache: { at: number; ok: boolean; detail: string } | null = null;

export async function GET(req: Request) {
  let dbOk = false;
  try {
    await db.$queryRaw`SELECT 1`;
    dbOk = true;
  } catch { /* reported below */ }

  const url = new URL(req.url);
  const staff = url.searchParams.get("detail") ? await getStaff() : null;
  if (!staff || staff.role !== "admin") {
    return NextResponse.json({ ok: dbOk }, { status: dbOk ? 200 : 503 });
  }

  const settings: Record<string, string> = {};
  if (dbOk) {
    for (const r of await db.setting.findMany({ where: { key: { in: ["worker_heartbeat", "bkash_personal", "bkash_qr_key"] } } })) settings[r.key] = r.value;
  }
  let hb: { at?: string; ffmpegDrawtext?: boolean; running?: number; concurrency?: number } = {};
  try { hb = JSON.parse(settings.worker_heartbeat || "{}"); } catch { /* ignore */ }
  const hbAge = hb.at ? (Date.now() - new Date(hb.at).getTime()) / 1000 : Infinity;

  let storageCheck: { ok: boolean; detail: string };
  if (driveStorage) {
    if (!driveCache || Date.now() - driveCache.at > 60_000) {
      try { await driveStorage.ping(); driveCache = { at: Date.now(), ok: true, detail: "Google Drive connected" }; }
      catch (e) { driveCache = { at: Date.now(), ok: false, detail: `Drive error: ${(e as Error).message.slice(0, 120)}` }; }
    }
    storageCheck = { ok: driveCache.ok, detail: driveCache.detail };
  } else {
    storageCheck = { ok: !env.isProd, detail: storage.name === "local" ? "local disk (wiped on every Railway deploy — set up Drive)" : storage.name };
  }

  const checks = {
    database: { ok: dbOk, detail: dbOk ? "connected" : "cannot reach database" },
    storage: storageCheck,
    worker: { ok: hbAge < 90, detail: hb.at ? `last heartbeat ${Math.round(hbAge)}s ago · ${hb.running ?? 0}/${hb.concurrency ?? "?"} jobs running` : "no heartbeat — is the worker service running?" },
    watermark: { ok: !!hb.ffmpegDrawtext, detail: hb.ffmpegDrawtext ? "ffmpeg drawtext available" : "ffmpeg drawtext missing on the worker" },
    wan: { ok: env.mockMode || wanConfigured(), detail: env.mockMode ? "mock" : wanConfigured() ? `${env.wanProvider} · ${env.wanModel} · ${env.wanResolution}` : "WAN_API_KEY missing" },
    llm: { ok: env.mockMode || llmConfigured(), detail: env.mockMode ? "mock" : llmConfigured() ? `${env.llmProvider} · heavy=${modelFor("heavy")} · light=${modelFor("light")} · vision=${env.visionProvider === "qwen" ? "qwen" : modelFor("vision")}` : "key or LLM_MODEL_HEAVY / LLM_MODEL_LIGHT missing" },
    firebase: { ok: authMode() === "firebase" || env.mockMode, detail: authMode() === "firebase" ? `project ${env.firebase.projectId}` : env.mockMode ? "mock OTP (123456)" : "Firebase config missing — customers cannot log in" },
    telegram: { ok: !!(env.telegramBotToken && env.telegramChatId), detail: env.telegramBotToken && env.telegramChatId ? "alerts on" : "TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID missing (alerts only in logs)" },
    payments: {
      ok: env.paymentMode === "manual_qr" ? !!settings.bkash_personal : true,
      detail: env.paymentMode === "manual_qr"
        ? `manual bKash QR · number ${settings.bkash_personal ? "set" : "NOT set"} · QR ${settings.bkash_qr_key ? "uploaded" : "not uploaded"}`
        : "bKash API",
    },
  };
  const ok = Object.values(checks).every((c) => c.ok);
  return NextResponse.json({ ok, mock: env.mockMode, checks });
}
