// GET /api/orders/list?token=<customerToken> — list orders for a customer
// Item 6: token-only access; phone is taken from the token.
// Item 13: also returns the customer's plan credits + expiry.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { readCustomerToken } from "@/lib/auth";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const token = url.searchParams.get("token") || "";
  if (!token) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const s = readCustomerToken(token);
  if (!s) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const phone = s.phone;

  const [orders, customer] = await Promise.all([
    db.order.findMany({
      where: { customerPhone: phone },
      include: { product: true, payments: true },
      orderBy: { createdAt: "desc" },
    }),
    db.customer.findUnique({ where: { phone }, select: { planCredits: true, planExpiresAt: true } }),
  ]);
  return NextResponse.json({
    orders,
    planCredits: customer?.planCredits ?? 0,
    planExpiresAt: customer?.planExpiresAt ?? null,
  });
}
