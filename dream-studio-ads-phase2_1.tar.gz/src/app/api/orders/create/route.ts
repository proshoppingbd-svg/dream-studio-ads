// POST /api/orders/create — create an order from a brief (status PENDING_PAYMENT)
// Phase 1C Item 1: requires a valid customer token; the phone comes ONLY from
//   the token, never from the request body.
// Item 2: random non-guessable order codes.
// Item 7: storage keys are cuid-based (no phone number in the path).
// Phase 1C Item 2: credit payment deducts atomically with updateMany and a
//   count === 1 guard, so concurrent orders can't double-spend a credit.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { env } from "@/lib/env";
import { generateOrderCode, slaDeadline } from "@/lib/orders";
import { rateLimit, getIp } from "@/lib/rateLimit";
import { storage, generateStorageKey } from "@/lib/storage";
import { readCustomerToken } from "@/lib/auth";
import type { Brief } from "@/lib/types";

export async function POST(req: Request) {
  const ip = getIp(req);
  const rl = await rateLimit(`order-create:${ip}`, 10, 60 * 1000);
  if (!rl.ok) return NextResponse.json({ error: "rate_limited" }, { status: 429 });

  const body = (await req.json()) as {
    token?: string;          // Phase 1C Item 1: required customer token
    name?: string;
    productCode?: string;
    brief?: Partial<Brief>;
    photos?: string[];
    logo?: string;
    useCredit?: boolean;
  };
  // Phase 1C Item 1: require a valid customer token; phone from token ONLY.
  if (!body.token) return NextResponse.json({ error: "token_required" }, { status: 401 });
  const session = readCustomerToken(body.token);
  if (!session) return NextResponse.json({ error: "invalid_token" }, { status: 401 });
  const phone = session.phone; // phone comes ONLY from the token

  if (!body.productCode) return NextResponse.json({ error: "product_required" }, { status: 400 });
  if (!body.brief?.rightsConfirmed) return NextResponse.json({ error: "rights_required" }, { status: 400 });
  if (!body.photos || body.photos.length < 1) return NextResponse.json({ error: "photo_required" }, { status: 400 });

  const product = await db.product.findUnique({ where: { code: body.productCode } });
  if (!product || !product.active) return NextResponse.json({ error: "product_inactive" }, { status: 400 });

  // LAUNCH price auto-disable after 10 paid
  if (product.code === "LAUNCH") {
    const paid = await db.order.count({
      where: { product: { code: "LAUNCH" }, status: { notIn: ["PENDING_PAYMENT", "REJECTED", "REFUNDED"] } },
    });
    if (paid >= 10) return NextResponse.json({ error: "launch_sold_out" }, { status: 410 });
  }

  // ensure customer exists (phone from token) — update name if provided
  await db.customer.upsert({
    where: { phone },
    update: { name: body.name || undefined },
    create: { phone, name: body.name },
  });

  // save photos (cuid-based keys, no phone in path)
  // Order code first, so every file lands in its own Drive folder:
  // DreamStudioAds/orders/<CODE>/photos/…
  const code = await generateOrderCode();

  const photoPaths: string[] = [];
  for (let i = 0; i < Math.min(body.photos.length, 5); i++) {
    const dataUrl = body.photos[i]!;
    const m = dataUrl.match(/^data:(image\/(\w+));base64,(.+)$/);
    if (!m) continue;
    const ext = m[2] === "jpeg" ? "jpg" : m[2];
    const buf = Buffer.from(m[3]!, "base64");
    const saved = await storage.save(buf, generateStorageKey(`orders/${code}/photos`, `${ext}`), m[1]!);
    photoPaths.push(saved.key);
  }

  let logoPath: string | undefined;
  if (body.logo && body.logo.startsWith("data:")) {
    const m = body.logo.match(/^data:(image\/(\w+));base64,(.+)$/);
    if (m) {
      const ext = m[2] === "jpeg" ? "jpg" : m[2];
      const buf = Buffer.from(m[3]!, "base64");
      const saved = await storage.save(buf, generateStorageKey(`orders/${code}/photos`, `logo.${ext}`), m[1]!);
      logoPath = saved.key;
    }
  }

  const brief: Brief = {
    productName: body.brief.productName || "",
    category: body.brief.category || "other",
    priceOffer: body.brief.priceOffer,
    photos: photoPaths,
    logo: logoPath,
    targetCustomer: body.brief.targetCustomer || "",
    tone: body.brief.tone || "premium",
    language: body.brief.language || "Bangla",
    cta: body.brief.cta || "",
    phoneOrPage: body.brief.phoneOrPage || phone,
    notes: body.brief.notes,
    rightsConfirmed: true,
  };

  const driveFolderUrl = await storage.folderUrl(`orders/${code}`).catch(() => null);

  // Phase 1C Item 2: atomic credit payment. A MONTHLY customer with
  // planCredits >= 1 and an unexpired plan can pay for a STANDARD/LAUNCH
  // order with 1 credit. The deduction is a single updateMany with a
  // count === 1 guard, so concurrent orders can't double-spend.
  if (body.useCredit && (product.code === "STANDARD" || product.code === "LAUNCH")) {
    const order = await db.$transaction(async (tx) => {
      // atomic credit deduction — only succeeds if the customer still has
      // >= 1 credit AND the plan hasn't expired.
      const claim = await tx.customer.updateMany({
        where: { phone, planCredits: { gte: 1 }, planExpiresAt: { gt: new Date() } },
        data: { planCredits: { decrement: 1 } },
      });
      if (claim.count !== 1) {
        throw new Error("no_credits");
      }
      const o = await tx.order.create({
        data: {
          code,
          customerPhone: phone,
          customerName: body.name,
          productId: product.id,
          status: "PAID",
          briefJson: JSON.stringify(brief),
          revisionsMax: product.revisions,
          slaDeadline: slaDeadline(product.deliverySla),
          paidAt: new Date(),
          driveFolderUrl,
        },
      });
      await tx.payment.create({
        data: {
          orderId: o.id,
          provider: "credit",
          amount: 0,
          status: "PAID",
          trxId: `CREDIT-${code}`,
          rawResponse: JSON.stringify({ creditsUsed: 1 }),
          manualNote: "Paid with 1 Monthly plan credit",
        },
      });
      return o;
    }).catch((e: any) => {
      if (e?.message === "no_credits") return null;
      throw e;
    });
    if (!order) return NextResponse.json({ error: "no_credits" }, { status: 400 });
    const { enqueue } = await import("@/lib/queue");
    await enqueue("generate_script", { orderId: order.id });
    const { notifyAdmin } = await import("@/lib/notify");
    await notifyAdmin(`🎟️ ${order.code}: new ${product.name} order paid with a Monthly plan credit.`);
    return NextResponse.json({ ok: true, order, paidWithCredit: true });
  }

  const order = await db.order.create({
    data: {
      code,
      customerPhone: phone,
      customerName: body.name,
      productId: product.id,
      status: "PENDING_PAYMENT",
      briefJson: JSON.stringify(brief),
      revisionsMax: product.revisions,
      // SLA starts when payment is confirmed (reset at PAID).
      slaDeadline: slaDeadline(product.deliverySla),
      driveFolderUrl,
    },
  });

  await db.payment.create({
    data: {
      orderId: order.id,
      provider: env.paymentMode === "manual_qr" ? "manual_qr" : env.mockMode ? "mock" : "bkash",
      amount: product.priceBdt,
      status: "PENDING",
    },
  });

  return NextResponse.json({ ok: true, order });
}

// GET — list products (for the order page to choose)
export async function GET() {
  const products = await db.product.findMany({ where: { active: true }, orderBy: { sortOrder: "asc" } });
  return NextResponse.json({ products });
}
