// GET /api/orders/[id]?token=<customerToken>  OR  staff session cookie
// POST /api/orders/[id]  { token, note }  — request a revision
// Item 6: requires a valid customer token (or staff session).
// The phone is taken ONLY from the token, never from the request.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff, readCustomerToken } from "@/lib/auth";
import { resolveVideoUrl } from "@/lib/orders";
import { storage } from "@/lib/storage";

function readTokenFromQuery(req: Request): string {
  const url = new URL(req.url);
  return url.searchParams.get("token") || "";
}

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;

  // Item 6: staff session OR customer token. No phone-only access.
  const staff = await getStaff();
  let customerPhone: string | null = null;
  if (!staff) {
    const token = readTokenFromQuery(req);
    if (!token) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
    const s = readCustomerToken(token);
    if (!s) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
    customerPhone = s.phone;
  }

  const order = await db.order.findUnique({
    where: { id },
    include: { product: true, shots: true, payments: true, revisions: true, costLogs: true, operator: { select: { id: true, name: true, email: true, role: true } } },
  });
  if (!order) return NextResponse.json({ error: "not_found" }, { status: 404 });
  if (!staff && order.customerPhone !== customerPhone) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }

  const finalVideoUrl = await resolveVideoUrl(order.finalVideoUrl);
  const shots = await Promise.all(
    order.shots.map(async (s) => ({
      ...s,
      videoUrl: await resolveVideoUrl(s.videoUrl),
    }))
  );
  const brief = JSON.parse(order.briefJson) as { photos: string[] };
  const photos = await Promise.all(
    (brief.photos || []).map((p) => storage.signedUrl(p))
  );

  const finalVideo15Url = await resolveVideoUrl(order.finalVideo15Url);
  const lastPayment = [...order.payments].sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt))[0] || null;
  const lastRejected = order.payments.filter((p) => p.status === "REJECTED").sort((a, b) => +new Date(b.updatedAt) - +new Date(a.updatedAt))[0] || null;
  const payment = {
    status: lastPayment?.status || null,
    rejectReason: order.status === "PENDING_PAYMENT" ? lastRejected?.rejectReason || null : null,
  };

  if (!staff) {
    // Customers never see costs, raw provider responses or staff details.
    const { costLogs: _c, operator: _o, driveFolderUrl: _d, qaNote: _q, payments, ...rest } = order;
    const safeOrder = { ...rest, payments: payments.map((p) => ({ id: p.id, status: p.status, amount: p.amount, provider: p.provider, createdAt: p.createdAt })) };
    return NextResponse.json({ order: safeOrder, shots: [], finalVideoUrl, finalVideo15Url, photos, payment });
  }
  return NextResponse.json({ order, shots, finalVideoUrl, finalVideo15Url, photos, payment });
}

// POST /api/orders/[id] — request a revision (customer token required)
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = (await req.json()) as { note?: string; token?: string };
  if (!body.token) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const s = readCustomerToken(body.token);
  if (!s) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const phone = s.phone;

  const order = await db.order.findUnique({ where: { id }, include: { product: true, operator: { select: { id: true, name: true, email: true, role: true } } } });
  if (!order) return NextResponse.json({ error: "not_found" }, { status: 404 });
  if (order.customerPhone !== phone) return NextResponse.json({ error: "forbidden" }, { status: 403 });
  if (order.revisionsUsed >= order.revisionsMax) {
    return NextResponse.json({ error: "no_revisions_left" }, { status: 400 });
  }
  if (!body.note || body.note.length > 500) {
    return NextResponse.json({ error: "note_required" }, { status: 400 });
  }

  await db.revision.create({ data: { orderId: order.id, note: body.note } });
  // Item 11: revision routes back to the SAME operator (keep operatorId)
  // and to the editor queue, with a fresh 24h SLA.
  await db.order.update({
    where: { id: order.id },
    data: {
      status: "REVISION_REQUESTED",
      revisionsUsed: { increment: 1 },
      slaDeadline: new Date(Date.now() + 24 * 60 * 60 * 1000),
    },
  });
  return NextResponse.json({ ok: true });
}
