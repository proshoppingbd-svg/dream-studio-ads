// POST /api/payment/submit — customer submits a manual bKash QR payment.
// Body (JSON): { token, orderId, senderNumber, trxId, amount, screenshot? (data URL) }
// → Payment SUBMITTED + order PAYMENT_SUBMITTED + Telegram alert to admin.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { readCustomerToken } from "@/lib/auth";
import { rateLimit, getIp } from "@/lib/rateLimit";
import { storage, generateStorageKey } from "@/lib/storage";
import { notifyAdmin } from "@/lib/notify";

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as {
    token?: string; orderId?: string; senderNumber?: string; trxId?: string; amount?: number | string; screenshot?: string;
  };
  const session = body.token ? readCustomerToken(body.token) : null;
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const ip = getIp(req);
  const rl = await rateLimit(`pay-submit-ip:${ip}`, 20, 60 * 60 * 1000);
  if (!rl.ok) return NextResponse.json({ error: "rate_limited" }, { status: 429 });

  const order = await db.order.findUnique({ where: { id: body.orderId || "" }, include: { product: true } });
  if (!order || order.customerPhone !== session.phone) return NextResponse.json({ error: "not_found" }, { status: 404 });
  if (order.status !== "PENDING_PAYMENT") return NextResponse.json({ error: "not_pending", current: order.status }, { status: 400 });

  const sender = String(body.senderNumber || "").replace(/\s|-/g, "").replace(/^\+?88/, "");
  if (!/^01[3-9]\d{8}$/.test(sender)) return NextResponse.json({ error: "bad_sender" }, { status: 400 });
  const trxId = String(body.trxId || "").trim().toUpperCase();
  if (!/^[A-Z0-9]{10}$/.test(trxId)) return NextResponse.json({ error: "bad_trxid" }, { status: 400 });
  const amount = Math.round(Number(body.amount));
  if (!Number.isFinite(amount) || amount <= 0) return NextResponse.json({ error: "bad_amount" }, { status: 400 });

  // Reuse is blocked by a unique constraint — check first for a clear message.
  const used = await db.payment.findUnique({ where: { trxId } });
  if (used) return NextResponse.json({ error: "trxid_used" }, { status: 409 });

  // Max 3 real submissions per order per day (typos above don't count).
  const recent = await db.payment.count({
    where: { orderId: order.id, submittedAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } },
  });
  if (recent >= 3) return NextResponse.json({ error: "too_many_submissions" }, { status: 429 });

  let screenshotKey: string | undefined;
  if (body.screenshot) {
    const m = body.screenshot.match(/^data:(image\/(\w+));base64,(.+)$/);
    if (m && m[3]!.length < 8_000_000) {
      const ext = m[2] === "jpeg" ? "jpg" : m[2]!;
      screenshotKey = (await storage.save(Buffer.from(m[3]!, "base64"), generateStorageKey(`orders/${order.code}/payment`, ext), m[1]!)).key;
    }
  }

  try {
    await db.$transaction(async (tx) => {
      const moved = await tx.order.updateMany({ where: { id: order.id, status: "PENDING_PAYMENT" }, data: { status: "PAYMENT_SUBMITTED" } });
      if (moved.count !== 1) throw new Error("not_pending");
      const open = await tx.payment.findFirst({ where: { orderId: order.id, status: "PENDING" }, orderBy: { createdAt: "desc" } });
      const data = { provider: "manual_qr", trxId, senderNumber: sender, amountEntered: amount, screenshotKey, submittedAt: new Date(), status: "SUBMITTED", rejectReason: null };
      if (open) await tx.payment.update({ where: { id: open.id }, data });
      else await tx.payment.create({ data: { ...data, orderId: order.id, amount: order.product.priceBdt } });
    });
  } catch (e: any) {
    if (e?.code === "P2002") return NextResponse.json({ error: "trxid_used" }, { status: 409 });
    if (e?.message === "not_pending") return NextResponse.json({ error: "not_pending" }, { status: 400 });
    throw e;
  }

  const mismatch = amount !== order.product.priceBdt ? ` ⚠️ amount differs (due ৳${order.product.priceBdt})` : "";
  await notifyAdmin(`💰 New bKash payment to check\nOrder: ${order.code} (${order.product.name})\nAmount entered: ৳${amount}${mismatch}\nTrxID: ${trxId}\nSender: ${sender}\nOpen Staff → Admin → Payments to confirm.`);
  return NextResponse.json({ ok: true });
}
