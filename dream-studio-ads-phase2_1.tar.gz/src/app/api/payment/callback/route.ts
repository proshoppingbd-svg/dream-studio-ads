// GET /api/payment/callback?orderId=&paymentID= — bKash returns user here
// Then execute + verify and mark PAID. Idempotent.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { env } from "@/lib/env";
import { paymentProvider } from "@/lib/payment";
import { enqueue } from "@/lib/queue";
import { smsTemplates } from "@/lib/sms";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const orderId = url.searchParams.get("orderId");
  const paymentID = url.searchParams.get("paymentID");
  if (!orderId || !paymentID) {
    return NextResponse.redirect(new URL("/#/account?paid=0", env.appUrl));
  }
  const order = await db.order.findUnique({
    where: { id: orderId },
    include: { payments: true, product: true, customer: true },
  });
  if (!order) return NextResponse.redirect(new URL("/#/account?paid=0&err=order", env.appUrl));

  // already paid? idempotent
  if (order.status === "PAID" || order.payments.some((p) => p.status === "PAID")) {
    return NextResponse.redirect(new URL(`/#/account/orders/${order.id}?paid=1`, env.appUrl));
  }

  try {
    const exec = await paymentProvider.executePayment(paymentID);
    const verify = await paymentProvider.verifyPayment(paymentID, exec.trxId);
    if (verify.paid) {
      await db.payment.updateMany({
        where: { orderId: order.id, status: "PENDING" },
        data: { status: "PAID", trxId: exec.trxId, rawResponse: verify.raw },
      });
      await db.order.update({
        where: { id: order.id },
        data: { status: "PAID", paidAt: new Date() },
      });
      // enqueue script generation
      await enqueue("generate_script", { orderId: order.id });
      // queue SMS
      await enqueue("send_sms", { phone: order.customerPhone, message: smsTemplates.paymentReceived(order.code, order.product.priceBdt) });
      return NextResponse.redirect(new URL(`/#/account/orders/${order.id}?paid=1`, env.appUrl));
    }
    await db.payment.updateMany({
      where: { orderId: order.id, status: "PENDING" },
      data: { status: "FAILED", rawResponse: verify.raw },
    });
    return NextResponse.redirect(new URL(`/#/account/orders/${order.id}?paid=0&err=verify`, env.appUrl));
  } catch (e: unknown) {
    return NextResponse.redirect(new URL(`/#/account/orders/${order.id}?paid=0&err=${encodeURIComponent(String(e))}`, env.appUrl));
  }
}
