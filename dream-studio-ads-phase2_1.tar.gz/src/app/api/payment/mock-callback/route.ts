// GET /api/payment/mock-callback?pid=&invoice=&amount= — auto-marks paid in mock mode.
// Item 1: returns 404 unless MOCK_MODE === true AND NODE_ENV !== "production".
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { env } from "@/lib/env";
import { markOrderPaid } from "@/lib/payments";

export async function GET(req: Request) {
  // Item 1: hard lock. Even if someone flips MOCK_MODE on in prod, this
  // endpoint stays 404.
  if (!env.mockMode || env.isProd) {
    return new NextResponse("Not Found", { status: 404 });
  }

  const url = new URL(req.url);
  const pid = url.searchParams.get("pid");
  const invoice = url.searchParams.get("invoice");
  const amount = Number(url.searchParams.get("amount"));
  if (!pid || !invoice) return NextResponse.json({ error: "bad" }, { status: 400 });

  const order = await db.order.findFirst({
    where: { code: invoice },
    include: { product: true, customer: true },
  });
  if (!order) return NextResponse.json({ error: "order_not_found" }, { status: 404 });

  // idempotent
  if (order.status === "PAID") return NextResponse.redirect(new URL(`/#/account/orders/${order.id}?paid=1`, env.appUrl));

  await markOrderPaid({ orderId: order.id, fromStatuses: ["PENDING_PAYMENT"], newPayment: { provider: "mock", amount: amount || order.product.priceBdt, trxId: `MOCK-${order.code}-${Date.now().toString(36)}`, raw: JSON.stringify({ mock: true, pid }) } });

  const html = `<!doctype html><html><head><meta charset="utf-8"><title>Payment</title>
    <meta http-equiv="refresh" content="0;url=${env.appUrl}/#/account/orders/${order.id}?paid=1"></head>
    <body style="font-family:sans-serif;padding:2rem"><h2>পেমেন্ট সফল হয়েছে ✓</h2><p>আপনার অর্ডার প্রসেস করা হচ্ছে...</p>
    <script>setTimeout(()=>location.href='${env.appUrl}/#/account/orders/${order.id}?paid=1',500)</script>
    </body></html>`;
  return new NextResponse(html, { headers: { "content-type": "text/html" } });
}
