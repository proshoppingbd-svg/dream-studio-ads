// POST /api/payment/manual — admin marks an order paid manually
// (e.g. cash or a payment made outside the QR form). MONTHLY adds credits.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";
import { markOrderPaid } from "@/lib/payments";

export async function POST(req: Request) {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const body = (await req.json()) as { orderId?: string; note?: string };
  if (!body.orderId) return NextResponse.json({ error: "orderId_required" }, { status: 400 });
  const order = await db.order.findUnique({ where: { id: body.orderId }, include: { product: true } });
  if (!order) return NextResponse.json({ error: "not_found" }, { status: 404 });
  const r = await markOrderPaid({
    orderId: order.id,
    fromStatuses: ["PENDING_PAYMENT", "PAYMENT_SUBMITTED"],
    newPayment: {
      provider: "manual",
      amount: order.product.priceBdt,
      trxId: `MANUAL-${order.code}-${Date.now().toString(36)}`,
      note: body.note || `Manual confirmation by ${staff.email}`,
      raw: JSON.stringify({ by: staff.email, at: new Date().toISOString() }),
    },
  });
  if (!r.ok) return NextResponse.json({ error: r.error === "wrong_status" ? "not_pending" : r.error }, { status: 400 });
  return NextResponse.json({ ok: true });
}
