// POST /api/payment/create — create payment for an order
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { env } from "@/lib/env";
import { paymentProvider } from "@/lib/payment";

export async function POST(req: Request) {
  // Phase 2: automatic bKash checkout is only used when PAYMENT_MODE=bkash_api.
  // The default (manual_qr) uses /api/payment/submit + the admin check.
  // NOTE: review the callback checks (paymentID ↔ order, amount, status) before enabling.
  if (env.paymentMode !== "bkash_api") {
    return NextResponse.json({ error: "manual_qr_mode" }, { status: 400 });
  }
  const body = (await req.json()) as { orderId?: string };
  if (!body.orderId) return NextResponse.json({ error: "orderId_required" }, { status: 400 });
  const order = await db.order.findUnique({
    where: { id: body.orderId },
    include: { product: true, payments: true },
  });
  if (!order) return NextResponse.json({ error: "not_found" }, { status: 404 });
  if (order.status !== "PENDING_PAYMENT") {
    return NextResponse.json({ error: "not_pending" }, { status: 400 });
  }

  // idempotency: reuse existing PENDING payment if any
  const existing = order.payments.find((p) => p.status === "PENDING");
  if (existing && existing.trxId) {
    // already has a payment id from provider — return its payUrl (mock)
  }

  const callbackUrl = `${env.appUrl}/api/payment/callback?orderId=${order.id}`;
  const res = await paymentProvider.createPayment({
    amount: order.product.priceBdt,
    merchantInvoice: order.code,
    callbackUrl,
    ref: order.id,
  });

  await db.payment.updateMany({
    where: { orderId: order.id, status: "PENDING" },
    data: { status: "PENDING", trxId: res.paymentId, rawResponse: res.raw || null },
  });

  return NextResponse.json({
    payUrl: res.payUrl,
    paymentId: res.paymentId,
    amount: order.product.priceBdt,
    provider: paymentProvider.name,
  });
}
