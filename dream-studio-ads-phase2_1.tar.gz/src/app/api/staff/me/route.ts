// GET /api/staff/me — current staff
import { NextResponse } from "next/server";
import { getStaff } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET() {
  const staff = await getStaff();
  if (!staff) return NextResponse.json({ staff: null });
  const full = await db.staffUser.findUnique({ where: { id: staff.id } });
  return NextResponse.json({ staff: full ? { id: full.id, email: full.email, name: full.name, role: full.role } : null });
}
