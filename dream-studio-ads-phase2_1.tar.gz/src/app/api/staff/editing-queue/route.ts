// GET /api/staff/editing-queue — editor/admin: EDITING + REVISION_REQUESTED
// orders sorted by SLA (soonest first). Replaces the manual order-ID workaround.
// Item 11: REVISION_REQUESTED orders appear here so the editor sees the
// revision note and can re-upload.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";
import { isOverdue } from "@/lib/status";

export async function GET() {
  const staff = await getStaff();
  if (!staff) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (staff.role !== "editor" && staff.role !== "admin") {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }
  const orders = await db.order.findMany({
    where: { status: { in: ["EDITING", "REVISION_REQUESTED"] } },
    include: { product: true, operator: { select: { id: true, name: true, email: true, role: true } }, revisions: { orderBy: { createdAt: "desc" } } },
    orderBy: { slaDeadline: "asc" },
  });
  // attach the latest revision note + overdue flag
  const annotated = orders.map((o) => ({
    id: o.id,
    code: o.code,
    status: o.status,
    product: o.product,
    operator: o.operator,
    slaDeadline: o.slaDeadline,
    overdue: isOverdue(o.slaDeadline),
    latestRevisionNote: o.revisions[0]?.note || null,
    customerPhone: o.customerPhone,
    customerName: o.customerName,
    finalVideoUrl: o.finalVideoUrl,
    finalVideo15Url: o.finalVideo15Url,
    scriptJson: o.scriptJson,
    createdAt: o.createdAt,
  }));
  return NextResponse.json({ orders: annotated });
}
