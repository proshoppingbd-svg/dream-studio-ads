// GET /api/staff/queue — operator queue (paid orders needing work)
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";
import { isOverdue } from "@/lib/orders";

export async function GET() {
  const staff = await getStaff();
  if (!staff) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (staff.role !== "operator" && staff.role !== "admin") {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }

  const orders = await db.order.findMany({
    where: {
      status: { in: ["PAID", "SCRIPTING", "SCRIPT_READY", "SCRIPT_FAILED", "MANUAL_REVIEW", "GENERATING", "QC", "REVISION_REQUESTED"] },
    },
    include: { product: true, shots: true, operator: { select: { id: true, name: true, email: true, role: true } } },
    orderBy: { slaDeadline: "asc" },
  });
  // annotate overdue
  const annotated = orders.map((o) => ({ ...o, overdue: isOverdue(o.slaDeadline) }));
  return NextResponse.json({ orders: annotated });
}
