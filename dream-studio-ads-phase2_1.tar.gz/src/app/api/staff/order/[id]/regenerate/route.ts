// POST /api/staff/order/[id]/regenerate — regenerate a single shot
// (optionally with a new prompt).
// Item 16: only the claimer (or admin) can regenerate.
// Item 16: cap regenerations at 3 per shot; after that, the shot is locked
// and only an admin can unlock it via /unlock-regen.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";
import { enqueue } from "@/lib/queue";
import { logCost } from "@/lib/aiService";
import { getSettingCosts } from "@/lib/costs";

const REGEN_CAP = 3;

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const staff = await getStaff();
  if (!staff) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (staff.role !== "operator" && staff.role !== "admin") {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }
  const { id } = await ctx.params;
  const body = (await req.json()) as { shotId?: string; newPrompt?: string };
  if (!body.shotId) return NextResponse.json({ error: "shotId_required" }, { status: 400 });

  const order = await db.order.findUnique({ where: { id } });
  if (!order) return NextResponse.json({ error: "not_found" }, { status: 404 });
  // Item 16: claimer-only.
  if (order.operatorId && order.operatorId !== staff.id && staff.role !== "admin") {
    return NextResponse.json({ error: "claimed_by_other" }, { status: 409 });
  }

  const shot = await db.shot.findUnique({ where: { id: body.shotId } });
  if (!shot || shot.orderId !== id) return NextResponse.json({ error: "not_found" }, { status: 404 });

  // Item 16: regen cap.
  if (shot.regenLocked || shot.regenCount >= REGEN_CAP) {
    await db.shot.update({ where: { id: shot.id }, data: { regenLocked: true } });
    return NextResponse.json(
      { error: "regen_capped", regenCount: shot.regenCount, cap: REGEN_CAP },
      { status: 400 }
    );
  }

  await db.shot.update({
    where: { id: shot.id },
    data: {
      status: "GENERATING",
      regenCount: { increment: 1 },
      prompt: body.newPrompt || shot.prompt,
      // lock if this regen hits the cap
      regenLocked: shot.regenCount + 1 >= REGEN_CAP,
    },
  });

  // Item 18: log regen cost using the configured Wan rate.
  const costs = await getSettingCosts();
  const usd = costs.wanCostPerSecUsd * 5; // 5-second shot
  await logCost({
    orderId: id,
    type: "regeneration",
    cost: { usd, bdt: usd * costs.usdToBdt, detail: `regen shot ${shot.shotNo}` },
  });
  await enqueue("generate_shot", { orderId: id, shotId: shot.id });
  return NextResponse.json({ ok: true });
}
