// POST /api/staff/order/[id]/claim — operator claims an order
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const staff = await getStaff();
  if (!staff) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (staff.role !== "operator" && staff.role !== "admin") {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }
  const { id } = await ctx.params;
  const order = await db.order.findUnique({ where: { id } });
  if (!order) return NextResponse.json({ error: "not_found" }, { status: 404 });
  if (order.operatorId && order.operatorId !== staff.id) {
    return NextResponse.json({ error: "claimed_by_other" }, { status: 409 });
  }
  await db.order.update({ where: { id }, data: { operatorId: staff.id } });
  return NextResponse.json({ ok: true });
}
