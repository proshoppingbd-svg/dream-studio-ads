// POST /api/staff/order/[id]/generate — submit all Wan jobs in parallel for an order's shots.
// Item 16: only the operator who claimed the order (or admin) can generate.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";
import { enqueue } from "@/lib/queue";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const staff = await getStaff();
  if (!staff) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (staff.role !== "operator" && staff.role !== "admin") {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }
  const { id } = await ctx.params;
  const order = await db.order.findUnique({
    where: { id },
    include: { shots: true, product: true },
  });
  if (!order) return NextResponse.json({ error: "not_found" }, { status: 404 });
  if (!order.scriptJson) return NextResponse.json({ error: "no_script" }, { status: 400 });

  // Item 16: claimer-only (admin bypasses).
  if (order.operatorId && order.operatorId !== staff.id && staff.role !== "admin") {
    return NextResponse.json({ error: "claimed_by_other" }, { status: 409 });
  }

  await db.order.update({ where: { id }, data: { status: "GENERATING" } });

  let enqueued = 0;
  for (const shot of order.shots.filter((s) => s.status === "PENDING" || s.status === "REJECTED")) {
    await db.shot.update({ where: { id: shot.id }, data: { status: "GENERATING" } });
    await enqueue("generate_shot", { orderId: order.id, shotId: shot.id });
    enqueued++;
  }
  return NextResponse.json({ ok: true, enqueued });
}
