// POST /api/staff/order/[id]/qc — submit QC checklist, move to EDITING
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const staff = await getStaff();
  if (!staff) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (staff.role !== "operator" && staff.role !== "admin") {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }
  const { id } = await ctx.params;
  const body = (await req.json()) as {
    productCorrect?: boolean;
    noDeformed?: boolean;
    noGarbledText?: boolean;
    noWatermark?: boolean;
    toneMatch?: boolean;
  };
  const checks = [body.productCorrect, body.noDeformed, body.noGarbledText, body.noWatermark, body.toneMatch];
  if (!checks.every(Boolean)) {
    return NextResponse.json({ error: "qc_failed" }, { status: 400 });
  }
  await db.order.update({ where: { id }, data: { status: "EDITING" } });
  return NextResponse.json({ ok: true });
}
