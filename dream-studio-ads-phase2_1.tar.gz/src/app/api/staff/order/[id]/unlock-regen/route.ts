// POST /api/staff/order/[id]/unlock-regen — admin only: unlock a shot that
// hit the 3-regeneration cap so the operator can regenerate again.
// Item 16.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const staff = await getStaff();
  if (!staff) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (staff.role !== "admin") {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }
  const { id } = await ctx.params;
  const body = (await req.json().catch(() => ({}))) as { shotId?: string };
  if (!body.shotId) return NextResponse.json({ error: "shotId_required" }, { status: 400 });
  const shot = await db.shot.findUnique({ where: { id: body.shotId } });
  if (!shot || shot.orderId !== id) return NextResponse.json({ error: "not_found" }, { status: 404 });
  await db.shot.update({ where: { id: shot.id }, data: { regenLocked: false } });
  return NextResponse.json({ ok: true });
}
