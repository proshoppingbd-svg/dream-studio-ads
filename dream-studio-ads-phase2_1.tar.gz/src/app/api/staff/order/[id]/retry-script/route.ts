// POST /api/staff/order/[id]/retry-script — operator/admin: retry a stuck
// SCRIPT_FAILED order by re-enqueuing the generate_script job.
// Item 14.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";
import { enqueue } from "@/lib/queue";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const staff = await getStaff();
  if (!staff) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (staff.role !== "operator" && staff.role !== "admin") {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }
  const { id } = await ctx.params;
  const order = await db.order.findUnique({ where: { id } });
  if (!order) return NextResponse.json({ error: "not_found" }, { status: 404 });
  // Only retryable from SCRIPT_FAILED (or stuck SCRIPTING).
  if (order.status !== "SCRIPT_FAILED" && order.status !== "SCRIPTING") {
    return NextResponse.json({ error: "not_retryable", current: order.status }, { status: 400 });
  }
  // Item 16: only the claimer (or admin) can retry.
  if (order.operatorId && order.operatorId !== staff.id && staff.role !== "admin") {
    return NextResponse.json({ error: "claimed_by_other" }, { status: 409 });
  }
  await db.order.update({ where: { id }, data: { status: "PAID" } });
  await enqueue("generate_script", { orderId: id });
  return NextResponse.json({ ok: true });
}
