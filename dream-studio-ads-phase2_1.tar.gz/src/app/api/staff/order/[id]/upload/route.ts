// POST /api/staff/order/[id]/upload — editor/admin: upload final MP4 → DELIVERED.
// Item 8 (Phase 1): accepts video (required) and video15 (required for PREMIUM).
// Order status must be EDITING (initial delivery) or REVISION_REQUESTED
// (re-delivery after a revision).
// Saves to storage, sets finalVideoUrl / finalVideo15Url, status DELIVERED.
// Flags 1 in 5 orders for QA, enqueues the "ad delivered" SMS with a signed link,
// and returns { ok, qaFlag, has15 }.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";
import { storage, generateStorageKey } from "@/lib/storage";
import { enqueue } from "@/lib/queue";
import { smsTemplates } from "@/lib/sms";
import { env } from "@/lib/env";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const staff = await getStaff();
  if (!staff) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (staff.role !== "editor" && staff.role !== "admin") {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }
  const { id } = await ctx.params;
  const order = await db.order.findUnique({ where: { id }, include: { product: true } });
  if (!order) return NextResponse.json({ error: "not_found" }, { status: 404 });
  // Item 8: order must be EDITING (initial delivery) or REVISION_REQUESTED
  // (re-delivery after a revision).
  if (order.status !== "EDITING" && order.status !== "REVISION_REQUESTED") {
    return NextResponse.json({ error: "not_editing", current: order.status }, { status: 400 });
  }

  const form = await req.formData();
  const file = form.get("video") as File | null;
  const file15 = form.get("video15") as File | null;
  if (!file) return NextResponse.json({ error: "video_required" }, { status: 400 });

  // Item 8: PREMIUM requires the 15s cut.
  const isPremium = order.product.code === "PREMIUM";
  if (isPremium && !file15) {
    return NextResponse.json({ error: "video15_required_for_premium" }, { status: 400 });
  }

  const buf = Buffer.from(await file.arrayBuffer());
  const key = (await storage.save(buf, generateStorageKey(`orders/${order.code}/delivered`, "mp4"), "video/mp4")).key;

  let key15: string | undefined;
  if (file15) {
    const buf15 = Buffer.from(await file15.arrayBuffer());
    key15 = (await storage.save(buf15, generateStorageKey(`orders/${order.code}/delivered`, "15s.mp4"), "video/mp4")).key;
  }

  // Item 8: random QA — flag 1 in 5 delivered orders for admin spot-review.
  const qaFlag = Math.random() < 0.2;

  await db.order.update({
    where: { id },
    data: {
      status: "DELIVERED",
      finalVideoUrl: key,
      finalVideo15Url: key15,
      deliveredAt: new Date(),
      qaFlag,
    },
  });

  // Item 8 + 11: enqueue the delivery SMS with a signed link (the customer
  // order-detail page resolves a fresh signed URL on each visit).
  const link = `${env.appUrl}/#/account/orders/${order.id}`;
  await enqueue("send_sms", { phone: order.customerPhone, message: smsTemplates.adDelivered(order.code, link) });

  return NextResponse.json({ ok: true, qaFlag, has15: !!key15 });
}
