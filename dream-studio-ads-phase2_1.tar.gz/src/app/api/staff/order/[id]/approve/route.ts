// POST /api/staff/order/[id]/approve — approve a shot
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const staff = await getStaff();
  if (!staff) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  if (staff.role !== "operator" && staff.role !== "admin") {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }
  const { id } = await ctx.params;
  const body = (await req.json()) as { shotId?: string; approve?: boolean };
  if (!body.shotId) return NextResponse.json({ error: "shotId_required" }, { status: 400 });
  const shot = await db.shot.findUnique({ where: { id: body.shotId } });
  if (!shot || shot.orderId !== id) return NextResponse.json({ error: "not_found" }, { status: 404 });

  await db.shot.update({
    where: { id: shot.id },
    data: { status: body.approve === false ? "REJECTED" : "APPROVED" },
  });

  // check if all shots approved → set QC
  const order = await db.order.findUnique({ where: { id }, include: { shots: true } });
  if (order && order.shots.length > 0 && order.shots.every((s) => s.status === "APPROVED")) {
    await db.order.update({ where: { id }, data: { status: "QC" } });
  } else if (order && order.status === "QC" && order.shots.some((s) => s.status !== "APPROVED")) {
    // back to GENERATING if any shot got un-approved
    await db.order.update({ where: { id }, data: { status: "GENERATING" } });
  }
  return NextResponse.json({ ok: true });
}
