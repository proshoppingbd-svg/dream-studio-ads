// POST /api/staff/login — email + password
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyPassword, createStaffSession } from "@/lib/auth";
import { rateLimit, getIp } from "@/lib/rateLimit";

export async function POST(req: Request) {
  const ip = getIp(req);
  const rl = await rateLimit(`staff-login:${ip}`, 10, 60 * 1000);
  if (!rl.ok) return NextResponse.json({ error: "rate_limited" }, { status: 429 });

  const body = (await req.json()) as { email?: string; password?: string };
  const email = (body.email || "").toLowerCase().trim();
  if (!email || !body.password) return NextResponse.json({ error: "missing" }, { status: 400 });
  const staff = await db.staffUser.findUnique({ where: { email } });
  if (!staff || !verifyPassword(body.password, staff.passwordHash)) {
    return NextResponse.json({ error: "invalid" }, { status: 401 });
  }
  await createStaffSession(staff.id, staff.email, staff.role);
  return NextResponse.json({ ok: true, staff: { id: staff.id, email: staff.email, name: staff.name, role: staff.role } });
}
