// POST /api/studio/waitlist — hidden studio stub waitlist
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit, getIp } from "@/lib/rateLimit";

export async function POST(req: Request) {
  const ip = getIp(req);
  const rl = await rateLimit(`studio:${ip}`, 3, 60 * 1000);
  if (!rl.ok) return NextResponse.json({ error: "rate_limited" }, { status: 429 });
  const body = (await req.json()) as { phone?: string; name?: string; note?: string };
  if (!body.phone) return NextResponse.json({ error: "phone_required" }, { status: 400 });
  await db.studioWaitlist.create({ data: { phone: body.phone, name: body.name, note: body.note } });
  return NextResponse.json({ ok: true });
}
