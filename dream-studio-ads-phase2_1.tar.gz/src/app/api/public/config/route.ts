// GET /api/public/config — runtime config the browser needs (no secrets).
// Firebase web config values are public by design (they identify the
// project; security comes from Authorized Domains + App Check).
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { env, authMode } from "@/lib/env";
import { storage } from "@/lib/storage";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.setting.findMany({ where: { key: { in: ["bkash_personal", "bkash_qr_key", "whatsapp_number"] } } });
  const s: Record<string, string> = {};
  for (const r of rows) s[r.key] = r.value;
  const mode = authMode();
  return NextResponse.json({
    authMode: mode,
    firebase: mode === "firebase" ? env.firebase : null,
    paymentMode: env.paymentMode,
    bkashNumber: s.bkash_personal || "",
    bkashQrUrl: s.bkash_qr_key ? await storage.signedUrl(s.bkash_qr_key, 24 * 3600).catch(() => null) : null,
    whatsappNumber: s.whatsapp_number || "",
    mock: env.mockMode,
  });
}
