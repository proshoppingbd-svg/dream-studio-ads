// GET /api/public/content — public home page data (products, samples, faqs, testimonials, settings)
import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// Only these settings are public — internal keys (heartbeat, test results,
// alert flags, prices) never leave the server.
const PUBLIC_SETTING_KEYS = ["whatsapp_number", "bkash_personal", "terms_text", "privacy_text", "refund_text", "launch_remaining"];

export async function GET() {
  const [products, samples, faqs, testimonials, settingsRows] = await Promise.all([
    db.product.findMany({ where: { active: true }, orderBy: { sortOrder: "asc" } }),
    db.sample.findMany({ where: { active: true }, orderBy: { sortOrder: "asc" } }),
    db.faq.findMany({ where: { active: true }, orderBy: { sortOrder: "asc" } }),
    db.testimonial.findMany({ where: { active: true }, orderBy: { sortOrder: "asc" } }),
    db.setting.findMany({ where: { key: { in: PUBLIC_SETTING_KEYS } } }),
  ]);
  const settings: Record<string, string> = {};
  for (const r of settingsRows) settings[r.key] = r.value;
  return NextResponse.json({ products, samples, faqs, testimonials, settings });
}
