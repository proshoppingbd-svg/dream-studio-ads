// GET  /api/admin/test/wan — latest "Test Wan" result (+ playable video URL)
// POST /api/admin/test/wan — queue a new test (runs in the worker, 1–6 min)
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";
import { resolveVideoUrl } from "@/lib/orders";

export async function GET() {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const row = await db.setting.findUnique({ where: { key: "test_wan_result" } });
  let result: any = null;
  try { result = row ? JSON.parse(row.value) : null; } catch { /* ignore */ }
  const queued = (await db.job.count({ where: { type: "test_wan", status: { in: ["QUEUED", "RUNNING"] } } })) > 0;
  const videoUrl = result?.videoKey ? await resolveVideoUrl(result.videoKey).catch(() => null) : null;
  return NextResponse.json({ result, queued, videoUrl });
}

export async function POST() {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const busy = await db.job.count({ where: { type: "test_wan", status: { in: ["QUEUED", "RUNNING"] } } });
  if (busy) return NextResponse.json({ error: "already_running" }, { status: 409 });
  const queuedAt = JSON.stringify({ status: "QUEUED", at: new Date().toISOString() });
  await db.setting.upsert({ where: { key: "test_wan_result" }, update: { value: queuedAt }, create: { key: "test_wan_result", value: queuedAt } });
  await db.job.create({ data: { type: "test_wan", payloadJson: "{}", status: "QUEUED", maxAttempts: 1 } });
  return NextResponse.json({ ok: true });
}
