// POST /api/admin/test/ai — list models, run one photo moderation and one
// Bangla script from a sample brief. Shows raw output, time and cost.
import { NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";
import { getStaff } from "@/lib/auth";
import { env } from "@/lib/env";
import { aiService, logCost } from "@/lib/aiService";
import { listModels } from "@/lib/llm";

export const maxDuration = 120;

export async function POST() {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const out: Record<string, unknown> = { provider: env.llmProvider, mock: env.mockMode };

  try { out.models = env.mockMode ? ["(mock)"] : await listModels(); }
  catch (e) { out.models = { error: (e as Error).message }; }

  const img = await fs.readFile(path.join(process.cwd(), "public", "samples", "cosmetics.jpg"));
  let t = Date.now();
  const mod = await aiService.moderation("category=cosmetics; productName=Glow face cream; tone=premium", [{ mime: "image/jpeg", base64: img.toString("base64") }]);
  out.photoModeration = { ms: Date.now() - t, result: mod.result, parseFailed: mod.parseFailed, visionUsed: mod.visionUsed, error: mod.error, costUsd: mod.cost.usd };
  await logCost({ type: "llm_tokens", cost: { ...mod.cost, detail: `test ${mod.cost.detail}` } });

  t = Date.now();
  try {
    const sc = await aiService.generateScript(JSON.stringify({
      productName: "গ্লো ফেস ক্রিম", category: "cosmetics", tone: "premium", language: "Bangla",
      cta: "ইনবক্স করুন", targetCustomer: "২০-৩৫ বছরের নারী", priceOffer: "৳৫৫০, আজই ১০% ছাড়", photos: 3, isPremium: false,
    }));
    out.script = { ms: Date.now() - t, parseFailed: sc.parseFailed, costUsd: sc.cost.usd, script: sc.script };
    await logCost({ type: "llm_tokens", cost: { ...sc.cost, detail: `test ${sc.cost.detail}` } });
  } catch (e) {
    out.script = { ms: Date.now() - t, error: (e as Error).message };
  }
  return NextResponse.json(out);
}
