// GET /api/admin/qa — list orders flagged for random QA
// POST — mark QA decision
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";

export async function GET() {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const orders = await db.order.findMany({
    where: { qaFlag: true, status: "DELIVERED" },
    include: { product: true, operator: { select: { id: true, name: true, email: true, role: true } } },
    orderBy: { deliveredAt: "desc" },
  });
  return NextResponse.json({ orders });
}

export async function POST(req: Request) {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const body = (await req.json()) as { orderId?: string; note?: string; close?: boolean };
  if (!body.orderId) return NextResponse.json({ error: "orderId_required" }, { status: 400 });
  await db.order.update({
    where: { id: body.orderId },
    data: {
      qaFlag: false,
      qaNote: body.note || null,
      status: body.close ? "CLOSED" : undefined,
    },
  });
  return NextResponse.json({ ok: true });
}
