// GET/PUT /api/admin/products — list + edit products
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";

export async function GET() {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const products = await db.product.findMany({ orderBy: { sortOrder: "asc" } });
  return NextResponse.json({ products });
}

export async function PUT(req: Request) {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const body = (await req.json()) as { id?: string; priceBdt?: number; active?: boolean; name?: string; nameBn?: string; deliverySla?: string; revisions?: number };
  if (!body.id) return NextResponse.json({ error: "id_required" }, { status: 400 });
  const p = await db.product.update({
    where: { id: body.id },
    data: {
      ...(body.priceBdt !== undefined && { priceBdt: body.priceBdt }),
      ...(body.active !== undefined && { active: body.active }),
      ...(body.name !== undefined && { name: body.name }),
      ...(body.nameBn !== undefined && { nameBn: body.nameBn }),
      ...(body.deliverySla !== undefined && { deliverySla: body.deliverySla }),
      ...(body.revisions !== undefined && { revisions: body.revisions }),
    },
  });
  return NextResponse.json({ ok: true, product: p });
}
