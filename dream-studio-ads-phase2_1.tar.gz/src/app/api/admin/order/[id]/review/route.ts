// POST /api/admin/order/[id]/review — admin resolves a MANUAL_REVIEW order.
// Phase 1B Item 2 + Phase 1C Items 4 & 5:
//   "Approve and continue" → sets moderationOverride=true, resets to PAID,
//     and re-enqueues script generation. generate_script will SKIP
//     moderation because the admin already reviewed the product.
//   "Reject and refund" → marks REJECTED and sends the customer the proper
//     orderRejected refund SMS (no more text-replacement hack).
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";
import { enqueue } from "@/lib/queue";
import { smsTemplates } from "@/lib/sms";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }
  const { id } = await ctx.params;
  const body = (await req.json().catch(() => ({}))) as { action?: "approve" | "reject" };
  if (body.action !== "approve" && body.action !== "reject") {
    return NextResponse.json({ error: "action_required" }, { status: 400 });
  }
  const order = await db.order.findUnique({ where: { id }, include: { product: true } });
  if (!order) return NextResponse.json({ error: "not_found" }, { status: 404 });
  if (order.status !== "MANUAL_REVIEW") {
    return NextResponse.json({ error: "not_in_manual_review", current: order.status }, { status: 400 });
  }

  if (body.action === "approve") {
    // Item 4: set moderationOverride so the retry skips moderation.
    await db.order.update({ where: { id }, data: { status: "PAID", moderationOverride: true } });
    await enqueue("generate_script", { orderId: id });
    return NextResponse.json({ ok: true, status: "PAID", moderationOverride: true });
  }
  // Reject and refund — mark REJECTED; refund is manual in v1.
  await db.order.update({ where: { id }, data: { status: "REJECTED" } });
  // Item 5: send the proper Bangla refund SMS (no text-replacement hack).
  await enqueue("send_sms", {
    phone: order.customerPhone,
    message: smsTemplates.orderRejected(order.code),
  });
  return NextResponse.json({ ok: true, status: "REJECTED" });
}
