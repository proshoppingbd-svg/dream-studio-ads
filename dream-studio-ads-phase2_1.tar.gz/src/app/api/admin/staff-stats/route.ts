// GET /api/admin/staff-stats — operator performance
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";
import { isOverdue } from "@/lib/orders";

export async function GET() {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const operators = await db.staffUser.findMany({ where: { role: "operator" } });
  const stats = await Promise.all(
    operators.map(async (op) => {
      const orders = await db.order.findMany({
        where: { operatorId: op.id },
        include: { shots: true },
      });
      const done = orders.filter((o) => ["DELIVERED", "CLOSED"].includes(o.status));
      const onTime = done.filter((o) => o.deliveredAt && !isOverdue(o.slaDeadline));
      const totalRegens = orders.reduce((s, o) => s + o.shots.reduce((ss, sh) => ss + sh.regenCount, 0), 0);
      const totalShots = orders.reduce((s, o) => s + o.shots.length, 0);
      const qualityIssues = orders.filter((o) => o.qaNote).length;
      return {
        id: op.id,
        name: op.name,
        email: op.email,
        ordersDone: done.length,
        avgRegenPerShot: totalShots > 0 ? Math.round((totalRegens / totalShots) * 10) / 10 : 0,
        onTimePct: done.length > 0 ? Math.round((onTime.length / done.length) * 100) : 0,
        qualityIssues,
      };
    })
  );
  return NextResponse.json({ stats });
}
