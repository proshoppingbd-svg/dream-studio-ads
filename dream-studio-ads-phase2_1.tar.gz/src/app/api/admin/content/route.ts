// GET/POST/PUT/DELETE /api/admin/content — testimonials, faqs, samples
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";

export async function GET(req: Request) {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const url = new URL(req.url);
  const kind = url.searchParams.get("kind") || "all";
  const [testimonials, faqs, samples] = await Promise.all([
    db.testimonial.findMany({ orderBy: { sortOrder: "asc" } }),
    db.faq.findMany({ orderBy: { sortOrder: "asc" } }),
    db.sample.findMany({ orderBy: { sortOrder: "asc" } }),
  ]);
  return NextResponse.json({ testimonials, faqs, samples });
}

export async function POST(req: Request) {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const body = (await req.json()) as { kind: "testimonial" | "faq" | "sample"; data: Record<string, unknown> };
  let created;
  if (body.kind === "testimonial") created = await db.testimonial.create({ data: body.data as never });
  if (body.kind === "faq") created = await db.faq.create({ data: body.data as never });
  if (body.kind === "sample") created = await db.sample.create({ data: body.data as never });
  return NextResponse.json({ ok: true, created });
}

export async function PUT(req: Request) {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const body = (await req.json()) as { kind: "testimonial" | "faq" | "sample"; id: string; data: Record<string, unknown> };
  let updated;
  if (body.kind === "testimonial") updated = await db.testimonial.update({ where: { id: body.id }, data: body.data as never });
  if (body.kind === "faq") updated = await db.faq.update({ where: { id: body.id }, data: body.data as never });
  if (body.kind === "sample") updated = await db.sample.update({ where: { id: body.id }, data: body.data as never });
  return NextResponse.json({ ok: true, updated });
}

export async function DELETE(req: Request) {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const url = new URL(req.url);
  const kind = url.searchParams.get("kind");
  const id = url.searchParams.get("id");
  if (!kind || !id) return NextResponse.json({ error: "missing" }, { status: 400 });
  if (kind === "testimonial") await db.testimonial.delete({ where: { id } });
  if (kind === "faq") await db.faq.delete({ where: { id } });
  if (kind === "sample") await db.sample.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
