// GET /api/admin/costs — cost report per order + totals
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";

export async function GET() {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const orders = await db.order.findMany({
    where: { status: { notIn: ["PENDING_PAYMENT", "REJECTED"] } },
    include: { product: true, costLogs: true, shots: true },
    orderBy: { createdAt: "desc" },
  });
  const rows = orders.map((o) => {
    const costUsd = o.costLogs.reduce((s, c) => s + c.usdCost, 0);
    const costBdt = o.costLogs.reduce((s, c) => s + c.bdtCost, 0);
    const regenCount = o.shots.reduce((s, sh) => s + sh.regenCount, 0);
    const revenue = o.product.priceBdt;
    const margin = revenue - costBdt;
    const marginPct = revenue > 0 ? Math.round((margin / revenue) * 100) : 0;
    return {
      id: o.id,
      code: o.code,
      status: o.status,
      revenue,
      costUsd: Math.round(costUsd * 10000) / 10000,
      costBdt: Math.round(costBdt),
      margin,
      marginPct,
      regenCount,
      createdAt: o.createdAt,
    };
  });
  const totalRevenue = rows.reduce((s, r) => s + r.revenue, 0);
  const totalCostBdt = rows.reduce((s, r) => s + r.costBdt, 0);
  const totalCostUsd = rows.reduce((s, r) => s + r.costUsd, 0);
  return NextResponse.json({
    rows,
    totals: {
      orders: rows.length,
      revenue: totalRevenue,
      costBdt: totalCostBdt,
      costUsd: Math.round(totalCostUsd * 10000) / 10000,
      margin: totalRevenue - totalCostBdt,
      marginPct: totalRevenue > 0 ? Math.round(((totalRevenue - totalCostBdt) / totalRevenue) * 100) : 0,
    },
  });
}
