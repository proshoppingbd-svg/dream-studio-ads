// GET /api/admin/payments — payments waiting for the admin's bKash check.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";
import { storage } from "@/lib/storage";

export async function GET() {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const payments = await db.payment.findMany({
    where: { status: "SUBMITTED" },
    include: { order: { include: { product: true } } },
    orderBy: { submittedAt: "asc" },
    take: 200,
  });
  const rows = await Promise.all(
    payments.map(async (p) => ({
      id: p.id,
      orderId: p.orderId,
      orderCode: p.order.code,
      product: p.order.product.name,
      customerPhone: p.order.customerPhone,
      amountDue: p.order.product.priceBdt,
      amountEntered: p.amountEntered,
      trxId: p.trxId,
      senderNumber: p.senderNumber,
      submittedAt: p.submittedAt,
      screenshotUrl: p.screenshotKey ? await storage.signedUrl(p.screenshotKey, 3600) : null,
    }))
  );
  return NextResponse.json({ payments: rows, count: rows.length });
}
