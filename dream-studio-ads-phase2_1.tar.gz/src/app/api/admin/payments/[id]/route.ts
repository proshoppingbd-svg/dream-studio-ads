// POST /api/admin/payments/[id] — { action: "confirm" } or { action: "reject", reason }
// Confirm → order PAID (script generation starts). Reject → order back to
// PENDING_PAYMENT; the customer sees the reason and can submit again.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";
import { markOrderPaid } from "@/lib/payments";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const { id } = await ctx.params;
  const body = (await req.json().catch(() => ({}))) as { action?: string; reason?: string };
  const payment = await db.payment.findUnique({ where: { id }, include: { order: { include: { product: true } } } });
  if (!payment) return NextResponse.json({ error: "not_found" }, { status: 404 });
  if (payment.status !== "SUBMITTED") return NextResponse.json({ error: "not_submitted", current: payment.status }, { status: 400 });

  if (body.action === "confirm") {
    await db.payment.update({
      where: { id },
      data: { manualNote: `Confirmed by ${staff.email} at ${new Date().toISOString()}` },
    });
    const r = await markOrderPaid({ orderId: payment.orderId, fromStatuses: ["PAYMENT_SUBMITTED"], paymentId: id });
    if (!r.ok) return NextResponse.json({ error: r.error }, { status: 400 });
    return NextResponse.json({ ok: true, status: "PAID" });
  }

  if (body.action === "reject") {
    const reason = (body.reason || "").trim().slice(0, 300);
    if (!reason) return NextResponse.json({ error: "reason_required" }, { status: 400 });
    const done = await db.$transaction(async (tx) => {
      const moved = await tx.order.updateMany({ where: { id: payment.orderId, status: "PAYMENT_SUBMITTED" }, data: { status: "PENDING_PAYMENT" } });
      if (moved.count !== 1) return false;
      await tx.payment.update({ where: { id }, data: { status: "REJECTED", rejectReason: reason, manualNote: `Rejected by ${staff.email}` } });
      await tx.payment.create({ data: { orderId: payment.orderId, provider: "manual_qr", amount: payment.order.product.priceBdt, status: "PENDING" } });
      return true;
    });
    if (!done) return NextResponse.json({ error: "wrong_status" }, { status: 400 });
    return NextResponse.json({ ok: true, status: "PENDING_PAYMENT" });
  }
  return NextResponse.json({ error: "action_required" }, { status: 400 });
}
