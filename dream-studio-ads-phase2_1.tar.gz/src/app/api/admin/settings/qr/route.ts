// POST /api/admin/settings/qr — upload the bKash QR image (multipart "file").
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";
import { storage, generateStorageKey } from "@/lib/storage";

export async function POST(req: Request) {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const form = await req.formData();
  const file = form.get("file") as File | null;
  if (!file || !file.type.startsWith("image/")) return NextResponse.json({ error: "image_required" }, { status: 400 });
  if (file.size > 5 * 1024 * 1024) return NextResponse.json({ error: "too_large" }, { status: 400 });
  const ext = file.type.split("/")[1] === "jpeg" ? "jpg" : file.type.split("/")[1] || "png";
  const saved = await storage.save(Buffer.from(await file.arrayBuffer()), generateStorageKey("settings", `bkash-qr.${ext}`), file.type);
  await db.setting.upsert({ where: { key: "bkash_qr_key" }, update: { value: saved.key }, create: { key: "bkash_qr_key", value: saved.key } });
  return NextResponse.json({ ok: true, url: await storage.signedUrl(saved.key, 3600) });
}
