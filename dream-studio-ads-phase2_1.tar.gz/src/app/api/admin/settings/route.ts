// GET/PUT /api/admin/settings
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";

export async function GET() {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const rows = await db.setting.findMany();
  const settings: Record<string, string> = {};
  for (const r of rows) settings[r.key] = r.value;
  return NextResponse.json({ settings });
}

export async function PUT(req: Request) {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const body = (await req.json()) as Record<string, string>;
  const INTERNAL = /^(worker_heartbeat|test_|alert:|daily_|bkash_qr_key$)/;
  for (const [k, v] of Object.entries(body)) {
    if (INTERNAL.test(k) || typeof v !== "string") continue;
    await db.setting.upsert({
      where: { key: k },
      update: { value: v },
      create: { key: k, value: v },
    });
  }
  return NextResponse.json({ ok: true });
}
