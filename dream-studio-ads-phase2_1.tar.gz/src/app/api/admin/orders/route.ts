// GET /api/admin/orders — admin: every order in any status, with phone,
// product, payments, costs and operator. Used on the admin Orders tab so
// "Mark paid" works for PENDING_PAYMENT orders too.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff } from "@/lib/auth";
import { isOverdue } from "@/lib/status";

export async function GET() {
  const staff = await getStaff();
  if (!staff || staff.role !== "admin") {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }
  const orders = await db.order.findMany({
    include: { product: true, payments: true, costLogs: true, operator: { select: { id: true, name: true, email: true, role: true } }, revisions: true },
    orderBy: { createdAt: "desc" },
  });
  const rows = orders.map((o) => {
    const costBdt = o.costLogs.reduce((s, c) => s + c.bdtCost, 0);
    const regenCount = 0; // shots not included here for perf; admin/costs has it
    return {
      id: o.id,
      code: o.code,
      status: o.status,
      customerPhone: o.customerPhone,
      customerName: o.customerName,
      product: o.product,
      revenue: o.product.priceBdt,
      costBdt: Math.round(costBdt),
      margin: o.product.priceBdt - Math.round(costBdt),
      regenCount,
      operator: o.operator,
      slaDeadline: o.slaDeadline,
      overdue: isOverdue(o.slaDeadline),
      paidAt: o.paidAt,
      deliveredAt: o.deliveredAt,
      qaFlag: o.qaFlag,
      qaNote: o.qaNote,
      latestRevisionNote: o.revisions[0]?.note || null,
      createdAt: o.createdAt,
    };
  });
  return NextResponse.json({ orders: rows });
}
