// /api/admin/staff — admin manages staff accounts.
//   GET                          → list
//   POST { email, name, role, password }  → create (or reset password if the email exists)
//   DELETE ?id=                  → remove (cannot remove yourself)
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getStaff, hashPassword } from "@/lib/auth";

const ROLES = ["operator", "editor", "admin"];

export async function GET() {
  const me = await getStaff();
  if (!me || me.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const staff = await db.staffUser.findMany({ select: { id: true, email: true, name: true, role: true, createdAt: true }, orderBy: { createdAt: "asc" } });
  return NextResponse.json({ staff });
}

export async function POST(req: Request) {
  const me = await getStaff();
  if (!me || me.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const b = (await req.json().catch(() => ({}))) as { email?: string; name?: string; role?: string; password?: string };
  const email = (b.email || "").trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return NextResponse.json({ error: "bad_email" }, { status: 400 });
  if (!b.password || b.password.length < 10) return NextResponse.json({ error: "password_min_10" }, { status: 400 });
  const role = ROLES.includes(b.role || "") ? b.role! : "operator";
  const user = await db.staffUser.upsert({
    where: { email },
    update: { passwordHash: hashPassword(b.password), ...(b.name ? { name: b.name } : {}), role },
    create: { email, name: b.name || email.split("@")[0]!, role, passwordHash: hashPassword(b.password) },
    select: { id: true, email: true, name: true, role: true },
  });
  return NextResponse.json({ ok: true, staff: user });
}

export async function DELETE(req: Request) {
  const me = await getStaff();
  if (!me || me.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const id = new URL(req.url).searchParams.get("id") || "";
  if (id === me.id) return NextResponse.json({ error: "cannot_delete_self" }, { status: 400 });
  await db.order.updateMany({ where: { operatorId: id }, data: { operatorId: null } });
  await db.staffUser.delete({ where: { id } }).catch(() => null);
  return NextResponse.json({ ok: true });
}
