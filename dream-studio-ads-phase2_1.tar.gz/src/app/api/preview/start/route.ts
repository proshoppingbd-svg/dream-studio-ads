// POST /api/preview/start — request OTP for free preview OR account login
// Body: { phone, category?, purpose? }  (purpose: "preview" default | "login")
// Item 5: never return debug_otp in production (even when MOCK_MODE is on).
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { createOtp } from "@/lib/auth";
import { rateLimit, getIp } from "@/lib/rateLimit";
import { env, authMode } from "@/lib/env";
import { smsTemplates, sendSms } from "@/lib/sms";

export async function POST(req: Request) {
  const ip = getIp(req);
  const rl = await rateLimit(`otp-start:${ip}`, 10, 60 * 1000);
  if (!rl.ok) return NextResponse.json({ error: "rate_limited" }, { status: 429 });

  const body = (await req.json()) as { phone?: string; category?: string; purpose?: string; precheck?: boolean };
  const phone = (body.phone || "").replace(/\s+/g, "");
  if (!/^01[3-9]\d{8}$/.test(phone.replace(/^\+880/, "0"))) {
    return NextResponse.json({ error: "invalid_phone" }, { status: 400 });
  }
  const purpose = body.purpose === "login" ? "login" : "preview";

  if (purpose === "preview") {
    if (!body.category) return NextResponse.json({ error: "category_required" }, { status: 400 });

    // 1 free preview per phone, ever (a FAILED preview allows a retry,
    // but we don't enforce that here — it's enforced inside /generate's
    // transaction so the OTP can be requested first).
    const existing = await db.preview.findFirst({
      where: { customerPhone: phone },
      orderBy: { createdAt: "desc" },
    });
    if (existing && existing.status !== "FAILED") {
      return NextResponse.json({ error: "already_used_preview" }, { status: 409 });
    }

    // 3 per IP per day
    const dayStart = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const ipCount = await db.preview.count({ where: { customerIp: ip, createdAt: { gte: dayStart } } });
    if (ipCount >= 3) {
      return NextResponse.json({ error: "ip_limit" }, { status: 429 });
    }

    // site-wide daily cap
    const todayCount = await db.preview.count({ where: { createdAt: { gte: dayStart } } });
    if (todayCount >= env.previewDailyCap) {
      return NextResponse.json({ error: "daily_cap" }, { status: 429 });
    }
  }

  // ensure customer exists before OTP (FK constraint)
  await db.customer.upsert({ where: { phone }, update: {}, create: { phone } });

  // Phase 2: with Firebase Phone Auth the browser sends the SMS itself.
  // This call is then only the limits pre-check (no code is created here).
  if (body.precheck || authMode() === "firebase") {
    return NextResponse.json({ ok: true, authMode: authMode() });
  }

  const otp = await createOtp(phone, purpose);
  // In mock dev, we don't send SMS — return the code so the developer can
  // paste it. In production we always send via the SMS adapter, even in mock
  // mode (so MOCK_MODE=true in prod is still safe — there's just no real
  // number to text, so the mock SMS adapter logs to stdout).
  if (!env.mockMode || env.isProd) {
    await sendSms(phone, smsTemplates.otp(otp.code));
  }

  return NextResponse.json({
    ok: true,
    // Item 5: only expose the code in non-production mock mode.
    debug_otp: env.mockMode && !env.isProd ? otp.code : undefined,
  });
}
