// POST /api/preview/generate — kick off a preview generation.
// Item 3 (Phase 1): requires the signed token from /api/preview/verify;
//   phone comes ONLY from the token; re-checks IP + daily-cap limits.
// Phase 1B Item 4: the "1 preview per phone ever" limit is now a DB-level
//   atomic claim on Customer.previewUsed, with a one-time reset (tracked
//   by Customer.previewRetryUsed) granted on a moderation rejection or a
//   generation failure.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { env } from "@/lib/env";
import { storage, generateStorageKey } from "@/lib/storage";
import { aiService, logCost } from "@/lib/aiService";
import { rateLimit, getIp } from "@/lib/rateLimit";
import { enqueue } from "@/lib/queue";
import { readCustomerToken } from "@/lib/auth";

export async function POST(req: Request) {
  const ip = getIp(req);

  // require a valid customer token; phone comes ONLY from it.
  const body = (await req.json().catch(() => ({}))) as {
    token?: string;
    category?: string;
    photo?: string;
    promptText?: string;
  };
  if (!body.token) return NextResponse.json({ error: "token_required" }, { status: 401 });
  const session = readCustomerToken(body.token);
  if (!session) return NextResponse.json({ error: "invalid_token" }, { status: 401 });
  const phone = session.phone;

  const rl = await rateLimit(`preview-gen:${ip}`, 5, 60 * 1000);
  if (!rl.ok) return NextResponse.json({ error: "rate_limited" }, { status: 429 });

  if (!body.category) return NextResponse.json({ error: "category_required" }, { status: 400 });
  if (!body.photo || !body.photo.startsWith("data:")) {
    return NextResponse.json({ error: "photo_required" }, { status: 400 });
  }

  // ── Item 4: claim previewUsed atomically + re-check IP/daily limits ──
  const result = await db.$transaction(async (tx) => {
    // Phase 1B Item 4: atomic DB-level claim of the one-per-phone slot.
    // updateMany returns count === 1 only when previewUsed was false; this
    // is race-safe across concurrent requests and multiple instances.
    const claim = await tx.customer.updateMany({
      where: { phone, previewUsed: false },
      data: { previewUsed: true },
    });
    if (claim.count !== 1) {
      return { error: "already_used_preview" as const };
    }

    // 3 per IP per day.
    const dayStart = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const ipCount = await tx.preview.count({
      where: { customerIp: ip, createdAt: { gte: dayStart } },
    });
    if (ipCount >= 3) {
      // release the claim so the customer isn't penalised for an IP limit
      await tx.customer.update({ where: { phone }, data: { previewUsed: false } });
      return { error: "ip_limit" as const };
    }

    // PREVIEW_DAILY_CAP per calendar day in Asia/Dhaka.
    const dayBoundary = dhakaStartOfTodayUtcMs();
    const todayCount = await tx.preview.count({
      where: { createdAt: { gte: new Date(dayBoundary) } },
    });
    if (todayCount >= env.previewDailyCap) {
      await tx.customer.update({ where: { phone }, data: { previewUsed: false } });
      return { error: "daily_cap" as const };
    }
    return { ok: true as const };
  });

  if ("error" in result) {
    const status = result.error === "already_used_preview" ? 409 : 429;
    return NextResponse.json({ error: result.error }, { status });
  }

  // save the photo (cuid-based key — no phone number in the path)
  const m = body.photo!.match(/^data:(image\/(\w+));base64,(.+)$/);
  if (!m) {
    // release the claim on bad input
    await db.customer.update({ where: { phone }, data: { previewUsed: false } });
    return NextResponse.json({ error: "bad_photo" }, { status: 400 });
  }
  const ext = m[2] === "jpeg" ? "jpg" : m[2];
  const buf = Buffer.from(m[3]!, "base64");
  let key: string;
  try {
    key = (await storage.save(buf, generateStorageKey("preview", ext!), m[1]!)).key;
  } catch (e) {
    console.error("[preview] storage save failed", e);
    await db.customer.update({ where: { phone }, data: { previewUsed: false } });
    return NextResponse.json({ error: "generation_failed" }, { status: 500 });
  }
  const photoUrl = key;

  // moderation on category + any prompt text + the photo itself (vision)
  const modInput = `category=${body.category}; user_text=${body.promptText || ""}`;
  const modOut = await aiService.moderation(modInput, [{ mime: m[1]!, base64: m[3]! }]);
  const { result: mod, cost: modCost, parseFailed: modParseFailed } = modOut;
  if (modOut.error && !mod) {
    // The safety AI itself was unreachable — not the customer's fault.
    console.error("[preview] moderation call failed:", modOut.error);
    await db.customer.update({ where: { phone }, data: { previewUsed: false } });
    return NextResponse.json({ error: "generation_failed" }, { status: 503 });
  }
  await logCost({ type: "llm_tokens", cost: modCost });

  // Item 15 + Phase 1B Item 4: a moderation rejection OR a parse failure
  // grants the customer exactly one reset (previewUsed → false), tracked
  // by previewRetryUsed. Only the first rejection/reset gets a retry.
  if (modParseFailed || !mod || !mod.allowed) {
    const reason = mod?.reason_bn || "আপনার পণ্য গ্রহণযোগ্য নয়। সাপোর্টে যোগাযোগ করুন।";
    const preview = await db.preview.create({
      data: {
        customerPhone: phone,
        customerIp: ip,
        category: body.category || "other",
        photoPath: key,
        status: "FAILED",
        moderationJson: JSON.stringify({ allowed: false, reason_bn: reason, category: modParseFailed ? "parse_failed" : (mod?.category || "unknown") }),
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      },
    });
    // Phase 1B Item 4: reset previewUsed once (only if no retry used yet).
    await grantPreviewRetry(phone);
    return NextResponse.json({ error: "rejected", reason, previewId: preview.id }, { status: 403 });
  }

  // preview prompt
  const briefText = `category=${body.category}; product=${body.promptText || "product"}; tone=premium; language=Bangla`;
  let promptOut: Awaited<ReturnType<typeof aiService.previewPrompt>>;
  try {
    promptOut = await aiService.previewPrompt(briefText);
  } catch (e) {
    console.error("[preview] prompt generation failed", e);
    await grantPreviewRetry(phone);
    return NextResponse.json({ error: "generation_failed" }, { status: 500 });
  }
  const { result: promptRes, cost: promptCost, parseFailed: promptParseFailed } = promptOut;
  await logCost({ type: "llm_tokens", cost: promptCost });
  if (promptParseFailed || !promptRes) {
    // generation failed — grant one retry
    await grantPreviewRetry(phone);
    return NextResponse.json({ error: "generation_failed" }, { status: 500 });
  }

  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  const preview = await db.preview.create({
    data: {
      customerPhone: phone,
      customerIp: ip,
      category: body.category || "other",
      photoPath: key,
      status: "GENERATING",
      promptJson: JSON.stringify({ prompt: promptRes.prompt, negative_prompt: promptRes.negative_prompt, photoUrl }),
      moderationJson: JSON.stringify(mod),
      costUsd: modCost.usd + promptCost.usd,
      expiresAt,
    },
  });

  await enqueue("run_preview", {
    previewId: preview.id,
    photoUrl,
    prompt: promptRes.prompt,
    negativePrompt: promptRes.negative_prompt,
  });

  return NextResponse.json({ ok: true, previewId: preview.id });
}

// Phase 1B Item 4: grant a one-time retry by resetting previewUsed to
// false, but only if previewRetryUsed === 0. Atomically claims the retry
// slot with updateMany so concurrent requests can't double-grant.
async function grantPreviewRetry(phone: string): Promise<void> {
  await db.customer.updateMany({
    where: { phone, previewRetryUsed: 0, previewUsed: true },
    data: { previewUsed: false, previewRetryUsed: 1 },
  });
}

// ── Asia/Dhaka "start of today" in UTC ms ──────────────────────
function dhakaStartOfTodayUtcMs(): number {
  const now = new Date();
  const dhaka = new Date(now.getTime() + 6 * 60 * 60 * 1000);
  const midnight = new Date(dhaka);
  midnight.setUTCHours(0, 0, 0, 0);
  return midnight.getTime() - 6 * 60 * 60 * 1000;
}
