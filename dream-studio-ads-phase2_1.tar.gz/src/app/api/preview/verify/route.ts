// POST /api/preview/verify — verify OTP, return a signed customer token
// Item 5: never return debug_otp in production.
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyOtp, issueCustomerToken } from "@/lib/auth";
import { rateLimit, getIp } from "@/lib/rateLimit";
import { env, authMode } from "@/lib/env";

export async function POST(req: Request) {
  const ip = getIp(req);
  const rl = await rateLimit(`preview-verify:${ip}`, 20, 60 * 1000);
  if (!rl.ok) return NextResponse.json({ error: "rate_limited" }, { status: 429 });

  // With Firebase login enabled, codes are verified by Firebase (/api/auth/firebase).
  if (authMode() === "firebase") return NextResponse.json({ error: "use_firebase" }, { status: 400 });

  const body = (await req.json()) as { phone?: string; code?: string; purpose?: string };
  const phone = (body.phone || "").replace(/\s+/g, "");
  const code = (body.code || "").trim();
  if (!phone || !code) return NextResponse.json({ error: "missing" }, { status: 400 });
  const purpose = body.purpose === "login" ? "login" : "preview";

  const res = await verifyOtp(phone, code, purpose);
  if (!res.ok) return NextResponse.json({ error: res.reason }, { status: 401 });

  await db.customer.upsert({ where: { phone }, update: {}, create: { phone } });

  // Item 3 + 4: issue a namespaced customer token. The phone is bound into
  // the token so /generate can never trust a body-supplied phone.
  const token = issueCustomerToken(phone);
  return NextResponse.json({ ok: true, token, mock: env.mockMode && !env.isProd });
}
