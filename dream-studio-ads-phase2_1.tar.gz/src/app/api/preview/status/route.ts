// GET /api/preview/status?id=xxx — poll preview status
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { resolveVideoUrl } from "@/lib/orders";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id_required" }, { status: 400 });
  const preview = await db.preview.findUnique({ where: { id } });
  if (!preview) return NextResponse.json({ error: "not_found" }, { status: 404 });
  const videoUrl = await resolveVideoUrl(preview.videoUrl);
  return NextResponse.json({
    status: preview.status,
    videoUrl,
    photoPath: preview.photoPath,
    costUsd: preview.costUsd,
  });
}
