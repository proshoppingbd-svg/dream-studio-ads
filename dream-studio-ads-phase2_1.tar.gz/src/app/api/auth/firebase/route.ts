// POST /api/auth/firebase — exchange a Firebase phone-login ID token for our
// own customer token. Body: { idToken }
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { issueCustomerToken } from "@/lib/auth";
import { rateLimit, getIp } from "@/lib/rateLimit";
import { verifyFirebasePhoneToken } from "@/lib/firebaseVerify";
import { authMode } from "@/lib/env";

export async function POST(req: Request) {
  if (authMode() !== "firebase") return NextResponse.json({ error: "firebase_disabled" }, { status: 400 });
  const ip = getIp(req);
  const rl = await rateLimit(`fb-auth:${ip}`, 20, 60 * 1000);
  if (!rl.ok) return NextResponse.json({ error: "rate_limited" }, { status: 429 });
  const body = (await req.json().catch(() => ({}))) as { idToken?: string };
  if (!body.idToken) return NextResponse.json({ error: "missing" }, { status: 400 });
  const r = await verifyFirebasePhoneToken(body.idToken);
  if ("error" in r) return NextResponse.json({ error: r.error }, { status: 401 });
  await db.customer.upsert({ where: { phone: r.phone }, update: {}, create: { phone: r.phone } });
  return NextResponse.json({ ok: true, token: issueCustomerToken(r.phone), phone: r.phone });
}
