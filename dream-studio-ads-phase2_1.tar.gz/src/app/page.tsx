"use client";
// src/app/page.tsx — SPA shell with hash routing (only user-facing route)
import { useEffect, useState } from "react";
import { useHashRoute, parseRoute, readHashQuery } from "@/hooks/use-hash-route";
import { api } from "@/hooks/use-api";
import { SiteHeader, SiteFooter, WhatsAppFloat } from "@/components/chrome";
import { HomeView } from "@/components/views/home";
import { PreviewView } from "@/components/views/preview";
import { OrderView } from "@/components/views/order";
import { AccountView } from "@/components/views/account";
import { OrderDetailView } from "@/components/views/order-detail";
import { LegalView } from "@/components/views/legal";
import { StudioView } from "@/components/views/studio";
import { StaffView } from "@/components/views/staff";
import { Button } from "@/components/ui/button";

export default function Home() {
  const { route, navigate } = useHashRoute();
  const parsed = parseRoute(route);
  const query = readHashQuery(route);
  const [settings, setSettings] = useState<Record<string, string>>({});

  useEffect(() => {
    api<{ settings: Record<string, string> }>("/api/public/content")
      .then((d) => setSettings(d.settings || {}))
      .catch(() => {});
  }, []);

  // scroll to top on route change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  }, [parsed.name]);

  const isStaff = parsed.name === "staff";

  return (
    <div className="flex min-h-screen flex-col">
      {!isStaff && <SiteHeader settings={settings} navigate={navigate} />}
      <main className="flex-1">
        {parsed.name === "home" && <HomeView navigate={navigate} />}
        {parsed.name === "preview" && <PreviewView navigate={navigate} />}
        {parsed.name === "order" && (
          <OrderView productCode={parsed.params.productCode} navigate={navigate} />
        )}
        {parsed.name === "account" && <AccountView navigate={navigate} />}
        {parsed.name === "orderDetail" && (
          <OrderDetailView id={parsed.params.id} navigate={navigate} query={query} />
        )}
        {parsed.name === "terms" && <LegalView kind="terms" settings={settings} />}
        {parsed.name === "privacy" && <LegalView kind="privacy" settings={settings} />}
        {parsed.name === "refund" && <LegalView kind="refund" settings={settings} />}
        {parsed.name === "studio" && <StudioView navigate={navigate} />}
        {parsed.name === "staff" && <StaffView navigate={navigate} />}
        {parsed.name === "notfound" && (
          <div className="mx-auto max-w-md px-4 py-20 text-center">
            <h1 className="text-2xl font-bold">৪০৪</h1>
            <p className="mt-2 text-sm text-muted-foreground">পেজ খুঁজে পাওয়া গেল না।</p>
            <Button className="mt-4" onClick={() => navigate("#/")}>হোমে ফিরুন</Button>
          </div>
        )}
      </main>
      {!isStaff && <SiteFooter settings={settings} navigate={navigate} />}
      {!isStaff && <WhatsAppFloat number={settings.whatsapp_number} />}
    </div>
  );
}
