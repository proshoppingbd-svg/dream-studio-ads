import type { Metadata } from "next";
import { Geist, Hind_Siliguri } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const hindSiliguri = Hind_Siliguri({
  variable: "--font-bangla",
  subsets: ["bengali", "latin"],
  weight: ["300", "400", "500", "600", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Dream Studio Ads — আপনার পণ্যের ৩০ সেকেন্ডের বাংলা ভিডিও বিজ্ঞাপন",
  description:
    "শুটিং ছাড়া, মডেল ছাড়া — AI দিয়ে আপনার পণ্যের ৩০ সেকেন্ডের বাংলা ভিডিও বিজ্ঞাপন। ফ্রি প্রিভিউ দেখুন, bKash এ পেমেন্ট করুন, ৪৮ ঘন্টায় ডেলিভারি পান।",
  keywords: [
    "Dream Studio",
    "Digital Sign Bangladesh",
    "AI video ad",
    "bKash",
    "Facebook sellers Bangladesh",
    "বাংলা বিজ্ঞাপন",
    "video ad Bangladesh",
  ],
  authors: [{ name: "Digital Sign Bangladesh" }],
  openGraph: {
    title: "Dream Studio Ads",
    description: "আপনার পণ্যের ৩০ সেকেন্ডের বাংলা ভিডিও বিজ্ঞাপন — ফ্রি প্রিভিউ দেখুন",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Dream Studio Ads",
    description: "আপনার পণ্যের ৩০ সেকেন্ডের বাংলা ভিডিও বিজ্ঞাপন",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="bn" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${hindSiliguri.variable} bangla antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster richColors position="top-center" />
      </body>
    </html>
  );
}
