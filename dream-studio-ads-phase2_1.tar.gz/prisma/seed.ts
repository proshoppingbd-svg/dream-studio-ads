// prisma/seed.ts — seed admin, staff, products, samples, faqs, testimonials.
// Item 19: seed only when the database is empty (idempotent + safe on Railway).
// Item 19: admin email + password from env, with NO default password in production.
import { PrismaClient } from "@prisma/client";
import { hashPassword } from "../src/lib/crypto";
import { env } from "../src/lib/env";

const prisma = new PrismaClient();

async function main() {
  // Item 19: seed only when empty. If staff already exist, skip.
  const existingStaff = await prisma.staffUser.count();
  if (existingStaff > 0) {
    console.log("✅ Database already has staff — skipping seed.");
    return;
  }

  // Item 19: refuse to seed a default admin password in production.
  if (env.isProd && !process.env.ADMIN_PASSWORD) {
    throw new Error(
      "FATAL: ADMIN_PASSWORD env var is required to seed the admin user in production."
    );
  }

  // ── Settings ──────────────────────────────────────────────
  const settings: Record<string, string> = {
    // Contact + payment numbers are set by the admin (Settings tab) in production.
    whatsapp_number: env.isProd ? "" : "+8801700000000",
    bkash_personal: env.isProd ? "" : "01700000000",
    launch_remaining: "10",
    usd_to_bdt: String(env.usdToBdt),
    wan_cost_per_sec_usd: "0.05",
    terms_text:
      "Dream Studio Ads এর শর্তাবলী (placeholder — admin থেকে এডিট করুন)।",
    privacy_text:
      "আপনার ডাটা নিরাপদ (placeholder — admin থেকে এডিট করুন)।",
    refund_text:
      "রিফান্ড পলিসি (placeholder — admin থেকে এডিট করুন)।",
  };
  for (const [k, v] of Object.entries(settings)) {
    await prisma.setting.upsert({
      where: { key: k },
      update: {},
      create: { key: k, value: v },
    });
  }

  // ── Staff ─────────────────────────────────────────────────
  await prisma.staffUser.upsert({
    where: { email: env.adminEmail },
    update: {},
    create: {
      email: env.adminEmail,
      name: "Site Admin",
      role: "admin",
      passwordHash: hashPassword(env.adminPassword),
    },
  });
  // Demo operator/editor accounts exist only in local/dev databases.
  // In production the admin adds real staff from Admin → Settings → Staff.
  if (!env.isProd) {
  await prisma.staffUser.upsert({
    where: { email: "operator@dreamstudio.bd" },
    update: {},
    create: {
      email: "operator@dreamstudio.bd",
      name: "Operator One",
      role: "operator",
      passwordHash: hashPassword("operator12345"),
    },
  });
  await prisma.staffUser.upsert({
    where: { email: "editor@dreamstudio.bd" },
    update: {},
    create: {
      email: "editor@dreamstudio.bd",
      name: "Editor One",
      role: "editor",
      passwordHash: hashPassword("editor12345"),
    },
  });
  }

  // ── Products ──────────────────────────────────────────────
  const products = [
    { code: "PREVIEW", name: "Free Preview", nameBn: "ফ্রি প্রিভিউ", priceBdt: 0, revisions: 0, deliverySla: "1 min", active: true, sortOrder: 0, description: "Free 1-minute preview of your product." },
    { code: "EXPRESS", name: "Express Ad", nameBn: "এক্সপ্রেস বিজ্ঞাপন", priceBdt: 1499, revisions: 1, deliverySla: "same day", active: false, sortOrder: 1, description: "Same-day 30s ad. Coming soon." },
    { code: "STANDARD", name: "Standard Ad", nameBn: "স্ট্যান্ডার্ড বিজ্ঞাপন", priceBdt: 2999, revisions: 1, deliverySla: "48 h", active: true, sortOrder: 2, description: "30-second Bangla ad delivered in 48 hours." },
    { code: "PREMIUM", name: "Premium Ad (30s + 15s cut)", nameBn: "প্রিমিয়াম বিজ্ঞাপন (৩০সে + ১৫সে)", priceBdt: 4999, revisions: 2, deliverySla: "72 h", active: true, sortOrder: 3, description: "30s ad plus a 15s cut for stories." },
    { code: "MONTHLY", name: "Monthly Seller Plan (4 Standard ads)", nameBn: "মান্থলি প্ল্যান (৪টি স্ট্যান্ডার্ড)", priceBdt: 9999, revisions: 1, deliverySla: "48 h", active: true, sortOrder: 4, description: "4 Standard ads per month, manual renewal." },
    { code: "LAUNCH", name: "Launch price for first 10 customers", nameBn: "লঞ্চ প্রাইস (প্রথম ১০ জন)", priceBdt: 1999, revisions: 1, deliverySla: "48 h", active: true, sortOrder: 5, description: "Special launch price, auto-disables after 10 paid orders." },
  ];
  for (const p of products) {
    await prisma.product.upsert({
      where: { code: p.code },
      update: {},
      create: p,
    });
  }

  // ── Samples (placeholder videos) ─────────────────────────
  const samples = [
    { title: "Saree collection", category: "clothing", videoUrl: "/samples/saree.mp4", posterUrl: "/samples/saree.jpg" },
    { title: "Lipstick launch", category: "cosmetics", videoUrl: "/samples/cosmetics.mp4", posterUrl: "/samples/cosmetics.jpg" },
    { title: "Spice mix", category: "food", videoUrl: "/samples/food.mp4", posterUrl: "/samples/food.jpg" },
    { title: "Earbuds", category: "electronics", videoUrl: "/samples/earbuds.mp4", posterUrl: "/samples/earbuds.jpg" },
    { title: "Restaurant menu", category: "restaurant", videoUrl: "/samples/restaurant.mp4", posterUrl: "/samples/restaurant.jpg" },
    { title: "Handicraft", category: "other", videoUrl: "/samples/handicraft.mp4", posterUrl: "/samples/handicraft.jpg" },
  ];
  for (let i = 0; i < samples.length; i++) {
    const s = samples[i]!;
    await prisma.sample.create({ data: { ...s, sortOrder: i, active: true } });
  }

  // ── FAQ ───────────────────────────────────────────────────
  const faqs = [
    { q: "কিভাবে অর্ডার করব?", a: "হোম পেজ থেকে প্যাকেজ বাছুন, ব্রিফ পূরণ করুন, bKash এ পেমেন্ট করুন।" },
    { q: "কত দিনে ডেলিভারি পাব?", a: "স্ট্যান্ডার্ড ৪৮ ঘন্টা, প্রিমিয়াম ৭২ ঘন্টা।" },
    { q: "ফ্রি প্রিভিউ কি?", a: "আপনার পণ্যের ছবি দিন, ১ মিনিটে একটি ৫ সেকেন্ডের ফ্রি ভিডিও পাবেন।" },
    { q: "বাংলা ভাষায় ভিডিও হবে?", a: "হ্যাঁ, ডিফল্ট বাংলা। চাইলে ইংরেজি বা বাংলিশ নির্বাচন করুন।" },
    { q: "রিভিশন কি পাব?", a: "প্যাকেজ অনুযায়ী ১-২ বার ফ্রি রিভিশন।" },
  ];
  for (let i = 0; i < faqs.length; i++) {
    const f = faqs[i]!;
    await prisma.faq.create({ data: { question: f.q, answer: f.a, sortOrder: i, active: true } });
  }

  // ── Testimonials ─────────────────────────────────────────
  // Example testimonials are for local demos only — never shown in production
  // (publish only real customer quotes, added from Admin → Content).
  const testimonials = env.isProd ? [] : [
    { name: "Rina Akter", role: "Facebook seller, Dhaka", quote: "আমার শাড়ির বিজ্ঞাপনটা দেখে অর্ডার ৩ গুন বেড়ে গেছে!", rating: 5 },
    { name: "Hasan Mahmud", role: "Cosmetics, Chittagong", quote: "ফ্রি প্রিভিউ দেখেই অর্ডার করেছিলাম। সময়ে ডেলিভারি পেয়েছি।", rating: 5 },
    { name: "Sadia Islam", role: "Restaurant, Sylhet", quote: "ভিডিও কোয়ালিটি প্রফেশনাল। সিনেমার মতো লাগে।", rating: 5 },
  ];
  for (let i = 0; i < testimonials.length; i++) {
    const t = testimonials[i]!;
    await prisma.testimonial.create({ data: { ...t, sortOrder: i, active: true } });
  }

  console.log("✅ Seed complete");
  console.log("Admin login:", env.adminEmail, "/", env.adminPassword);
  console.log("Operator: operator@dreamstudio.bd / operator12345");
  console.log("Editor: editor@dreamstudio.bd / editor12345");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
