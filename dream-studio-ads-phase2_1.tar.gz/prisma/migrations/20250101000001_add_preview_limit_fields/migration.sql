-- Migration: add Customer.previewUsed + Customer.previewRetryUsed
-- Phase 1B Item 4: DB-level free-preview limit. previewUsed is claimed
-- atomically in /api/preview/generate; previewRetryUsed tracks the one-time
-- reset granted on a moderation rejection or generation failure.

ALTER TABLE "Customer" ADD COLUMN "previewUsed" BOOLEAN NOT NULL DEFAULT false;

ALTER TABLE "Customer" ADD COLUMN "previewRetryUsed" INTEGER NOT NULL DEFAULT 0;
