-- Migration: add Order.moderationOverride
-- Phase 1C Item 4: when admin approves a MANUAL_REVIEW order via
-- /api/admin/order/[id]/review (action=approve), this flag is set to true
-- so the next generate_script run skips moderation (the admin already
-- reviewed the product).

ALTER TABLE "Order" ADD COLUMN "moderationOverride" BOOLEAN NOT NULL DEFAULT false;
