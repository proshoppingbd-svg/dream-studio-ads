-- Phase 2: manual bKash QR payments + Drive folder link
ALTER TABLE "Payment" ADD COLUMN "senderNumber" TEXT;
ALTER TABLE "Payment" ADD COLUMN "amountEntered" INTEGER;
ALTER TABLE "Payment" ADD COLUMN "screenshotKey" TEXT;
ALTER TABLE "Payment" ADD COLUMN "rejectReason" TEXT;
ALTER TABLE "Payment" ADD COLUMN "submittedAt" TIMESTAMP(3);
ALTER TABLE "Payment" ADD COLUMN "providerPaymentId" TEXT;
CREATE UNIQUE INDEX "Payment_trxId_key" ON "Payment"("trxId");
ALTER TABLE "Order" ADD COLUMN "driveFolderUrl" TEXT;
